# Payment

The payment module provides a means for RVOS callcenter employees to submit a
payment to an account on behalf of a customer.

## Getting Started

There are a couple of ways to get started with user the payment module.

### Prerequisites

The XML-RPC module is required for the payment module to work.

### Installing

There are several ways to install the module.

### Manual download

Pull down a copy of the module from stash.rvos.com and put it into the modules
folder in the root Drupal 8 directory. If you follow typical stands the module
should go into either the contributed or custom modules folder depending on
whether or not your pulling it down as a contributed module or as in-house.

### Git

Change directories from the command-line to the drupal 8/modules/custom or
other directory where you are storing your custom modules. Run the following GIT
command.

`git checkout 1.x`

### Composer

Change to the parent directory of you drupal 8 install where your primary
composer.json file resides and use composer require to add the module dependency.

`composer require 'czechpoint/payment:1.x-dev'`

to retrieve the module code from the repository

## Enabling the module

You can enable the module in one of two ways as follows.

### Drupal 'Extend' interface

Sign-on to your Drupal website as a user with permissions to enable modules.
Navigate to the 'Extend' page and search for the 'Payment' module. Click the
checkbox next to the module and click the 'Save' button to enable the payment
module.

### Drush

If you have Drush (Drupal Shell) setup and configured you can use Drush to 
enable the module. Please view the Drush documentation on how to enable modules
for your specific version of Drush.

## Contributing

Please read CONTRIBUTING.md for details.

## Authors
 
 * Daniel Taylor - Contributer - [email](mailto:dtaylor@rvos.com)

## License

Please read LICENSE.md for details.
