<?php
/*
 * @author Daniel Taylor <dtaylor@rvos.com>
 * Contains \Drupal\payment\Form\PaymentSettingsForm.
 */
namespace Drupal\payment\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Payment Settings Form
 */
class PaymentSettingsForm extends ConfigFormBase
{

  /**
  * {@inheritdoc}
  */
  protected function getEditableConfigNames(): array
  {
    return ['payment.settings'];
  }

  /**
  * {@inheritdoc}
  */
  public function getFormId(): string
  {
    return 'payment_settings';
  }

  /**
  * {@inheritdoc}
  */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
    parent::buildForm($form, $form_state);
    $config = $this->config('payment.settings');
    $settings = $config->get();
    $form['endpoint'] = array(
      '#type' => 'details',
      '#title' => $this->t('Webservice Settings'),
      '#open' => TRUE, // Controls the HTML5 'open' attribute. Defaults to FALSE.
    );
    $form['endpoint']['payment_webservice'] = array(
      '#title' => $this->t('Endpoint URL for our payments processing webservice.'),
      '#description' => $this->t('These two services are independent. This first one processes EFT and CC transactions; the second looks up the account information from cesta.'),
      '#type' => 'textfield',
      '#default_value' => $config->get('payment_webservice'),
      '#required' => true,
    );
    $form['endpoint']['payment_lookup_webservice'] = array(
      '#title' => $this->t('Endpoint URL for our payments account lookup webservice.'),
      '#description' => $this->t('Please ensure there is no space at the tail of the endpoint.'),
      '#type' => 'textfield',
      '#default_value' => $config->get('payment_lookup_webservice'),
      '#required' => true,
    );
	
    $options = array('disallow' => $this->t('DISALLOW'), 'allow' => $this->t('ALLOW'));
    $form['endpoint']['payment_send_receipt_emails'] = array(
      '#title' => 'Allow receipt emails to be sent (ALLOW for production).',
      '#description' => '',
      '#type' => 'radios',
      '#options' => $options,
      '#default_value' => $config->get('payment_send_receipt_emails'),
      '#required' => true,
    );
	
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save configuration'),
      '#button_type' => 'primary',
    );
	
    return $form;
  }

  /**
  * {@inheritdoc}
  */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    parent::validateForm($form, $form_state);
  }

  /**
  * {@inheritdoc}
  */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    // Get the configuration settings
    $config = $this->configFactory->getEditable('payment.settings');

    // Save configuration settings
    $config
      ->set('payment_webservice', $form_state->getValue('payment_webservice'))
      ->set('payment_lookup_webservice', $form_state->getValue('payment_lookup_webservice'))
      ->set('payment_send_receipt_emails', $form_state->getValue('payment_send_receipt_emails'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
