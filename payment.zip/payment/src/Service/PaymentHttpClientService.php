<?php
/*
 * @author Daniel Taylor <dtaylor@rvos.com>
 * Contains \Drupal\payment\Service\PaymentHttpClientService
 */
namespace Drupal\payment\Service;

use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ConfigValueException;
use Drupal\Core\Form\FormStateInterface;
use Drupal\payment_receipt_search\Value\PaymentReceipt;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;

/**
 *
 */
class PaymentHttpClientService
{

 /**
  * @var Configuration
  */
  private $config;

 /**
  * @var Logger
  */
  private $logger;

 /**
  * @var \GuzzleHttp\Client
  */
  private $httpClient;

 /**
  * @var \Drupal\Core\Form\FormStateInterface
  */
  private $form_state;

 /**
  * Constructs the PaymentHttpClientService object.
  *
  * @param ConfigFactoryInterface $config_factory
  * @param LoggerInterface $logger
  */
  public function __construct(ConfigFactoryInterface $config_factory, LoggerInterface $logger, Client $http_client)
  {
    $this->config = $config_factory->get('payment.settings');
    $this->logger = $logger;
    $this->httpClient = $http_client;
  }

 /**
  * Creates a new instance for Drupal\payment\Service\PaymentHttpClientService
  *
  * @param ConfigFactoryInterface $config_factory
  * @return Drupal\payment\Service\PaymentHttpClientService
  */
  public static function create(ConfigFactoryInterface $config_factory, LoggerInterface $logger, Client $http_client)
  {
    return new static($config_factory, $logger, $http_client);
  }

 /**
  * Retrieves customer information based on search criteria provided by the
  * Drupal\Core\Form\FormStateInterface values.
  *
  * The values needed are;
  * - search_account_number
  * - search_billing_zip
  *
  * @param FormStateInterface $form_state
  * @return mixed boolean|array
  */
  public function retrieveCustomerInformation(FormStateInterface $form_state)
  {

    $this->form_state = $form_state;
    $query = [
      'account' => $form_state->getValue('search_account_number'),
      'zip' => $form_state->getValue('search_billing_zip'),
    ];

    $headers = [
      'Content-type' => 'text/xml; charset=UTF-8',
    ];

    $endpoint = $this->config->get('payment_lookup_webservice');
    $response = $this->httpClientRequest($endpoint, ['query' => $query, 'headers' => $headers]);

    if ($response !== false && !empty($response)) {
      return json_decode($response->getBody()->getContents(), true);
      
    }
    return false;
  }

 /**
  * Handles an occurrence of RequestException for a httpClient request.
  *
  * @param RequestException $e
  */
  protected function httpClientRequestException(RequestException $e)
  {
    drupal_set_message($e->getMessage(), 'error');
    $this->logger->error($this->t($e->getMessage()));
  }

 /**
  * Sets a message in Drupal based on the httpClient request status code.
  *
  * @param type $statusCode
  */
  protected function processClientStatusCode($statusCode)
  {
    switch ($statusCode) {
      case '200':
        return true;
      case '204':
        $msg = t('Account not found. Please verify the account information.');
        break;
      case '400':
        $msg = t('Our services have encountered an error. If this error persists, call customer service at 1-800-792-3084.');
        
        break;
      case '500':
        $msg = t('Our services have encountered an error. If this error persists, please call customer service at 1-800-792-3084.');        
        break;
      default:
        $msg = t('Account not found. Please verify the account information.');
        
    }

    if (isset($msg)) {
      $this->form_state->setErrorByName('search_account_number', $msg);
    }
    return false;
  }

 /**
  * Makes a HTTP client request. See \Drupal::httpClient().
  * This makes use of GuzzleHTTP which requires cURL.
  *
  * @param type $endpoint
  * @param type $options
  * @param type $method
  * @return boolean
  */
  protected function httpClientRequest($endpoint, $options, $method = 'get')
  {
    if (!empty($endpoint)) {
      $response = $this->httpClient->get($endpoint, $options);
      try {
        if ($this->processClientStatusCode($response->getStatusCode())) {
          return $response;
        }
      } catch (RequestException $e) {
        $this->httpClientRequestException($e);
      }
    }
    return false;
  }
}
