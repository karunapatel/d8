# Lodge

Lodge provides a user interface for interacting with the lodge database records
stored in the oracle database. The interaction with the database is done across
XML-RPC using Drupal 8's XML-RPC module.

## Getting Started

Pull down a copy of the module from stash.rvos.com and put it into the modules
folder in the root Drupal 8 directory. If you follow typical stands the module
should go into either the contributed or custom modules folder depending on
whether or not your pulling it down as a contributed module or as in-house.

### Prerequisites

You will need the XML-RPC module for Drupal 8. The XML-RPC module is no longer
distributed with Drupal 8 by default and will need to be downloaded manually.

### Installing

Place the lodge module into the your Drupal8/modules folder. Navigate to the
extend page in Drupal 8 and tick the checkbox for the lodge module. Click the
save button to finalize your options.

Do not forget to configure the XML-RPC endpoint URL in the lodge module settings.
By default it will point to the development server for the dev XML-RPC web
services.

### XML-RPC URLs as of 2017-10-13 (Black Friday!)
 - UAT: http://winservicesdev/uat/webservices/trunk/index.php
 - PROD: http://winservices/webservices/index.php

## Contributing

Please read CONTRIBUTING.md for details.

## Authors

 * Daniel Taylor - Initial Drupal 8 migration - [email](mailto:dtaylor@rvos.com)

## License

Please read LICENSE.md for details.
