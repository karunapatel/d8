Copyright (c) 2017 RVOS Insurance.

You may not use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of this Software without prior written permission from RVOS Insurance.
