# Changelog
All notable changes to this project will be documented in this file.

## [v8.x-1.1] - 2018-01-xx
### Added
- Added validation to the Add Officer page to prevent adding an officer where the termination date occurs before the Took Office on date.

### Changed
- Resolved an issue where getTerminationDate() was being referenced as a variable instead of method.
- Changed all editable field #prefix and #suffix values to variables to reduce the HTML in the code and to allow the editable content to be more manageable on code side.
- Changed the tier id value when adding a new lodge to retrieve the value from the form state directly instead of from the defaults variable.
- Resolved an error when saving lodge officers and lodge agents.
- Resolved an error when viewing lodge officer create page.
- Resolved an error when viewing lodge agent create page.
- Resolved an issue displaying the Took Office On date for lodge agents.
- Resolved an issue with the redirect on adding an officer. The lodge xml-rpc service doesn't return the lodge officer information so we do not have an officer id to redirect to the officer's newly created page. Changed this to return to the list of officers depending on the officers status; current or terminated which also takes into consideration the termination date compared to the current date.
- Resolved an issue with the officer add validation where the status was not referring to the correct field name and therefore not validating the termination date properly.

## [v8.x-1.0] - 2018-01-10
### Added
- Added composer compatibility for use in managing the module with composer.
- Added AJAX submits to lodge, officer, and agent editable fields for saving changes.

### Changed
- Resolved issues in lodge search.
- Resolved some issues to reduce messages written to PHP/Apache logs.
- Resolved some issues with back links.
- Reworked the formatter service to make formatting easier addresses and phone numbers easier.
- Resolved issues with Terminated date and statuses.
- Lodge officers and agents with future termination dates will display as active now instead of terminated until after the termination date specified.
- Dues confirmation and failure message changes.
- Resolved an Apply Promo database case issue.
- Resolved an issue with Cesta status and Agent lodge status; they were being treated as the same thing.

## [v8.x-1.0rc6] - 2017-11-22
### Changed
 - Fixed [issue #1949393](https://rvos.teamwork.com/desk/#/tickets/1949393) in Teamwork Desk
 - Fixed [issue #1952146](https://rvos.teamwork.com/desk/#/tickets/1952146) in Teamwork Desk 

## [v8.x-1.0rc5] - 2017-10-13 (Friday the 13th)
### Changes
 - Resolved several issues with saving (editing and creating) lodges, agents,
officers, and lodge dues.

## [v8.x-1.0rc4] - 2017-10-11
### Changes
 - Moved all the back link URLs from the controllers to the forms: it is now
possible to modify the back links through the use hook_form_alter().
 - Updated references to officer id, officer name, agent id, agent name, lodge id,
lodge name in the controllers to utilize the value as set in the form where it
was applicable to do so. This reduces the number of XML-RPC calls which were
used to display this information at the top of the lodge pages. Removed the
unnecessary XML-RPC calls.
 - Added a check to hook_form_alter in lodge.module to check if #type is set on
the element before attempting to loop through it. This prevents a lot of writes
to the watchdog table, and, therefore, significantly decreases the amount of
time required to load and render the page.

## [v8.x-1.0rc3] - 2017-10-03
### Added
 - Added ValueNormalizationInterface for use in normalizing Lodge XML-RPC response
date with that of Drupal 8 to help in the use of the response data with forms and
other Drupal 8 systems easier.
 - Added DateTimeNormalization functionality.
 - Added XmlRpcValue to assist with translations from the lodge XML-RPC service
to Drupal 8.
 - Added a XML-RPC query entity which handles the XML-RPC query callbacks to
the lodge service to help assist with easier searching of content queried through
the use of the Lodge XML-RPC service.
 - Added a search form and controller.
 - Added a search block.
 - Added a search page.
 - Added search functionality to the Lodge XML-RPC service which searches for
lodges and lodge officers. Cannot search for agents due to the limit on the input
data the XML-RPC request allows for input: only allows agent Ids.

### Changed
 - Updated several retrieve functions in the Lodge XML-RPC service to utilize
the XmlRpcQuery object.
 - Updated the XmlRpcLodge, XmlRpcLodgeAgent, and XmlRpcLodgeOfficer objects to
use the new XmlRpocQuery object.
 - Removed Tax ID field from all forms where applicable.

## [v8.x-1.0rc2] - 2017-09-14
### Changed
 - Resolved an issue where lodge agents could not be viewed or edited.
 - Resolved an issue where viewing/editing an agent was improperly placing the
   change text on the 'Agent ID' details summary.
 - Resolved an issue where the CONTRIBUTING.md file was missing the .md file
   extension.
 - Updated the hook_install() method to check for known production URLs and
   assign the production XML-RPC endpoint URL as the default URL in cases where
   the current host name matches a known production URL for czechpoint. All
   other host cases get the development web services XML-RPC endpoint URL.

### Added
 - Updated lodge.settings.xml to contain the XML-RPC endpoint URL for production
   web services.

## [v8.x-1.0rc1] - 2017-09-14
### Added
 - The initial release candidate and commit to GIT @ stash.rvos.com.
 - Conversion from the Drupal 7 module named lodge_ui.