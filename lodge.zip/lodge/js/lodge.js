
jQuery(function() {

  jQuery('[name="lodge_status"]').each(function(i, e) {
    e.addEventListener('change', function(event) {
      displayLodgeStatusChangeConfirmation();
    });
  });

  jQuery('.details-container details >summary').each(function(index, element) {

    toggleDetailsActionStatus(element);

    element.addEventListener('click', function(event) {
      toggleElement = jQuery(this).find('.details-summary-edit-toggle');
      if (toggleElement.text().length <= 0 || toggleElement.text() === 0 || toggleElement.text() === '' || toggleElement.text() === null) {
        event.preventDefault();
      }
    });

    element.addEventListener('toggle', function(event) {
      toggleDetailsActionStatus(this);
    });
  });

  function displayLodgeStatusChangeConfirmation() {
    if(!confirm("Warning - The status of the lodge will be changed!")) {}
  }

  function toggleDetailsActionStatus(element) {
    toggleElement = jQuery(element).find('.details-summary-edit-toggle');
    if (element.hasAttribute('open')) {
      toggleElement.text('hide');
    } else {
      toggleElement.text('change');
    }
  }  
              
});
