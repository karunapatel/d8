<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Form\AbstractLodgeForm;

/**
 * Description of OfficerHistoryForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class OfficerHistoryForm extends AbstractLodgeForm {

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $officer_id = null) {

    if (empty($lodge_id) || empty($officer_id)) {
      $this->redirect('lodge.list', [], [], 404);
    }

    $officer = $this->lodgeService->retrieveLodgeOfficer($officer_id)->getOfficer();
    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $history = $this->lodgeService->retrieveLodgeOfficerHistory($lodge_id, $officer_id);
    
    $officerStatus = 'current';
    if (is_null($officer->getTerminationDate())) {
      $officerStatus = 'terminated';
    }

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.officers', ['lodge_id' => $lodge_id, 'officer_status' => $officerStatus]),
    ];

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];

    $form['officer_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Officer ID'),
      '#default_value' => $officer_id
    ];

    $form['officer_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Officer Name'),
      '#default_value' => $officer->getFullName(),
    ];
    
    if (empty($history)) {
      $form['results'] = [
          '#type' => 'markup',
          '#markup' => 'No changes have been made to this officer.',
          '#prefix' => '<div class="officer-history-page">',
          '#suffix' => '</div>',
        ];
      return $form;
    }

    $idx = 0;
    foreach ($history as $i => $record) {
      $form['records'][$i] = [
        '#type' => 'table',
        '#header' => [
          $this->getTitleFromFieldName('HISTORY_ID'),
          $this->getTitleFromFieldName('TIMESTAMP'),
          $this->getTitleFromFieldName('USER_ID'),
        ],
        '#prefix' => '<div class="officer-history-page officer-history-page-top">',
        '#suffix' => '</div>',
      ];

      $form['records'][$i][$idx]['hid'] = [
        '#title' => $this->getTitleFromFieldName('HISTORY_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['HISTORY_ID'],
      ];

      $form['records'][$i][$idx]['timestamp'] = [
        '#title' => $this->getTitleFromFieldName('TIMESTAMP'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['TIMESTAMP'],
      ];

      $form['records'][$i][$idx]['uid'] = [
        '#title' => $this->getTitleFromFieldName('USER_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['USER_ID'],
      ];

      foreach ($record['CHANGES'] as $changeIdx => $changes) {
        $idx++;
        $headers = [];
        $form['records'][$i][$idx]['changes'] = [
          '#type' => 'table',
          '#wrapper_attributes' => ['colspan' => 3],
        ];

        foreach ($changes as $k => $v) {
          $headers[] = ucwords($this->getTitleFromFieldName($k));
          $form['records'][$i][$idx]['changes'][$changeIdx][strtolower($k)] = [
            '#title' => $this->getTitleFromFieldName($k),
            '#title_display' => 'invisible',
            '#attributes' => ['class' => []],
            '#type' => 'item',
            '#markup' => $v,
            '#prefix' => '<div class="officer-history-page officer-history-page-result">',
            '#suffix' => '</div>',
          ];
        }

        $form['records'][$i][$idx]['changes']['#header'] = $headers;
      }
      $idx++;
    }

    return $form;
  }

  public function getFormId() {
    return 'lodge_officer_history';
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Form is not submittable.
  }

  public function getTitleFromFieldName($fieldName) {
    $a = [
      'HISTORY_ID' => $this->t('History ID'),
      'TIMESTAMP' => $this->t('Timestamp'),
      'ACTION' => $this->t('Action'),
      'USER_ID' => $this->t('User ID'),
      'PREVIOUS_LODGE_ID' => $this->t('Previous Lodge ID'),
      'NEW_LODGE_ID' => $this->t('New Lodge ID'),
      'PREVIOUS_OFFICER_ID' => $this->t('Previous Officer ID'),
      'NEW_OFFICER_ID' => $this->t('New Officer ID'),
      'PREVIOUS_OFFICETYPE_ID' => $this->t('Previous Office Type ID'),
      'NEW_OFFICETYPE_ID' => $this->t('New Officer Type ID'),
      'PREVIOUS_FIRST_NAME' => $this->t('Previous First Name'),
      'NEW_FIRST_NAME' => $this->t('New First Name'),
      'PREVIOUS_MIDDLE_NAME' => $this->t('Previous Middle Name'),
      'NEW_MIDDLE_NAME' => $this->t('New Middle Name'),
      'PREVIOUS_LAST_NAME' => $this->t('Previous Last Name'),
      'NEW_LAST_NAME' => $this->t('New Last Name'),
      'PREVIOUS_ADDRESS' => $this->t('Previous Address'),
      'NEW_ADDRESS' => $this->t('New Address'),
      'PREVIOUS_CITY' => $this->t('Previous City'),
      'NEW_CITY' => $this->t('New City'),
      'PREVIOUS_STATE' => $this->t('Previous State'),
      'NEW_STATE' => $this->t('New State'),
      'PREVIOUS_ZIP' => $this->t('Previous Zip'),
      'NEW_ZIP' => $this->t('New Zip'),
      'PREVIOUS_ZIP_EXT' => $this->t('Previous Zip Ext'),
      'NEW_ZIP_EXT' => $this->t('New Zip Ext'),
      'PREVIOUS_WORKPHONE' => $this->t('Previous Work Phone'),
      'NEW_WORKPHONE' => $this->t('New Work Phone'),
      'PREVIOUS_CELLPHONE' => $this->t('Previous Cell Phone'),
      'NEW_CELLPHONE' => $this->t('New Cell Phone'),
      'PREVIOUS_FAX' => $this->t('Previous Fax'),
      'NEW_FAX' => $this->t('New Fax'),
      'PREVIOUS_EMAILADDRESS' => $this->t('Previous Email Address'),
      'NEW_EMAILADDRESS' => $this->t('New Email Address'),
      'PREVIOUS_TAXID' => $this->t('Previous Tax ID'),
      'NEW_TAXID' => $this->t('New Tax ID'),
      'PREVIOUS_TOOK_OFFICE_DATE' => $this->t('Previous Took Office Date'),
      'NEW_TOOK_OFFICE_DATE' => $this->t('New Took Office Date'),
      'PREVIOUS_TERMINATION_DATE' => $this->t('Previous Termination Date'),
      'NEW_TERMINATION_DATE' => $this->t('New Termination Date'),
    ];
    if (array_key_exists($fieldName, $a)) {
      return $a[$fieldName];
    }
  }

}
