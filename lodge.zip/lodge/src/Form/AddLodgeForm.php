<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Value\Lodge;
use Drupal\lodge\Value\LodgeDues;
use Drupal\lodge\Value\XmlRpcLodge;
use Drupal\lodge\Value\XmlRpcLodgeDues;
use Drupal\Core\Url;

/**
 * Description of LodgeGeneralSettingsForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class AddLodgeForm extends AbstractLodgeForm {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'lodge_add_lodge';
  }

  /**
   * The lodge general settings form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
           
    $countyOptions = $this->lodgeService->retrieveCounties();
    $tierOptions = $this->lodgeService->retrieveTiers();
    $districtOptions = $this->lodgeService->retrieveDistricts();
    $applyLodgeRefundOptions = ['y' => $this->t('Yes'), 'n' => $this->t('No')];

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ]; 
    
    $form['lodge_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('ID'),
      '#size' => 5,
      '#maxlength' => 4,
      '#required' => true,
      '#defaul_value' => $form_state->getValue('lodge_id'),
    ];

    $form['lodge_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#size' => 35,
      '#maxlength' => 30,
      '#required' => true,
      '#default_value' => $form_state->getValue('lodge_name'),
    ];

    $form['county_name'] = [
      '#type' => 'select',
      '#title' => $this->t('County'),
      '#options' => $countyOptions,
      '#required' => true,
      '#default_value' => $form_state->getValue('county_name'),
    ];

    $form['tier_id'] = [
      '#type' => 'select',
      '#title' => $this->t('Tier'),
      '#options' => $tierOptions,
      '#required' => true,
      '#default_value' => $form_state->getValue('tier_id'),
    ];

    $form['district_id'] = [
      '#type' => 'select',
      '#title' => $this->t('District'),
      '#options' => $districtOptions,
      '#required' => true,
      '#default_value' => $form_state->getValue('district_id'),
    ];

    $form['organized_date'] = [
      '#type' => 'date',
      '#title' => $this->t('Date Organized'),
      '#required' => true,
      '#default_value' => empty($form_state->getValue('organized_date')) ? (new DrupalDateTime())->format('Y-m-d') : $form_state->getValue('organized_date'),
    ];

    $form['apply_lodge_refund'] = [
      '#type' => 'radios',
      '#title' => $this->t('Apply Lodge Refund?'),
      '#options' => $applyLodgeRefundOptions,
      '#required' => true,
      '#default_value' => empty($form_state->getValue('apply_lodge_refund')) ? 'y' : $form_state->getValue('apply_lodge_refund'),
    ];

    $form['add_dues'] = [
      '#title' => 'Add a new dues entry',
      '#type' => 'checkbox',
      '#default_value' => empty($form_state->getValue('add_dues')) ? false : $form_state->getValue('add_dues'),
    ];

    $form['dues_amount'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Dues Amount'),
      '#size' => 5,
      '#maxlength' => 4,
      '#states' => [
        'visible' => [
          ':input[name="add_dues"]' => ['checked' => true],
        ],
        'required' => [
          ':input[name="add_dues"]' => ['checked' => true],
        ],
      ],
      '#default_value' => $form_state->getValue('dues_amount'),
    ];

    $form['dues_effective_date'] = [
      '#type' => 'date',
      '#title' => $this->t('Effective Date'),
      '#states' => [
        'visible' => [
          ':input[name="add_dues"]' => ['checked' => true],
        ],
        'required' => [
          ':input[name="add_dues"]' => ['checked' => true],
        ],
      ],
      '#default_value' => empty($form_state->getValue('dues_effective_date')) ? (new DrupalDateTime())->format('Y-m-d') : $form_state->getValue('dues_effective_date'),
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

  /**
   * Handle the validation of the lodge general settings form.
   *
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

    parent::validateForm($form, $form_state);

    if (0 === preg_match('/^[0-9]{1,4}$/', $form_state->getValue('lodge_id'))) {
      $form_state->setError($form['lodge_id'], t('%title must be numeric.', ['%title' => $form['lodge_id']['#title']]));
    }

    $lodge = $this->lodgeService->retrieveLodge($form_state->getValue('lodge_id'));
    if (!empty($lodge)) {
      $form_state->setError($form['lodge_id'], t('A lodge with the Lodge ID of %lodge_id already exists.', ['%lodge_id' => $form_state->getValue('lodge_id')]));
    }

    if (0 === preg_match('/^[a-zA-Z\d,-_.\s#\'\&()]{1,30}$/', $form_state->getValue('lodge_name'))) {
      $form_state->setError($form['lodge_name'], t('%title contains invalid characters.', array('%title' => $form['lodge_name']['#title'])));
    }

    try {
      $organizedDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('organized_date')));
    } catch (\Exception $e) {
      $form_state->setError($form['organized_date'], $this->t('%title is not a valid date.', array('%title' => $form['organized_date']['#title'])));
    }

    if ($form_state->getValue('add_dues') == true) {
      $amount = $form_state->getValue('dues_amount');
      if (empty($amount) || !is_numeric($form_state->getValue('dues_amount'))) {
        $form_state->setError($form['dues_amount'], $this->t('%title cannot be empty and must be numeric.', array('%title' => $form['dues_amount']['#title'])));
      }

      try {
        $effectiveDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('dues_effective_date')));
      } catch (\Exception $e) {
        $form_state->setError($form['dues_effective_date'], $this->t('%title is not a valid date.', array('%title' => $form['dues_effective_date']['#title'])));
      }
    }

  }

  /**
   * Handle the lodge general settings form submission.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $xmlRpcLodge = new XmlRpcLodge(new XmlRpcQuery($this->lodgeService), Lodge::createFromFormState($form_state));

    // Use the lodge service to save the lodge.
    $response = $xmlRpcLodge->save();

    if (false != $response) {

      $lodge = $response->getLodge();
      drupal_set_message($this->t('The lodge record has been saved successfully.'));

      if ($form_state->getValue('add_dues') == true) {

        $lodgeDues = LodgeDues::createFromFormState($form_state);
        $xmlRpcLodgeDues = new XmlRpcLodgeDues($this->lodgeService, $lodgeDues);

        $duesResponse = $xmlRpcLodgeDues->save();
        if (false != $duesResponse) {
          drupal_set_message($this->t('Lodge new lodge dues have been saved successfully.'));
        } else {
          drupal_set_message($this->t('The lodge dues were not saved.'), 'error');
        }
      }

      return $form_state->setRedirect('lodge.view', ['lodge_id' => $lodge->getLodgeId()]);
      
    }

    drupal_set_message($this->t('The lodge record was not saved.'), 'error');
  }

}
