<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Value\Address;
use Drupal\lodge\Value\Contact;
use Drupal\lodge\Value\LodgeAgent;
use Drupal\lodge\Value\XmlRpcLodgeAgent;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;

/**
 * Description of EditAgentForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class EditAgentForm extends AbstractLodgeForm {

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $agent_id = null) {

    $user = \Drupal::currentUser();

    if (is_null($lodge_id)) {
      drupal_set_message('Unable to find the lodge requested.', 'warning');
      return $this->redirect('lodge.list', [], [], 404);
    }

    if (is_null($agent_id)) {
      drupal_set_message('Unable to find the agent requested.', 'warning');
      return $this->redirect('lodge.view', ['lodge_id' => $lodge_id], [], 404);
    }

    $outputFormatter = \Drupal::service('lodge.outputformatter');

    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $agent = $this->lodgeService->retrieveLodgeAgents($lodge_id, $agent_id)->getLodgeAgent();

    $promoOptions = ['yes' => $this->t('Yes'), 'no' => $this->t('No')];
    $agentStatusOptions = ['active' => $this->t('Active'), 'terminated' => $this->t('Terminated')];

    $zipExt = $agent->getZipExt();
    $address = $agent->getAddress() . "\n" . $agent->getCity() . ', ' . $agent->getZip() . (!empty($zipExt) ? '-' . $zipExt : '') . "\n" . $agent->getCountyName() . ' County';

    /* $termStatus = is_null($agent->getTerminationDate()) ? 'active' : 'terminated';  */ //commented by synapseindia
    // Line added by synapseinda
    /* RVOS comment and change; Datetime objects can be compared directly (same as DrupalDateTime objects). */
    if (is_null($agent->getTerminationDate()) || ($agent->getTerminationDate() > new DrupalDateTime())) {
      $termStatus = 'active';
    }
    else {
      $termStatus = 'terminated';
    }
    // Line Ended    
    //    $term = "Status: ".$agentStatusOptions[$termStatus]."\nBegin: ".$agent->getTookOfficeDate('n/j/Y')."\nEnd: ".(is_null($agent->getTerminationDate()) ? '' : $agent->getTerminationDate('n/j/Y'));
    // URL usage.
    $agentStatus = $termStatus;
    if ($form_state->getValue('agent_lodge_status') || $termStatus == 'active') {
      $agentStatus = 'current';
    }

    /* $form['history_link2'] = [
      '#type' => 'link',
      '#title' => $this->t('History'),
      '#attributes' => ['class' => ['history-link last']],
      '#url' => Url::fromRoute('lodge.agenthistory', ['lodge_id' => $lodge_id, 'agent_id' => $agent_id]),
      ]; */

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.agents', ['lodge_id' => $lodge_id, 'agent_status' => $agentStatus]),
    ];

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];

    $form['agent_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Agent ID'),
      '#default_value' => $agent_id,
    ];

    $form['took_office_on'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Took Office Date'),
      '#default_value' => $agent->getTookOfficeDate('Y-m-d'),
    ];

    $form['aid'] = [
      '#type' => 'details',
      '#title' => $this->t('Agent ID'),
      '#description' => $this->t('Id of the agent.'),
      '#value' => '<div class="field-output">' . $agent->getAgentId() . '</div>',
    ];

    $form['name'] = [
      '#type' => 'details',
      '#title' => $this->t('Name'),
      '#description' => $this->t('Full name of the agent.'),
      '#value' => '<div class="field-output">' . $agent->getName() . '</div>',
    ];

    $form['agency'] = [
      '#type' => 'details',
      '#title' => $this->t('Agency'),
      '#description' => $this->t('Agency.'),
      '#value' => '<div class="field-output">' . $agent->getBrokerageName() . '</div>',
    ];

    $address = new Address($agent->getAddress(), $agent->getCity(), $agent->getState(), $agent->getZip(), $agent->getCountyName(), $agent->getZipExt());
    $form['address'] = [
      '#type' => 'details',
      '#title' => $this->t('Address'),
      '#description' => $this->t('Mailing address.'),
      '#value' => '<div class="field-output">' . $outputFormatter->formatAddress($address) . '</div>',
    ];

    $form['email'] = [
      '#type' => 'details',
      '#title' => $this->t('eMail'),
      '#description' => $this->t('eMail address.'),
      '#value' => '<div class="field-output">' . $agent->getEmailAddress() . '</div>',
    ];

    $contactString = '';
    if (!empty($agent->getWorkPhone())) {
      $contactString .= "Work: {$outputFormatter->formatContact(new Contact('phone', $agent->getWorkPhone()))}";
    }
    if (!empty($agent->getCellPhone())) {
      if (!empty($contactString)) {
        $contactString .= "\n";
      }
      $contactString .= "Cell: {$outputFormatter->formatContact(new Contact('phone', $agent->getCellPhone()))}";
    }
    if (!empty($agent->getFax())) {
      if (!empty($contactString)) {
        $contactString .= "\n";
      }
      $contactString = "Fax: {$outputFormatter->formatContact(new Contact('phone', $agent->getFax()))}";
    }
    $form['contact'] = [
      '#type' => 'details',
      '#title' => $this->t('Contact'),
      '#description' => $this->t('Contact Information.'),
      '#value' => '<div class="field-output">' . $contactString . '</div>',
    ];
    
    $prefix = '';
    $suffix = '';
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {
    $prefix = '<div class="detail-summary-group element-group-edit"><span class="details-summary-edit-toggle">change</span>';
    $suffix = '</div>';    
    }

    $doPromo = strtolower($agent->getApplyPromo());
    $do_promo = array_key_exists($doPromo, $promoOptions) ? $promoOptions[$doPromo] : $promoOptions['no'];
    $form['promo'] = [
      '#type' => 'details',
      '#title' => $this->t('Agent Promo'),
      '#description' => $this->t('Apply agent promo?'),
      '#value' => '<div class="field-output">' . $do_promo . '</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => [
        'callback' => '::ajaxReturn',
      ],
    ];

    $form['agent_term'] = [
      '#type' => 'details',
      '#title' => $this->t('Term'),
      '#description' => $this->t('Date the agent took and left office.'),
      '#value' => '<div class="field-output">' . nl2br($outputFormatter->formatOfficeTerm($agentStatusOptions[$termStatus], $agent->getTookOfficeDate(), $agent->getTerminationDate())) . '</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => [
        'callback' => '::ajaxReturn',
      ],
    ];

    // Term status is NOT the same as cesta status.
    // $agent->getStatus() is cesta status.
    // Term status must be determined based on Termination Date. See $termStatus
    // variable above.
    $form['status'] = [
      '#type' => 'details',
      '#title' => $this->t('Status'),
      '#description' => $this->t('Current lodge status of the officer.'),
      '#value' => '<div class="field-output">' . $agentStatusOptions[$termStatus] . '</div>',
    ];

    $form['cesta_status'] = [
      '#type' => 'details',
      '#title' => $this->t('Cesta Status'),
      '#description' => $this->t('Current Cesta status of the agent.'),
      '#value' => '<div class="field-output">' . ucfirst($agent->getStatus()) . '</div>',
    ];

    // If user has permissions, show fields for editing and saving edits.
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['promo']['apply_promo'] = [
        '#type' => 'radios',
        '#title' => $this->t('Apply Agent Promo'),
        '#title_display' => 'invisible',
        '#options' => $promoOptions,
        '#required' => true,
        '#default_value' => strtolower($agent->getApplyPromo()),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // Per https://rvos.teamwork.com/desk/#/tickets/1966599 this has to be
      // present. Was commented out with commit 07cd33f on 11/24/2017 but
      // should not have been.
      $form['agent_term']['agent_lodge_status'] = [
        '#type' => 'radios',
        '#title' => $this->t('Lodge Status'),
        '#options' => $agentStatusOptions,
        '#required' => true,
        '#default_value' => $termStatus,
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['agent_term']['took_office_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Took Office on'),
        '#required' => true,
        '#default_value' => $agent->getTookOfficeDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['agent_term']['termination_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Date Terminated'),
        '#default_value' => is_null($agent->getTerminationDate()) ? null : $agent->getTerminationDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
        '#states' => [
          'required' => [
            ':input[name="agent_lodge_status"]' => ['value' => 'terminated'],
          ],
          'visible' => [
            ':input[name="agent_lodge_status"]' => ['value' => 'terminated'],
          ],
        ],
      ];

      $form['agent_term']['agent_lodge_status'] = [
        '#type' => 'radios',
        '#title' => $this->t('Lodge Status'),
        '#options' => $agentStatusOptions,
        '#required' => true,
        '#default_value' => is_null($agent->getTerminationDate()) ? 'active' : 'terminated',
        '#description' => t('Setting to \'Active\' will remove \'Date Terminated\'.'),
        '#description_display' => 'before',
        '#field_prefix' => '<div class="container-inline">',
        '#field_suffix' => '</div>',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $saveChangesButtonText = $this->t('Save Changes');
      foreach (['promo', 'agent_term'] as $element) {
        $form[$element]['save_changes'] = [
          '#type' => 'submit',
          '#value' => $saveChangesButtonText,
          '#attributes' => [
            'class' => [
              'btn',
              'btn-disabled',
              'use-ajax-submit',
              'lodge-save',
            ],
          ],
          '#ajax' => [
            'wrapper' => 'lodge-agent-id',
            'effect' => 'fade',
            'progress' => ['type' => 'throbber', 'message' => $this->t('Please wait...')],
            'method' => 'replace',
          ],
        ];
      }
    }

    return $form;
  }

  public function getFormId() {
    return 'lodge_edit_agent';
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    if ($form_state->getValue('agent_lodge_status') == 'terminated' && empty($form_state->getValue('termination_date'))) {
      $form_state->setError($form['agent_term']['termination_date'], $this->t('%title is required.', ['%title' => $form['agent_term']['termination_date']['#title']]));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $xmlRpcLodgeAgent = new XmlRpcLodgeAgent(new XmlRpcQuery($this->lodgeService), LodgeAgent::createFromFormState($form_state));

    $response = $xmlRpcLodgeAgent->save();
    if (false != $response) {
      $agent = $response->getLodgeAgent();
      $message = $this->t('Lodge agent record for lodge %lodge and agent %agent saved successfully.', ['%lodge' => $form_state->getValue('lodge_name'), '%agent' => $form_state->getValue('agency')]);
      drupal_set_message($message);
      //return $this->redirect('lodge.viewagent', ['lodge_id' => $form_state->getValue('lodge_id'), 'agent_id' => $agent->getAgentId()]);
      return $form;
    }

    $message = $this->t('Could not save the lodge agent record for lodge %lodge and agent %agent.', ['%lodge' => $form_state->getValue('lodge_name'), '%agent' => $form_state->getValue('agency')]);
    drupal_set_message($message, 'error');
  }

  public function ajaxReturn(array $form, FormStateInterface $form_state) {
    $ajax_response = new AjaxResponse();
    if ($form_state->getValue()) {
      $opt = $form_state->getValue();
    }
    else {
      $opt = ' ';
    }

    $ajax_response->addCommand(new ReplaceCommand('#lodge-agent-id', $opt));
    $form_state->setRebuild(TRUE);
    $form->setRebuild(TRUE);
    return $ajax_response;
  }

}
