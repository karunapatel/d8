<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Value\Address;
use Drupal\lodge\Value\Contact;
use Drupal\lodge\Value\LodgeAgent;
use Drupal\lodge\Value\XmlRpcLodgeAgent;

/**
 * Description of AddAgentForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class AddAgentForm extends AbstractLodgeForm {
  
  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null) {

    if (is_null($lodge_id)) {
      drupal_set_message('Unable to find the lodge requested.', 'warning');
      return $this->redirect('lodge.list', [], [], 404);
    }

    $outputFormatter = \Drupal::service('lodge.outputformatter');
//    $test = $this->lodgeService->retrieveCestaAgents(['35278']);

    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $agentId = $form_state->getValue('agent_id');
    $selected = empty($agentId) ? 0 : $agentId;

    $hasCestaAgent = false;
    if (isset($selected) && !empty($selected)) {
      $xmlRpcAgent = $this->lodgeService->retrieveCestaAgents([$selected]);
      if (!is_null($xmlRpcAgent)) {
        $agent = $xmlRpcAgent->getLodgeAgent();
      }
      if ($agent instanceof LodgeAgent) {
        $hasCestaAgent = true;
      }
    }

    if (!isset($agent) || !$agent instanceof LodgeAgent) {
      $agent = new LodgeAgent();
    }

    if (is_null($agent->getTookOfficeDate())) {
      $agent->setTookOfficeDate(new DrupalDateTime());
    }

    $ddContainerClass = 'hidden';
    if (!empty($agent->getAgentId())) {
      $ddContainerClass = '';
    }
    
    $agents = $this->lodgeService->retrieveActiveAgents();
    $agentOptions = [];
    foreach ($agents as $record) {
      $agentName = $record['ENTY_NAME'];
      $agentOptions[$record['ENTY_CODE']] = $record['ENTY_CODE'] . ' - ' . $record['ENTY_NAME'];
    }
    $applyPromoOptions = ['yes' => $this->t('Yes'), 'no' => $this->t('No')];

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ];

    $form['lodge_id'] = [
      '#title' => $this->t('Lodge ID'),
      '#type' => 'hidden',
      '#required' => true,
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#title' => $this->t('Lodge name'),
      '#type' => 'hidden',
      '#required' => true,
      '#default_value' => $lodge->getLodgeName(),
    ];

    $form['agent_id'] = [
      '#title' => $this->t('Agent ID'),
      '#type' => 'select',
      '#required' => true,
//      '#description' => t('Please select an Agent.'),
      '#default_value' => $agentId,
      '#options' => $agentOptions,
      '#empty_value' => '_none',
      '#ajax' => [
        'callback' => [$this, 'lodge_ajax_agent_id_select_callback'],
        'wrapper' => 'dropdown-second-replace',
        'effect' => 'fade',
        'progress' => ['type' => 'throbber', 'message' => $this->t('Retrieving agent information...')],
        'event' => 'change',
        'method' => 'replace',
      ],
    ];

    $form['dropdown_second'] = [
      '#type' => 'container',
//      '#title' => $options_first[$selected] . ' is selected',
      '#prefix' => '<div id="dropdown-second-replace" class="' . $ddContainerClass . '">',
      '#suffix' => '</div>',
    ];

    if (!$hasCestaAgent) {
      $form['dropdown_second']['not_found'] = [
        '#type' => 'markup',
        '#markup' => '<div role="contentinfo" aria-label="Warning message" class="messages messages--warning"><h2 class="visually-hidden">Warning message</h2>No records found in Cesta.</div>',
      ];
    } elseif($hasCestaAgent) {
      $form['dropdown_second']['agency'] = [
        '#type' => 'item',
        '#title' => $this->t('Agency'),
        '#markup' => $agent->getBrokerageName(),
      ];

      $address = new Address($agent->getAddress(), $agent->getCity(), $agent->getState(), $agent->getZip(), $agent->getCountyName(), $agent->getZipExt());
      $form['dropdown_second']['agent_address'] = [
        '#type' => 'item',
        '#title' => $this->t('Address'),
        '#markup' => nl2br($outputFormatter->formatAddress($address)),
      ];

      $form['dropdown_second']['agent_email'] = [
        '#type' => 'item',
        '#title' => $this->t('E-mail'),
        '#markup' => !empty($agent) ? $agent->getEmailAddress() : '',
      ];

      if (!empty($agent->getWorkPhone())) {
        $form['dropdown_second']['agent_workphone'] = [
          '#type' => 'item',
          '#title' => $this->t('Work Phone'),
          '#markup' => !empty($agent) ? $outputFormatter->formatContact(new Contact('phone', $agent->getWorkPhone())) : '',
        ];
      }

      if (!empty($agent->getCellPhone())) {
        $form['dropdown_second']['agent_cellphone'] = [
          '#type' => 'item',
          '#title' => $this->t('Cell Phone'),
          '#markup' => !empty($agent) ? $outputFormatter->formatContact(new Contact('phone', $agent->getCellPhone())) : '',
        ];
      }

      if (!empty($agent->getFax())) {
        $form['dropdown_second']['agent_fax'] = [
          '#type' => 'item',
          '#title' => $this->t('Fax'),
          '#markup' => !empty($agent) ? $outputFormatter->formatContact(new Contact('phone', $agent->getFax())) : '',
        ];
      }

//      $form['dropdown_second']['agent_tax_id'] = [
//        '#type' => 'item',
//        '#title' => $this->t('Tax ID'),
//        '#markup' => !empty($agent) ? $agent->getTaxId() : '',
//      ];
    }

    $form['apply_promo'] = [
      '#title' => $this->t('Apply Agent Promo'),
      '#type' => 'radios',
      '#options' => $applyPromoOptions,
      '#default_value' => !empty($agent->getApplyPromo()) ? array_search($agent->getApplyPromo(), $applyPromoOptions) : 'yes',
    ];

    $form['took_office_date'] = [
      '#type' => 'date',
      '#title' => $this->t('Took office on'),
      '#required' => true,
      '#default_value' => !empty($agent) ? $agent->getTookOfficeDate('Y-m-d') : (new DrupalDateTime())->format('Y-m-d'),
    ];
    
    $form['agent_lodge_status'] = [
      '#title' => $this->t('Status at lodge'),
      '#type' => 'radios',
      '#options' => ['active' => $this->t('Active'), 'terminated' => $this->t('Terminated')],
      '#default_value' => !empty($agent) && is_null($agent->getTerminationDate()) ? 'active' : 'terminated',
    ];

    $form['termination_date'] = [
      '#type' => 'date',
      '#title' => $this->t('Date Terminated'),
      '#default_value' => !empty($agent) ? $agent->getTerminationDate('Y-m-d') : null,
      '#states' => [
        'visible' => [
          ':input[name="agent_lodge_status"]' => ['value' => 'terminated'],
        ],
        'required' => [
          ':input[name="agent_lodge_status"]' => ['value' => 'terminated'],
        ],
      ],
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#weight' => 50,
    ];
        
    $form['cancel'] = [
      '#type' => 'submit',
      //'#value' => $this->t('Cancel'),
      '#value' => $this->t('Cancel'),
      '#weight' => 51,
      //'#limit_validation_errors' => ['agent_id'],        // commented by synapseindia
      '#limit_validation_errors' => array([('lodge_id')]), // Added by synapseindia
      '#submit' => array([$this, 'cancelForm']),           // Added by synapseindia
      //'#submit' => array('\Drupal\lodge\Form\AddAgentForm::cancelForm'), // commented by synapseindia
    ];
   
    return $form;
  }

  public function getFormId() {
    return 'lodge_agent_add';
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Don't validate fields for the the agent selection ajax callback.
    if ($form_state->getTriggeringElement()['#name'] == 'agent_id') {
      return;
    }

    // Default validation (required fields and other default element validation)
    parent::validateForm($form, $form_state);

    // Add Agent specific form validation.
    if (!is_numeric($form_state->getValue('lodge_id'))) {
      $form_state->setError($form['id']['lodge_id'], $this->t('%title must be numeric.', ['%title' => $form['lodge_id']['#title']]));
    }
  
    if (!is_numeric($form_state->getValue('agent_id'))) {
      $form_state->setError($form['agent_id'], $this->t('%title must be numeric.', ['%title' => $form['agent_id']['#title']]));
    }

    $agent = $this->lodgeService->retrieveLodgeAgents($form_state->getValue('lodge_id'), $form_state->getValue('agent_id'));
    if (!empty($agent)) {
      $form_state->setError($form['agent_id'], $this->t('The agent "%agent_id" is already assigned to this lodge.', ['%agent_id' => $form_state->getValue('agent_id')]));
    }
 
    if ($form_state->getValue('agent_lodge_status') == 'terminated' && is_null($form_state->getValue('termination_date'))) {
      $form_state->setError($form['termination_date'], $this->t('%title is required.', ['%title' => $form['termination_date']['#title']]));
    }
  }

  public function cancelForm(array &$form, FormStateInterface $form_state) {
    $form_state->setRedirect('lodge.agents', ['lodge_id' => $form['lodge_id']['#value']]);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $xmlRpcLodgeAgent = new XmlRpcLodgeAgent(new XmlRpcQuery($this->lodgeService), LodgeAgent::createFromFormState($form_state));

    $response = $xmlRpcLodgeAgent->save();
    if (false != $response) {
      $agent = $response->getLodgeAgent();
      $message = $this->t('Lodge agent record for lodge %lodge and agent %agent saved successfully.', ['%lodge' => $form_state->getValue('lodge_name'), '%agent' => $form_state->getValue('dd_agency_value')]);
      drupal_set_message($message);
      return $form_state->setRedirect('lodge.viewagent', ['lodge_id' => $form_state->getValue('lodge_id'), 'agent_id' => $agent->getAgentId()]);
    }

    $message = $this->t('Could not save the lodge agent record for lodge %lodge and agent %agent.', ['%lodge' => $form_state->getValue('lodge_name'), '%agent' => $form_state->getValue('dd_agency_value')]);
    drupal_set_message($message, 'error');
  }

  public function lodge_ajax_agent_id_select_callback(array &$form, FormStateInterface $form_state) {
    return $form['dropdown_second'];
  }

}
