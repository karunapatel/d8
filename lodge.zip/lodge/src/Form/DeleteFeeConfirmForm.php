<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\lodge\Form\AbstractLodgeFormConfirm;
use Drupal\Core\Url;
use Drupal\lodge\Value\LodgeDues;
use Drupal\lodge\Value\XmlRpcLodgeDues;

/**
 * Description of DeleteFeeConfirmForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class DeleteFeeConfirmForm extends AbstractLodgeFormConfirm {

  protected $lodge;
  protected $xmlRpcLodgeDues;
  
  public function getCancelUrl() {
    return new Url('lodge.view', array('lodge_id' => $this->lodge->getLodgeId()));
  }

  public function getFormId() {
    return 'lodge_delete_lodge_fee';
  }

  public function getQuestion() {
    $fee = $this->xmlRpcLodgeDues->getLodgeDues();
    return $this->t('Are you sure you want to delete the lodge fee of %amount for the lodge %lodge?.', ['%amount' => $fee->getAmount(), '%lodge' => $this->lodge->getLodgeName()]);
  }

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $fee_id = null) {

    if (empty($fee_id) && !empty($lodge_id)) {
      drupal_set_message('Unable to delete the lodge dues.');
      $this->redirect('lodge.view', ['lodge_id' => $lodge_id]);
    }

    if (empty($fee_id) && empty($lodge_id)) {
      drupal_set_message('Unable to delete the lodge dues.');
      $this->redirect('lodge.list');
    }
    
    
    $this->lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $this->xmlRpcLodgeDues = $this->lodgeService->retrieveDues($lodge_id, $fee_id);
    
    // Line added by synapseindia
    $fee = $this->xmlRpcLodgeDues->getLodgeDues();
    $form['confirm_title'] = [
      '#type' => 'details',
      '#title' => $this->t('Are you sure you want to delete the lodge fee of %amount for the lodge %lodge?.', ['%amount' => $fee->getAmount(), '%lodge' => $this->lodge->getLodgeName()]),
    ]; // End line
    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $user = \Drupal::currentUser();
    if (!$user->hasPermission('administer site configuration') || !$user->hasPermission('manage lodges')) {
      drupal_set_message('Access denied! You do not have permissions to delete lodge dues.', 'error');
      return $form_state->setRedirect('lodge.view', ['lodge_id' => $form_state->getValue('lodge_id')]);
    }
    
    $fee = $this->xmlRpcLodgeDues->getLodgeDues();
    if (false != $response = $this->xmlRpcLodgeDues->delete()) {
      drupal_set_message($this->t("Lodge due was successfully deleted."));
    } else {
      drupal_set_message($this->t('Lodge due could not be deleted.'), 'error');
    }

    return $form_state->setRedirect('lodge.view', ['lodge_id' => $this->lodge->getLodgeId()]);
  }

}
