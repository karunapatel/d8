<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\ConfirmFormBase;

/**
 * Description of LodgeFormBase
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
abstract class AbstractLodgeFormConfirm extends ConfirmFormBase {
  protected $xmlRpcService;

  public function __construct() {
    $this->lodgeService = \Drupal::service('lodge.xmlrpc');
  }
}
