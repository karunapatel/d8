<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Value\Address;
use Drupal\lodge\Value\Contact;
use Drupal\lodge\Value\LodgeOfficer;
use Drupal\lodge\Value\XmlRpcLodgeOfficer;
use Drupal\Core\Ajax\AjaxResponse;  
use Drupal\Core\Ajax\ReplaceCommand;

/**
 * Description of EditOfficerForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class EditOfficerForm extends AbstractLodgeForm {
  
  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $officer_id = null) {

    $outputFormatter = \Drupal::service('lodge.outputformatter');
    $user = \Drupal::currentUser();
    $officer = $this->lodgeService->retrieveLodgeOfficer($officer_id)->getOfficer();
    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $officeTypeOptions = LodgeOfficer::getOfficeTypeNameMap();
    $statesOptions = $this->lodgeService->getStates();
    $countyOptions = $this->lodgeService->retrieveCounties();
    $officerStatusOptions = ['active' => $this->t('Active'), 'terminated' => $this->t('Terminated')];

    if (empty($officer)) {
      $officer = new LodgeOfficer();
    }

    $today = new \Drupal\Core\Datetime\DrupalDateTime();
    $officerStatus = 'current';
    if ((!is_null($officer->getTerminationDate()) && $officer->getTerminationDate() <= $today)) {
      $officerStatus = 'terminated';
    }

    /* $form['history_link'] = [
      '#type' => 'link',
      '#title' => $this->t('History'),
      '#attributes' => ['class' => ['history-link last']],
      '#url' => Url::fromRoute('lodge.officerhistory', ['lodge_id' => $lodge_id, 'officer_id' => $officer_id]),
    ];  */

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.officers', ['lodge_id' => $lodge_id, 'officer_status' => $officerStatus]),
    ];
    
    // This is a hidden field to be used in data processing. e.g. saving data
    // to the database.
    // It SHOULD NOT include HTML tags.
    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge name'),
      '#value' => $lodge->getLodgeName(),
      '#default_value' => $lodge->getLodgeName(),
    ];

    // This is a hidden field to be used in data processing. e.g. saving data
    // to the database.
    // It SHOULD NOT include HTML tags.
    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge->getLodgeId(),
    ];

    // This is a hidden field to be used in data processing. e.g. saving data
    // to the database.
    // It SHOULD NOT include HTML tags.
    $form['officer_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Officer ID'),
      '#default_value' => $officer->getOfficerId(),
    ];

   /*  $form['lid'] = [
      '#type' => 'details',
      '#title' => $this->t('Lodge ID'),
      '#description' => $this->t('ID of the lodge.'),
      '#value' => '<div class="field-output">'.$lodge->getLodgeId().'</div>',
    ]; */

    $form['oid'] = [
      '#type' => 'details',
      '#title' => $this->t('Officer ID'),
      '#description' => $this->t('ID of the officer.'),
      '#value' => '<div class="field-output">'.$officer->getOfficerId().'</div>',
    ];

    $prefix = '';
    $suffix = '';
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {
    $prefix = '<div class="detail-summary-group element-group-edit"><span class="details-summary-edit-toggle">change</span>';
    $suffix = '</div>';    
    }
    
    $form['officer_name'] = [
      '#type' => 'details',
      '#title' => $this->t('Name'),
      '#description' => $this->t('Full name of officer.'),
      '#value' => '<div class="field-output">'.$officer->getFullName().'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $address = new Address($officer->getAddress(), $officer->getCity(), $officer->getState(), $officer->getZip(), $officer->getCountyName(), $officer->getZipExt());
    $form['address'] = [
      '#type' => 'details',
      '#title' => $this->t('Address'),
      '#description' => $this->t('Mailing address.'),
      '#value' => '<div class="field-output">'.nl2br($outputFormatter->formatAddress($address)).'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $form['email'] = [
      '#type' => 'details',
      '#title' => $this->t('eMail'),
      '#description' => $this->t('eMail Address.'),
      '#value' => '<div class="field-output"><p class="email">'.$officer->getEmailAddress().'</p></div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $contacts = '';
    if (!empty($officer->getWorkPhone())) {
      $contacts .= '<p class="phone-work">Work: ' . $outputFormatter->formatContact(new Contact('phone', $officer->getWorkPhone())) . '</p>';
    }
    if (!empty($officer->getCellPhone())) {
      $contacts .= '<p class="phone-mobile">Cell: ' . $outputFormatter->formatContact(new Contact('phone', $officer->getCellPhone())) . '</p>';
    }
    if (!empty($officer->getFax())) {
      $contacts .= '<p class="phone-fax">Fax: ' . $outputFormatter->formatContact(new Contact('phone', $officer->getFax())) . '</p>';
    }
    $form['contact'] = [
      '#type' => 'details',
      '#title' => $this->t('Phone'),
      '#description' => $this->t('Contact information.'),
      '#value' => '<div class="field-output">'.$contacts.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $officeType = '';
    if (array_key_exists($officer->getOfficeTypeId(), $officeTypeOptions)) {
      $officeType = $officeTypeOptions[$officer->getOfficeTypeId()];
    } else {
      drupal_set_message($this->t(
        'The office type id "%office_type_id" was not found in the list of office types. Please update the list of office types and verify the office type id is correct.',
        [
          '%office_type_id' => $officer->getOfficeTypeId(),
        ]
      ));
      $officeType = $officer->getOfficeTypeId();
    }
    $form['office_type'] = [
      '#type' => 'details',
      '#title' => $this->t('Office'),
      '#description' => $this->t('Officer type.'),
      '#value' => '<div class="field-output">'.$officeType.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];
    
    $status = $officer->getStatus();
    if (in_array($status, ['inactive', 'terminated'])) {
      $status = 'terminated';
    } else {
      $status = 'active';
    }
    $termStatus = array_key_exists($status, $officerStatusOptions) ? $officerStatusOptions[$status] : $officerStatusOptions['active'];
    $form['term'] = [
      '#type' => 'details',
      '#title' => $this->t('Term'),
      '#description' => $this->t('Date officer took and left office.'),
      '#value' => '<div class="field-output">'.nl2br($outputFormatter->formatOfficeTerm($termStatus, $officer->getTookOfficeDate(), $officer->getTerminationDate())).'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];
    
    $form['status'] = [
      '#type' => 'details',
      '#title' => $this->t('Status'),
      '#description' => $this->t('Current lodge status of the officer.'),
      '#value' => '<div class="field-output">'.$termStatus.'</div>',
    ];
    
    // Requires admin or lodge permissions for the edit and save button elements.
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {

      $form['officer_name']['first_name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('First name'),
        '#required' => true,
        '#default_value' => $officer->getFirstName(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['officer_name']['middle_name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Middle name'),
        '#default_value' => $officer->getMiddleName(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['officer_name']['last_name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Last name'),
        '#required' => true,
        '#default_value' => $officer->getLastName(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['street'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Street / P.O. Box'),
        '#required' => true,
        '#default_value' => $officer->getAddress(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['city'] = [
        '#type' => 'textfield',
        '#title' => $this->t('City'),
        '#required' => true,
        '#default_value' => $officer->getCity(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['state'] = [
        '#type' => 'select',
        '#title' => $this->t('State'),
        '#options' => $statesOptions,
        '#required' => true,
        '#default_value' => $officer->getState(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['zip'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Zip'),
        '#required' => true,
        '#default_value' => $officer->getZip(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['zip_ext'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Zip Ext.'),
        '#default_value' => $officer->getZipExt(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['address']['county'] = [
        '#type' => 'select',
        '#title' => $this->t('County'),
        '#options' => $countyOptions,
        '#required' => true,
        '#default_value' => $officer->getCountyName(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['email']['email_address'] = [
        '#type' => 'email',
        //'#title' => $this->t('Email'),
        '#default_value' => $officer->getEmailAddress(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['contact']['work_phone'] = [
        '#type' => 'tel',
        '#title' => $this->t('Work Phone'),
        '#required' => true,
        '#default_value' => $officer->getWorkPhone(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['contact']['cell_phone'] = [
        '#type' => 'tel',
        '#title' => $this->t('Cell Phone'),
        '#default_value' => $officer->getCellPhone(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['contact']['fax'] = [
        '#type' => 'tel',
        '#title' => $this->t('Fax #'),
        '#default_value' => $officer->getFax(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['office_type']['office_type_id'] = [
        '#type' => 'select',
        '#title' => $this->t('Office Type'),
        '#title_display' => 'invisible',
        '#options' => $officeTypeOptions,
        '#required' => true,
        '#default_value' => $officer->getOfficeTypeId(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // Per https://rvos.teamwork.com/desk/#/tickets/1966599 this has to be
      // present. Was commented out with commit 07cd33f on 11/24/2017 but
      // should not have been.
      $form['term']['officer_status'] = [
        '#type' => 'radios',
        '#title' => $this->t('Status at Lodge'),
        '#required' => true,
        '#options' => $officerStatusOptions,
        '#default_value' => is_null($officer->getTerminationDate()) ? 'active' : 'terminated',
        '#description' => t('Setting to \'Active\' will remove \'Date Terminated\'.'),
        '#description_display' => 'before',
        '#field_prefix' => '<div class="container-inline">',
        '#field_suffix' => '</div>',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['term']['took_office_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Took Office on'),
        '#title_display' => 'before',
        '#required' => true,
        '#default_value' => $officer->getTookOfficeDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['term']['termination_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Date Terminated on'),
        '#default_value' => $officer->getTerminationDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
        '#states' => [
          'visible' => [
            ':input[name="officer_status"]' => ['value' => 'terminated'],
          ],
          'required' => [
            ':input[name="officer_status"]' => ['value' => 'terminated'],
          ],
        ],
      ];

      $editButtonText = $this->t('Save Changes');
      foreach (['term', 'office_type', 'contact', 'email', 'address', 'officer_name'] as $element) {
        $form[$element]['submit'] = [
          '#type' => 'submit',
          '#value' => $editButtonText,
          '#attributes' => [
            'class' => [         
              'btn',
              'btn-disabled',
              'use-ajax-submit',
              'lodge-save',
            ],
          ],
          '#ajax' => array(
            'wrapper' => 'lodge-officer-id',
            'effect' => 'fade',
            'progress' => ['type' => 'throbber', 'message' => $this->t('Please wait...')],
            'method' => 'replace',
          ),
        ];
      }
    }

    return $form;
  }

  public function getFormId() {
    return 'lodge_officer_edit';
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $status = $form_state->getValue('lodge_status');
    $terminationDate = $form_state->getValue('termination_date');
    if ($status === 'terminated' && is_null($terminationDate)) {
      $form_state->setError($form['term']['termination_date'], $this->t('%title is required.', ['%title' => $form['term']['termination_date']['#title']]));
    }

    if (is_numeric($form_state->getValue('city'))) {
      $form_state->setError($form['address']['city'], $this->t('%title cannot contain numbers.', ['%title' => $form['address']['city']['#title']]));
    }

    $workphone = $form_state->getValue('workphone');
    if (!empty($workphone) && !is_numeric($workphone)) {
      $form_state->setError($form['contact']['workphone'], $this->t('%title must be numeric.', ['%title' => $form['contact']['workphone']['#title']]));
    }

    $cellphone = $form_state->getValue('cellphone');
    if (!empty($cellphone) && !is_numeric($cellphone)) {
      $form_state->setError($form['contact']['cellphone'], $this->t('%title must be numeric.', ['%title' => $form['contact']['cellphone']['#title']]));
    }

    $fax = $form_state->getValue('fax');
    if (!empty($fax) && !is_numeric($fax)) {
      $form_state->setError($form['contact']['fax'], $this->t('%title must be numeric.', ['%title' => $form['contact']['fax']['#title']]));
    }

    $email = $form_state->getValue('email_address');
    if (!empty($email) && false === filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $form_state->setError($form['email']['email_address'], $this->t('%title is not a valid email address.', ['%title' => $form['email']['email_address']['#title']]));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $xmlRpcOfficer = new XmlRpcLodgeOfficer(new XmlRpcQuery($this->lodgeService), LodgeOfficer::createFromFormState($form_state));
    $response = $xmlRpcOfficer->save();
    $ajax_response = new AjaxResponse(); 
    $ajax_response->addCommand(new ReplaceCommand('#lodge-view-id', $form)); 
    if ($ajax_response) {
      drupal_set_message($this->t('The lodge record was successfully saved.'));
      //return $this->redirect('lodge.view', ['lodge_id' => $lodge->getLodgeId()]);
      
      return $ajax_response;
    }
   /*  if (false != $response) {
      $officer = $response->getOfficer();
      drupal_set_message($this->t('Lodge officer record successfully updated.'));
      //return $form_state->setRedirect('lodge.viewofficer', ['lodge_id' => $officer->getLodgeId(), 'officer_id' => $officer->getOfficerId()]);
      return $form;
    } */

    drupal_set_message($this->t('Could not update the lodge officer record.'), 'error');
  }
  
}
