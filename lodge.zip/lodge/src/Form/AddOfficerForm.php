<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Value\LodgeOfficer;
use Drupal\lodge\Value\XmlRpcLodgeOfficer;

/**
 * Description of AddOfficerForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class AddOfficerForm extends AbstractLodgeForm {

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $officer_id = null) {

    if (!is_null($officer_id)) {
      $officer = $this->lodgeService->retrieveLodgeOfficer($officer_id)->getOfficer();
      $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    }

    // We'll need an officer object, even if the attributes are empty.
    if (!isset($officer)) {
      $officer = new LodgeOfficer();
    }

    if (is_array($officer)) {
      $officer = null;
      drupal_set_message(
          $this->t('An error occurred loading the officer information. If this error persists please contact Computer Operations.'), 'error'
      );
      return $this->redirect('lodge.officers', ['lodge_id' => $lodge_id], array(), 302);
    }

    $lodges = $this->lodgeService->retrieveLodgeListing();
    $lodgeOptions = [];
    foreach ($lodges as $v) {
      $l = $v->getLodge();
      $lodgeOptions[$l->getLodgeId()] = $l->getLodgeId() . ' - ' . $l->getLodgeName();
    }

    $statesOptions = $this->lodgeService->getStates();
    $countyOptions = $this->lodgeService->retrieveCounties();
    $officeTypeOptions = LodgeOfficer::getOfficeTypeNameMap();
    $officerStatusOptions = ['active' => $this->t('Active'), 'terminated' => $this->t('Terminated')];

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ];

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => isset($lodge) ? $lodge->getLodgeName() : '',
    ];

    $form['first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('First name'),
      '#required' => true,
      '#size' => 20,
      '#maxlength' => 50,
      '#default_value' => isset($officer) ? $officer->getFirstName() : '',
    ];

    $form['middle_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Middle name'),
      '#size' => 20,
      '#maxlength' => 40,
      '#default_value' => isset($officer) ? $officer->getMiddleName() : '',
    ];

    $form['last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Last name'),
      '#required' => true,
      '#size' => 20,
      '#maxlength' => 50,
      '#default_value' => isset($officer) ? $officer->getLastName() : '',
    ];

    $form['street'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Street / P.O. Box'),
      '#size' => 30,
      '#maxlength' => 30,
      '#default_value' => isset($officer) ? $officer->getAddress() : '',
      '#required' => true,
    ];

    $form['city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#size' => 30,
      '#maxlength' => 30,
      '#default_value' => isset($officer) ? $officer->getCity() : '',
      '#required' => true,
    ];

    $form['state'] = [
      '#type' => 'select',
      '#title' => $this->t('State'),
      '#options' => $statesOptions,
      '#required' => true,
      '#default_value' => isset($officer) ? $officer->getState() : '',
      '#required' => true,
    ];

    $form['zip'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Zip'),
      '#size' => 6,
      '#maxlength' => 5,
      '#default_value' => isset($officer) ? $officer->getZip() : '',
      '#rules' => array('numeric'),
      '#required' => true,
    ];

    $form['zip_ext'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Zip Ext.'),
      '#size' => 5,
      '#maxlength' => 4,
      '#default_value' => isset($officer) ? $officer->getZipExt() : '',
      '#rules' => array('numeric'),
    ];

    $form['county'] = [
      '#type' => 'select',
      '#title' => $this->t('County'),
      '#required' => true,
      '#options' => $countyOptions,
      '#default_value' => isset($officer) ? $officer->getCountyName() : '',
    ];

    $form['email_address'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#default_value' => isset($officer) ? $officer->getEmailAddress() : '',
    ];

    $form['work_phone'] = [
      '#type' => 'tel',
      '#title' => $this->t('Work Phone'),
      '#required' => true,
      '#size' => 15,
      '#maxlength' => 10,
      '#filters' => ['numeric'],
      '#default_value' => isset($officer) ? $officer->getWorkPhone() : ''
    ];

    $form['cell_phone'] = [
      '#type' => 'tel',
      '#title' => $this->t('Cell Phone'),
      '#size' => 15,
      '#maxlength' => 10,
      '#filters' => ['numeric'],
      '#default_value' => isset($officer) ? $officer->getCellPhone() : ''
    ];

    $form['fax'] = [
      '#type' => 'tel',
      '#title' => $this->t('Fax #'),
      '#size' => 15,
      '#maxlength' => 10,
      '#filters' => ['numeric'],
      '#default_value' => isset($officer) ? $officer->getFax() : ''
    ];

    $form['office_type_id'] = [
      '#type' => 'select',
      '#title' => $this->t('Office Type'),
      '#required' => true,
      '#options' => $officeTypeOptions,
      '#default_value' => isset($officer) ? $officer->getOfficeTypeId() : '',
    ];

//    $form['tax_id_number'] = [
//      '#type' => 'textfield',
//      '#title' => $this->t('Tax ID'),
//      '#size' => 15,
//      '#maxlength' => 9,
//      '#default_value' => isset($officer) ? $officer->getTaxId() : '',
//      '#filters' => array('numeric'),
//    ];

    $form['officer_term']['date_took_office'] = [
      '#type' => 'date',
      '#title' => $this->t('Took Office on'),
      '#required' => true,
      '#default_value' => isset($officer) && !is_null($officer->getTookOfficeDate()) ? $officer->getTookOfficeDate('Y-m-d') : (new DrupalDateTime())->format('Y-m-d'),
    ];

    $form['officer_term']['officer_status'] = [
      '#type' => 'radios',
      '#title' => 'Status at Lodge',
      '#options' => $officerStatusOptions,
      '#default_value' => (isset($officer) && is_null($officer->getTerminationDate())) || !isset($officer) ? 'active' : 'terminated',
    ];

    $form['officer_term']['termination_date'] = [
      '#type' => 'date',
      '#title' => $this->t('Date Terminated'),
      '#default_value' => isset($officer) ? $officer->getTerminationDate('Y-m-d') : null,
      '#states' => [
        'visible' => [
          ':input[name="officer_status"]' => ['value' => 'terminated'],
        ],
        'required' => [
          ':input[name="officer_status"]' => ['value' => 'terminated'],
        ]
      ],
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#weight' => 50,
    ];

    $form['cancel'] = [
      '#type' => 'submit',
      '#value' => $this->t('Cancel'),
      '#limit_validation_errors' => [],
      '#submit' => array([$this, 'cancelForm']), // Added by synapseindia
      //'#submit' => ['\Drupal\lodge\Form\AddOfficerForm::cancelForm'],  // Commented by synapseindia
      '#weight' => 51,
    ];

    return $form;
  }

  public function getFormId() {
    return 'lodge_officer_add';
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $status = $form_state->getValue('officer_status');
    $terminationDate = $form_state->getValue('termination_date');
    if ($status == 'terminated') {
      if (is_null($terminationDate)) {
        $form_state->setError($form['officer_term']['termination_date'], $this->t('%title is required.', ['%title' => $form['officer_term']['termination_date']['#title']]));
      }
      
      $terminatedDate = new \DateTime($terminationDate);
      $tookOfficeDate = new \DateTime($form_state->getValue('date_took_office'));
      if ($terminatedDate < $tookOfficeDate) {
        $form_state->setError($form['officer_term']['termination_date'], $this->t('%title cannot be a date before the Took Office on date.', ['%title' => $form['officer_term']['termination_date']['#title']]));
      }
    }

    if (!is_numeric($form_state->getValue('lodge_id'))) {
      $form_state->setError($form['lodge_id'], $this->t('%title must be numeric.', ['%title' => $form['lodge_id']['#title']]));
    }

    if (!empty($form_state->getValue('city')) && is_numeric($form_state->getValue('city'))) {
      $form_state->setError($form['city'], $this->t('%title cannot contain numbers.', ['%title' => $form['city']['#title']]));
    }

    if (!empty($form_state->getValue('zip')) && !is_numeric($form_state->getValue('zip'))) {
      $form_state->setError($form['zip'], $this->t('%title must be numeric.', ['%title' => $form['zip']['#title']]));
    }

    if (!empty($form_state->getValue('zip_ext')) && !is_numeric($form_state->getValue('zip_ext'))) {
      $form_state->setError($form['zip_ext'], $this->t('%title must be numeric.', ['%title' => $form['zip_ext']['#title']]));
    }

    if ($form_state->getValue('officer_id') != '') {
      if (is_numeric($form_state->getValue('officer_id'))) {
        $officer = XmlRpcLodgeOfficer::createFromXmlRpc($this->lodgeService, $form_state->getValue('officer_id'))->getOfficer();
        if (!empty($officer)) {
          $form_state->setError($form['officer_id'], $this->t('%title already exists.', ['%title' => $form['officer_id']['#title']]));
        }
      }
      else {
        $form_state->setError($form['officer_id'], $this->t('%title must be numeric.', ['%title' => $form['officer_id']['#title']]));
      }
    }

    $workphone = $form_state->getValue('work_phone');
    if (!empty($workphone) && !is_numeric($workphone)) {
      $form_state->setError($form['work_phone'], $this->t('%title must be numeric.', ['%title' => $form['work_phone']['#title']]));
    }

    $cellphone = $form_state->getValue('cell_phone');
    if (!empty($cellphone) && !is_numeric($cellphone)) {
      $form_state->setError($form['cell_phone'], $this->t('%title must be numeric.', ['%title' => $form['cell_phone']['#title']]));
    }

    $fax = $form_state->getValue('fax');
    if (!empty($fax) && !is_numeric($fax)) {
      $form_state->setError($form['fax'], $this->t('%title must be numeric.', ['%title' => $form['fax']['#title']]));
    }

    $taxId = str_replace('-', '', $form_state->getValue('tax_id_number'));
    if (!empty($taxId) && !is_numeric($taxId)) {
      $form_state->setError($form['tax_id_number'], $this->t('%title is invalid.', ['%title' => $form['tax_id_number']['#title']]));
    }

    if ($form_state->getValue('email_address') != '' && false === filter_var($form_state->getValue('email_address'), FILTER_VALIDATE_EMAIL)) {
      $form_state->setError($form['email_address'], $this->t('%title is not a valid email address.', ['%title' => $form['email_address']['#title']]));
    }
  }

  public function cancelForm(array &$form, FormStateInterface $form_state) {
    $form_state->setRedirect('lodge.officers', ['lodge_id' => $form['lodge_id']['#value']]);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $officer = LodgeOfficer::createFromFormState($form_state);
    $xmlRpcLodgeOfficer = new XmlRpcLodgeOfficer(new XmlRpcQuery($this->lodgeService), $officer);

    $redirectArgs = ['lodge_id' => $form_state->getValue('lodge_id')];
    $terminatedDate = $officer->getTerminationDate();
    $today = DrupalDateTime::createFromDateTime(new \DateTime('today midnight'));
    $termintatedLink = (bool) ($terminatedDate < $today);

    if ($officer->getStatus() == 'inactive' && $termintatedLink) {
      $redirectArgs['officer_status'] = 'terminated';
    }

    if (false != $response = $xmlRpcLodgeOfficer->save()) {
      drupal_set_message($this->t('Lodge offficer record successfully created.'));
      return $form_state->setRedirect('lodge.officers', $redirectArgs);
    }

    drupal_set_message($this->t('Could not create lodge officer record.'), 'error');
  }

}
