<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\lodge\Form\AbstractLodgeForm;

/**
 * Description of ListOfficersForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class ListOfficersForm extends AbstractLodgeForm {


  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $officer_status = 'current') {

    //  Following code deletes test lodge officers for adding new officers.
//    $this->lodgeService->handle([
//      'Lodge.delete' =>
//      [
//        \Drupal::currentUser()->getAccountName(),
//        'LODGEOFFICER',
//        [
//          'OFFICER_ID=989783',
//          'LODGE_ID='.$lodge_id,
//        ]
//      ]
//    ]);

    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();

    $officers = [];
    $xmlRpcOfficers = $this->lodgeService->retrieveLodgeOfficers($lodge_id);

    if (is_array($xmlRpcOfficers) && !empty($xmlRpcOfficers)) {
      foreach ($xmlRpcOfficers as $xmlRpcOfficer) {
        $officers[] = $xmlRpcOfficer->getOfficer();
      }
    }

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];
    
    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ];
    
    $form['current_officer_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Current Officers'),
      '#attributes' => ['class' => ['current-officer-link last nouse']],
      '#url' => Url::fromRoute('lodge.officers', ['lodge_id' => $lodge_id, 'officer_status' => 'current']),
    ];
    
    $form['terminated_officer_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Terminated Officers'),
      '#attributes' => ['class' => ['terminated-officer-link last nouse']],
      '#url' => Url::fromRoute('lodge.officers', ['lodge_id' => $lodge_id, 'officer_status' => 'terminated']),
    ];
    
    $form['officers'] = [
      '#type' => 'fieldset',
      '#title' => ucfirst($officer_status) . ' Officers', /* Officer status added by synapseindia */
      '#description' => t('Lodge officers.'),
      '#open' => true,
    ];

    $form['officers']['active'] = [
      '#type' => 'table',
      '#caption' => t('Current Officers'),
      //'#header' => [t(ucfirst($officer_status) . ' Officers'), t('')],
      '#attributes' => ['class' => ['officergrid']],
      '#empty' => t('No officers were found assigned to this lodge.'),
    ];

    $form['officers']['inactive'] = $form['officers']['active'];
    $form['officers']['inactive']['#caption'] = t('Terminated Officers');

    foreach ($officers as $idx => $officer) {
      $today = DrupalDateTime::createFromDateTime(new \DateTime());
      if (!is_null($officer->getTerminationDate()) && $officer->getTerminationDate() <= $today) {
        $status = 'inactive';
      } else {
        $status = 'active';
      }
      $form['officers'][$status][$idx]['id'] = [
        '#title' => $officer->getFullName(),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'link',
        '#url' => Url::fromRoute('lodge.viewofficer', array('lodge_id' => $lodge_id, 'officer_id' => $officer->getOfficerId()))
      ];

      $form['officers'][$status][$idx]['office_type'] = [
        '#type' => 'item',
        '#markup' => ucfirst($officer->getOfficeTypeName()),
      ];
    }

    // Display only the officer status provided in the URL.
    if (strtolower($officer_status) == 'terminated') {
      unset($form['officers']['active']);
    }

    if (strtolower($officer_status) == 'current') {
      unset($form['officers']['inactive']);
    }

    return $form;
  }

  public function getFormId() {
    return 'lodge_officers_list';
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Should not be a submittable form.
  }

}
