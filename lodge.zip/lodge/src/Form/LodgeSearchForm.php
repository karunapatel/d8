<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of LodgeSearchForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeSearchForm extends AbstractLodgeForm {
  
  public function getFormId() {
    return 'lodge_search_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $search_text='') {

    $searchPhrase = !empty($search_text) && 'content' != $search_text ? $search_text : (
      !empty($form_state->getValue('search_filter_input'))
      && 'content' != $form_state->getValue('search_filter_input')
      ? $form_state['search_filter_input']
      : ''
    );

    $form['search_filter_input'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Search phrase'),
      '#required' => true,
      '#description' => $this->t('Enter the text to search for.'),
      '#placeholder' => 'Search by id, name, city, and/or county',
      '#default_value' => $searchPhrase,
    ];
    
    $form['submit_search'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
    ];

    $form['reset_search'] = [
      '#type' => 'submit',
      '#value' => $this->t('Reset'),
      '#submit' => [[$this, 'resetForm']],
      '#limit_validation_errors' => [],
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $phrases = explode(' ', preg_replace('/[^a-zA-Z0-9]/', ' ', $form_state->getValue('search_filter_input')));
    $searchCriteria = array_filter($phrases, function($phrase) {
      return $phrase;
    });

    if (!$searchCriteria) {
      if (count($searchCriteria) > 5) {
        $form_state->setErrorByName('search_filter_input', $this->t('Please limit your search phrases to five (5) terms or less.', ['@title' => $form['search_filter_input']['#title']]));
      }
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $form_state->setRedirect('lodge.search', ['search_text' => urlencode($form_state->getValue('search_filter_input'))]);
  }

  public function resetForm(array &$form, FormStateInterface $form_state) {
    $form_state->setRedirect('lodge.search', ['search_text' => 'content']);
  }

}
