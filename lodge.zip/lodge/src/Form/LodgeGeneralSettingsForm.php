<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\UrlHelper;

/**
 * Description of LodgeGeneralSettingsForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeGeneralSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['lodge.generalsettings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'lodge_general_settings';
  }

  /**
   * The lodge general settings form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form = parent::buildForm($form, $form_state);

    $config = $this->config('lodge.generalsettings');

    $form['lodge_xmlrpc_uri'] = array(
      '#title' => $this->t('XML-RPC Endpoint'),
      '#description' => $this->t('The endpoint to the Lodge XML-RPC service(s).'),
      '#type' => 'url',
      '#default_value' => $config->get('lodge_xmlrpc_uri'),
    );

    return $form;
  }

  /**
   * Handle the validation of the lodge general settings form.
   *
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if (!UrlHelper::isValid($form_state->getValue('lodge_xmlrpc_uri'))) {
      $form_state->setErrorByName(
          'lodge_xmlrpc_uri', $this->t('The XML-RPC URL endpoint you entered is invalid.')
      );
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * Handle the lodge general settings form submission.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory()->getEditable('lodge.generalsettings')
        ->set('lodge_xmlrpc_uri', $form_state->getValue('lodge_xmlrpc_uri'))
        ->save();

    parent::submitForm($form, $form_state);
  }

}
