<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\lodge\Form\AbstractLodgeForm;

/**
 * Description of ListAgentsForm
 *l
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class ListAgentsForm extends AbstractLodgeForm {

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $agent_status='all') {

    //  Following code deletes test lodge for adding new lodges.
//    $this->lodgeService->handle([
//      'Lodge.delete' =>
//      [
//        \Drupal::currentUser()->getAccountName(),
//        'LODGEAGENT',
//        [
//          'AGENT_ID=58883',
//          'LODGE_ID='.$lodge_id,
//        ]
//      ]
//    ]);

    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $xmlRpcAgents = $this->lodgeService->retrieveLodgeAgents($lodge_id);    
    $agents = [];
    if (count($xmlRpcAgents) > 1) {
      foreach ($xmlRpcAgents as $idx => $agent) {
        $agents[] = $agent;
      }
    } else {
        $agents[] = $xmlRpcAgents;
    }

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ];
    
    $form['current_agent_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Current Agents'),
      '#attributes' => ['class' => ['current-agent-link last nouse']],
      '#url' => Url::fromRoute('lodge.agents', ['lodge_id' => $lodge_id, 'agent_status' => 'current']),
    ];
    
    $form['terminated_agent_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Terminated Agents'),
      '#attributes' => ['class' => ['terminated-agent-link last nouse']],
      '#url' => Url::fromRoute('lodge.agents', ['lodge_id' => $lodge_id, 'agent_status' => 'terminated']),
    ];

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];

    $form['agents'] = [
      '#type' => 'fieldset',
      '#title' => ucfirst($agent_status) . ' Agents',
      '#description' => t('Lodge agents.'),
      '#open' => true,
    ];

    if (count($agents) > 0) {
      foreach ($agents as $idx => $record) {
        $agent = $record->getLodgeAgent();
      }
    }
    
    //$theader = (!empty($form_state) ? [t(''), t('Cesta Status')] : '');
    $form['agents']['active'] = [
      '#type' => 'table',
      '#caption' => t('Current Agents'),
      '#header' => [t(''), t('Cesta Status')],
      '#attributes' => ['class' => ['agentgrid']],
      '#empty' => t('No agents were found assigned to this lodge.'),
    ];

    $form['agents']['inactive'] = $form['agents']['active'];
    $form['agents']['inactive']['#caption'] = t('Terminated Agents');

    if (count($agents) > 0) {
      foreach ($agents as $idx => $record) {
        $agent = $record->getLodgeAgent();
        $today = DrupalDateTime::createFromDateTime(new \DateTime());
        if (!is_null($agent->getTerminationDate()) && $agent->getTerminationDate() <= $today) {
          $status = 'inactive';
        } else {
          $status = 'active';
        }
        $form['agents'][$status][$idx]['id'] = [
          '#title' => $agent->getName(),
          '#title_display' => 'invisible',
          '#attributes' => ['class' => []],
          '#type' => 'link',
          '#url' => Url::fromRoute('lodge.viewagent', array('lodge_id' => $lodge_id, 'agent_id' => $agent->getAgentId()))
        ];

        $form['agents'][$status][$idx]['agent_type'] = [
          '#type' => 'item',
          '#markup' => ucfirst($agent->getStatus()),
        ];
      }
    }

    // Display only the officer status provided in the URL.
    if (strtolower($agent_status) == 'terminated') {
      unset($form['agents']['active']);
    }

    if (strtolower($agent_status) == 'current') {
      unset($form['agents']['inactive']);
    }

    return $form;
  }

  public function getFormId() {
    return 'lodge_agents_list';
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // should not be a submittable form.
  }

}
