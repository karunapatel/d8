<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\lodge\Value\Lodge;
use Drupal\lodge\Value\XmlRpcLodge;
use Drupal\lodge\Value\LodgeDues;
use Drupal\lodge\Value\XmlRpcLodgeDues;
use Drupal\Core\Ajax\AjaxResponse;  
use Drupal\Core\Ajax\ReplaceCommand;

/**
 * Description of EditLodgeForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class EditLodgeForm extends AbstractLodgeForm {


  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null) {

    $user = \Drupal::currentUser();
    $defaults = !empty($form_state->getValues()) ? XmlRpcLodge::createFromFormState($form_state)->getLodge() : array();
    if (!empty($lodge_id)) {
      $defaults = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
      $fees = $this->lodgeService->retrieveDues($lodge_id);
      if (!is_array($fees) && !empty($fees)) {
        $fees = [$fees];
      }
    }

    $lodgeStatusOptions = ['active' => $this->t('Active'), 'disbanded' => $this->t('Disbanded')];
    $countyOptions = $this->lodgeService->retrieveCounties();
    $tierOptions = $this->lodgeService->retrieveTiers();
    $districtOptions = $this->lodgeService->retrieveDistricts();
    $applyLodgeRefundOptions = ['y' => $this->t('Yes'), 'n' => $this->t('No')];

    $statusString = 'Status: '.(array_key_exists($defaults->getLodgeStatus(), $lodgeStatusOptions) ? $lodgeStatusOptions[$defaults->getLodgeStatus()] : '');
    $statusString .= "\nOrganized: ".(is_null($defaults->getOrganizedDate()) ? '' : $defaults->getOrganizedDate('n/j/Y'));
    $statusString .= "\nDisbanded: ".(is_null($defaults->getDisbandedDate()) ? '' : $defaults->getDisbandedDate('n/j/Y'));
    
    $form['history_link'] = [
      '#type' => 'link',
      '#title' => $this->t('History'),
      '#attributes' => ['class' => ['history-link last nouse']],
      '#url' => Url::fromRoute('lodge.history', ['lodge_id' => $lodge_id]),
    ]; 
    
    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.list'),
    ]; 
    
    $form['lodge'] = [
      '#type' => 'details',
      '#title' => $this->t('ID'),
      '#description' => $this->t('Internal identifier for this lodge.'),
      '#value' => '<div class="field-output">'.$defaults->getLodgeId().'</div>',
    ];
    
    // Add Change/Hide prefix suffix according to user access
    $prefix = '';
    $suffix = '';
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {
    $prefix = '<div class="detail-summary-group element-group-edit"><span class="details-summary-edit-toggle">change</span>';
    $suffix = '</div>';    
    }
    
    $form['name'] = [
      '#type' => 'details',
      '#title' => $this->t('Name'),
      '#description' => $this->t('The name of the lodge.'),
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#value' => '<div class="field-output">'.$defaults->getLodgeName().'</div>',
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
        
    ];

	$foundedvalue = is_null($defaults->getOrganizedDate()) ? '' : $defaults->getOrganizedDate('n/j/Y');
    $form['founded'] = [
      '#type' => 'details',
      '#title' => $this->t('Organized Date'),
      '#description' => $this->t('The date the lodge was formed.'),
      '#value' => '<div class="field-output">'.$foundedvalue.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

	$countryvalue = array_key_exists($defaults->getCountyName(), $countyOptions) ? $countyOptions[$defaults->getCountyName()] : '';
    $form['county'] = [
      '#type' => 'details',
      '#title' => $this->t('County'),
      '#description' => $this->t('The county where the lodge is located.'),
      '#value' => '<div class="field-output">'.$countryvalue.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $form['tier'] = [
      '#type' => 'details',
      '#title' => $this->t('Tier'),
      '#description' => $this->t('The geographic assignment of the lodge.'),
      '#value' => '<div class="field-output">'.$defaults->getTierId().'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $form['district'] = [
      '#type' => 'details',
      '#title' => $this->t('District'),
      '#description' => $this->t('RVOS political assignment.'),
      '#value' => '<div class="field-output">'.$defaults->getDistrictId().'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

	$statusvalue = array_key_exists($defaults->getLodgeStatus(), $lodgeStatusOptions) ?
        $lodgeStatusOptions[$defaults->getLodgeStatus()] :
          (is_null($defaults->getDisbandedDate() ? $lodgeStatusOptions['active'] : $lodgeStatusOptions['disbanded'])
        );
    $form['status'] = [
      '#type' => 'details',
      '#title' => $this->t('Status'),
      '#description' => $this->t('Current status. Disbanded lodges will not be included in reporting.'),
      '#value' => '<div class="field-output">'.$statusvalue.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

	$refundvalue = array_key_exists($defaults->getApplyLodgeRefund(), $applyLodgeRefundOptions) ?
            $applyLodgeRefundOptions[$defaults->getApplyLodgeRefund()] :
            $applyLodgeRefundOptions['n'];
    $form['refund'] = [
      '#type' => 'details',
      '#title' => $this->t('Apply Lodge Refund'),
      '#description' => $this->t('Does the lodge participate in premium refund plan?'),
      '#value' => '<div class="field-output">'.$refundvalue.'</div>',
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    $form['dues_wrapper'] = [
      '#type' => 'container',
    ];

    $form['dues_wrapper']['dues'] = [
      '#type' => 'details',
      '#title' => $this->t('Dues'),
      '#description' => $this->t('Annual dues amount the lodge charges each member.'),
      '#prefix' => $prefix,
      '#suffix' => $suffix,
      '#ajax' => array(
          'callback' => '::submitForm',
      ),
    ];

    if (isset($fees) && (is_array($fees) && !empty($fees))) {
        $rows = array();
        foreach ($fees as $lodgeDues) {
          $record = $lodgeDues->getLodgeDues();
          $operations = '';
          if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {
            $operations = Link::fromTextAndUrl(t('Delete'), Url::fromRoute('lodge.deletefee', array('lodge_id' => $lodge_id, 'fee_id' => $record->getFeeId())));
          }
          $rows[] = [
            'due' => $record->getAmount(),
            'effective_date' => is_null($record->getEffectiveDate()) ? null : $record->getEffectiveDate('m/d/Y'),
            'operations' => $operations,
          ];
        }

        $form['dues_wrapper']['fees_table'] = [
          '#type' => 'table',
          //'#caption' => $this->t('Active Dues'),
          '#header' => ['Amount', 'Effective Date', ''],
          '#rows' => $rows,
          '#attributes' => ['class' => ['lodge-dues']],
          '#prefix' => '<div class="dues-table">',
          '#suffix' => '</div>',
        ];
      }

    // If the user has permissions to Edit/Create a new Lodge then it is safe
    // to add the elements to allow editing as well as the submit buttons to
    // save the the changes.
    if ($user->hasPermission('administer site configuration') || $user->hasPermission('manage lodges')) {

      $form['lodge_id'] = [
        '#type' => 'hidden',
        '#title' => $this->t('Lodge ID'),
        '#default_value' => $lodge_id,
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['name']['lodge_name'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Name'),
        '#title_display' => 'invisible',
        '#size' => 30,
        '#maxlength' => 30,
        '#required' => true,
        '#default_value' => $defaults->getLodgeName(), 
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',        
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['founded']['organized_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Date Organized'),
        '#title_display' => 'invisible',
        '#date_date_format' => 'Y-m-d',
        '#required' => true,
        '#default_value' => is_null($defaults->getOrganizedDate()) ? '' : $defaults->getOrganizedDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['county']['county_name'] = [
        '#type' => 'select',
        '#title' => $this->t('County'),
        '#title_display' => 'invisible',
        '#options' => $countyOptions,
        '#size' => 1,
        '#required' => true,
        '#default_value' => array_key_exists($defaults->getCountyName(), $countyOptions) ? $defaults->getCountyName() : '',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['tier']['tier_id'] = [
        '#type' => 'select',
        '#title' => $this->t('Tier'),
        '#title_display' => 'invisible',
        '#options' => $tierOptions,
        '#size' => 1,
        '#required' => true,
        '#default_value' => array_search($defaults->getTierId(), $tierOptions),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['district']['district_id'] = [
        '#type' => 'select',
        '#title' => $this->t('District'),
        '#title_display' => 'invisible',
        '#options' => $districtOptions,
        '#size' => 1,
        '#required' => true,
        '#default_value' => array_key_exists($defaults->getDistrictId(), $districtOptions) ? $defaults->getDistrictId() : '',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['status']['lodge_status'] = [
        '#type' => 'radios',
        '#title' => $this->t('Lodge Status'),
        '#title_display' => 'invisible',
        '#options' => $lodgeStatusOptions,
        '#default_value' => $defaults->getLodgeStatus(),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['status']['disbanded_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Date Disbanded'),
        '#default_value' => is_null($defaults->getDisbandedDate()) ? '' : $defaults->getDisbandedDate('Y-m-d'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
        '#states' => [
          'visible' => [
            ':input[name="lodge_status"]' => ['value' => 'disbanded'],
          ],
          'required' => [
            ':input[name="lodge_status"]' => ['value' => 'disbanded'],
          ],
        ],
      ];

      // According to WCAG 2.0 AA rules (http://www.w3.org/TR/UNDERSTANDING-WCAG20/minimize-error-cues.html)
      // you MUST HAVE a title for all form elements on a web page.
      // Also see https://www.section508.gov/content/build/website-accessibility-improvement/WCAG-conformance
      $form['refund']['apply_lodge_refund'] = [
        '#type' => 'radios',
        '#title' => $this->t('Apply Lodge Refund'),
        '#title_display' => 'invisible',
        '#options' => $applyLodgeRefundOptions,
        '#required' => true,
        '#default_value' => array_key_exists($defaults->getApplyLodgeRefund(), $applyLodgeRefundOptions) ? $defaults->getApplyLodgeRefund() : 'n',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['dues_wrapper']['dues']['add_dues'] = [
        '#title' => 'Add a new dues entry',
        '#type' => 'checkbox',
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
      ];

      $form['dues_wrapper']['dues']['container'] = [
        '#type' => 'container',
        '#states' => [
          'visible' => [
            ':input[name="add_dues"]' => ['checked' => true],
          ],
        ],
      ];

      $form['dues_wrapper']['dues']['container']['dues_amount'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Dues Amount'),
        //'#description' => $this->t('Enter the amount for the new dues.'),
        '#size' => 5,
        '#maxlength' => 4,
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
        '#states' => [
          'required' => [
            ':input[name="add_dues"]' => ['checked' => true],
          ],
        ],
      ];

      $form['dues_wrapper']['dues']['container']['dues_effective_date'] = [
        '#type' => 'date',
        '#title' => $this->t('Effective Date'),
        '#description' => $this->t('The new dues amount will become effective on the date entered.'),
        '#prefix' => '<div class="lodge-form-wrapper">',
        '#suffix' => '</div>',
        '#states' => [
          'required' => [
            ':input[name="add_dues"]' => ['checked' => true],
          ],
        ],
      ];

      $saveChangesButtonText = $this->t('Save Changes');
      foreach (['name', 'founded', 'county', 'tier', 'district', 'status', 'refund'] as $element) {
        $form[$element]['submit'] = [
          '#type' => 'submit',
          '#value' => $saveChangesButtonText,
          '#attributes' => [
            'class' => [         
              'btn',
              'btn-disabled',
              'use-ajax-submit',
              'lodge-save',
            ],
          ],
          '#ajax' => [
            'wrapper' => 'lodge-view-id',
            'effect' => 'fade',
            'progress' => ['type' => 'throbber', 'message' => $this->t('Please wait...')],
            'method' => 'replaceWith',
          ],   
        ];
      }

      $form['dues_wrapper']['dues']['submit'] = [
        '#type' => 'submit',
        '#value' => $saveChangesButtonText,
        '#states' => [
          'visible' => [
            ':input[name="new"]' => ['checked' => true],
          ],
        ],
        '#attributes' => [
            'class' => [         
              'btn',
              'btn-disabled',
              'use-ajax-submit',
              'lodge-save',
            ],
          ],
        '#ajax' => array(
          'wrapper' => 'lodge-view-id',
          'effect' => 'fade',
          'progress' => ['type' => 'throbber', 'message' => $this->t('Please wait...')],
          'method' => 'replaceWith',
          'url' => Url::fromRoute('<current>'),   // set this to the route of the view page
         // 'options' => ['query' => \Drupal::request()->query->all() + [FormBuilderInterface::AJAX_FORM_REQUEST => TRUE]],
        ),
      ];
    }
    return $form;
    
  }

  public function getFormId() {
    return 'lodge_edit_lodge';
  }
  
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    if (0 === preg_match('/^[a-zA-Z\d,-_.\s#\'\&()]{1,30}$/', $form_state->getValue('lodge_name'))) {
      $form_state->setError($form['name']['lodge_name'], $this->t('%title contains invalid characters.', array('%title' => $form['name']['lodge_name']['#title'])));
    }

    try {
      $organizedDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('organized_date')));
    } catch (\Exception $e) {
      $form_state->setError($form['organized_date'], $this->t('%title is not a valid date.', array('%title' => $form['organized_date']['#title'])));
    }

    if ($form_state->getValue('add_dues') == true) {
      $amount = $form_state->getValue('dues_amount');
      if (empty($amount) || !is_numeric($form_state->getValue('dues_amount'))) {
        $form_state->setError($form['dues_amount'], $this->t('%title cannot be empty and must be numeric.', array('%title' => $form['dues_amount']['#title'])));
      }

      try {
        $effectiveDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('dues_effective_date')));
      } catch (\Exception $e) {
        $form_state->setError($form['dues_effective_date'], $this->t('%title is not a valid date.', array('%title' => $form['dues_effective_date']['#title'])));
      }
    }

  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Create a new lodge dues record if necessary.
    if ($form_state->getValue('add_dues') == true) {

      $lodgeDues =  LodgeDues::createFromFormState($form_state);      
      $xmlRpcLodgeDues = new XmlRpcLodgeDues($this->lodgeService, $lodgeDues);
      $duesResponse = $xmlRpcLodgeDues->save();

      if (false == $duesResponse) {
        drupal_set_message($this->t('The lodge dues were not saved.'), 'error');
      } else {
        drupal_set_message($this->t('The lodge dues have been saved successfully.'));
      }
    }

    // Update the Lodge record.
    $lodge = Lodge::createFromFormState($form_state);
    $xmlRpcLodge = new XmlRpcLodge(new XmlRpcQuery($this->lodgeService), $lodge);
    $response = $xmlRpcLodge->save(); 
    $ajax_response = new AjaxResponse(); 
    $ajax_response->addCommand(new ReplaceCommand('#lodge-view-id', $form));    
    
    if ($ajax_response) {
      drupal_set_message($this->t('The lodge record was successfully saved.'));
      //return $this->redirect('lodge.view', ['lodge_id' => $lodge->getLodgeId()]);
      return $ajax_response;
    }

    drupal_set_message($this->t('The lodge record was not saved.'), 'error');
    
  }
  
  /* public function ajaxReturn(array $form, FormStateInterface $form_state) {
    $ajax_response = new AjaxResponse();
    if ($form_state->getValue()) {
       $opt = $form_state->getValue();
     } else {
       $opt = ' ';
     }

    $ajax_response->addCommand(new ReplaceCommand('#lodge-view-id', $opt));
    $form_state->setRebuild(TRUE);
    $form->setRebuild(TRUE);
    //$form['#attached']['library'][] = 'lodge/lodge';
    return $ajax_response;
  }  */ 

}

 