<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Form\AbstractLodgeForm;

/**
 * Description of AgentHistoryForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class AgentHistoryForm extends AbstractLodgeForm {
  
  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null, $agent_id = null) {
    if (empty($lodge_id)) {
      drupal_set_message($this->t('The lodge id is required.'));
      $this->redirect('lodge.list', [], [], 404);
    }

    if (empty($agent_id)) {
      drupal_set_message($this->t('The agent id is required.'));
      $this->redirect('lodge.agents', ['lodge_id' => $lodge_id], [], 404);
    }

    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $agent = $this->lodgeService->retrieveLodgeAgents($lodge_id, $agent_id)->getLodgeAgent();
    $history = $this->lodgeService->retrieveLodgeAgentHistory($lodge_id, $agent_id);
    if (is_null($agent->getTerminationDate())) {
      $agentStatus = 'terminated';
    } else {
      $agentStatus = 'current';
    }

    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse']],
      '#url' => Url::fromRoute('lodge.agents', ['lodge_id' => $lodge_id, 'agent_status' => $agentStatus]),
    ];
    
    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];
    
    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];

    $form['agent_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Agent ID'),
      '#default_value' => $agent->getAgentId(),
    ];

    $form['agent_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Agent Name'),
      '#default_value' => $agent->getName(),
    ];

    if (empty($history)) {
      return [
        'results' => [
          '#type' => 'markup',
          '#markup' => 'No changes have been made to this officer',
        ],
      ];
    }

    $idx = 0;
    foreach ($history as $i => $record) {
      $form['records'][$i] = [
        '#type' => 'table',
        '#header' => [
          $this->getTitleFromFieldName('HISTORY_ID'),
          $this->getTitleFromFieldName('TIMESTAMP'),
          $this->getTitleFromFieldName('USER_ID'),
        ],
      ];

      $form['records'][$i][$idx]['hid'] = [
        '#title' => $this->getTitleFromFieldName('HISTORY_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['HISTORY_ID'],
      ];

      $form['records'][$i][$idx]['timestamp'] = [
        '#title' => $this->getTitleFromFieldName('TIMESTAMP'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['TIMESTAMP'],
      ];

      $form['records'][$i][$idx]['uid'] = [
        '#title' => $this->getTitleFromFieldName('USER_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['USER_ID'],
      ];

      foreach ($record['CHANGES'] as $changeIdx => $changes) {
        $idx++;
        $headers = [];
        $form['records'][$i][$idx]['changes'] = [
          '#type' => 'table',
          '#wrapper_attributes' => ['colspan' => 3],
        ];

        foreach ($changes as $k => $v) {
          $headers[] = ucwords($this->getTitleFromFieldName($k));
          $form['records'][$i][$idx]['changes'][$changeIdx][strtolower($k)] = [
            '#title' => $this->getTitleFromFieldName($k),
            '#title_display' => 'invisible',
            '#attributes' => ['class' => []],
            '#type' => 'item',
            '#markup' => $v,
            '#prefix' => '<div class="officer-history-page officer-history-page-result">',
            '#suffix' => '</div>',
          ];
        }

        $form['records'][$i][$idx]['changes']['#header'] = $headers;
      }
      $idx++;
    }

    return $form;

   }

  public function getFormId() {
    return 'lodge_agent_history';
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

  public function getTitleFromFieldName($fieldName) {
    $a = [
      'HISTORY_ID' => $this->t('History ID'),
      'TIMESTAMP' => $this->t('Timestamp'),
      'USER_ID' => $this->t('User ID'),
      'PREVIOUS_LODGE_ID' => $this->t('Previous Lodge ID'),
      'NEW_LODGE_ID' => $this->t('New Lodge ID'),
      'PREVIOUS_APPLY_PROMO' => $this->t('Previous Apply Promo'),
      'NEW_APPLY_PROM' => $this->t('New Apply Promo'),
      'PREVIOUS_TOOK_OFFICE_DATE' => $this->t('Previous Took Office Date'),
      'NEW_TOOK_OFFICE_DATE' => $this->t('New Took Office Date'),
      'PREVIOUS_TERMINATION_DATE' => $this->t('Previous Termination Date'),
      'NEW_TERMINATION_DATE' => $this->t('New Termination Date'),
    ];
    if (array_key_exists($fieldName, $a)) {
      return $a[$fieldName];
    }
    return $fieldName;
  }

}
