<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\lodge\Form\AbstractLodgeForm;

/**
 * Description of ListLodgesForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class ListLodgesForm extends AbstractLodgeForm {

  public function getFormId() {
    return 'lodge_list_lodges';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $results = $this->lodgeService->retrieveLodgeListing();

//  Following code deletes test lodge for adding new lodges.
//    $this->lodgeService->handle([
//      'Lodge.delete' =>
//      [
//        \Drupal::currentUser()->getAccountName(),
//        'LODGE',
//        'LODGE_ID=998',
//      ]
//    ]);
    
    $form['lodges'] = array(
      '#type' => 'table',
      //'#header' => array(t('ID'), t('Name'), t('Status')),
      '#attributes' => ['class' => ['lodgegrid']],
    );

    foreach ($results as $idx => $record) {
      $lodge = $record->getLodge();
      $viewLodgeURL = Url::fromRoute('lodge.view', array('lodge_id' => $lodge->getLodgeId()));
      $form['lodges'][$idx]['id'] = [
        '#title' => $lodge->getLodgeId(),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => ['lodgenumber']],
        '#type' => 'link',
        '#url' => $viewLodgeURL,
      ];

      $form['lodges'][$idx]['name'] = [
        '#title' => $lodge->getLodgeName(),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => ['lodgename']],
        '#type' => 'link',
        '#url' => $viewLodgeURL,
      ];
	  
      $statusclass = $lodge->getLodgeStatus();
      $form['lodges'][$idx]['status'] = [
        '#title' => $lodge->getLodgeStatus(),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => ['lodgestatus', 'status-'.$statusclass]],
        '#type' => 'link',
        '#url' => $viewLodgeURL,
      ];
    }

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Nothing to do here.
  }

}
