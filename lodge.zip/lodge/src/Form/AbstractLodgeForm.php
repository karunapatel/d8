<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormBase;

/**
 * Description of LodgeFormBase
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
abstract class AbstractLodgeForm extends FormBase {
  protected $xmlRpcService;

  public function __construct() {
    $this->lodgeService = \Drupal::service('lodge.xmlrpc');
  }
}
