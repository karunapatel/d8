<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\lodge\Form\AbstractLodgeForm;
use Drupal\Core\Url;

/**
 * Description of LodgeHistoryForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeHistoryForm extends AbstractLodgeForm {

  public function buildForm(array $form, FormStateInterface $form_state, $lodge_id = null) {

    if (empty($lodge_id)) {
      return [
        'lodges' => [
          '#type' => 'markup',
          '#markup' => 'A lodge id was not provided. Please provide a lodge id.',
          '#prefix' => '<div class="lodge-history-page">',
          '#suffix' => '</div>',
        ],
      ];
    }

    // Order
    $order = 'HISTORY_ID DESC';
    // Retrieve the data
    $lodge = $this->lodgeService->retrieveLodge($lodge_id)->getLodge();
    $results = $this->lodgeService->retrieveLodgeHistory($lodge_id, $order);

    $form['lodge_id'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge ID'),
      '#default_value' => $lodge_id,
    ];

    $form['lodge_name'] = [
      '#type' => 'hidden',
      '#title' => $this->t('Lodge Name'),
      '#default_value' => $lodge->getLodgeName(),
    ];
    
    $form['back_link'] = [
      '#type' => 'link',
      '#title' => $this->t('Back'),
      '#attributes' => ['class' => ['back-link last nouse'], 'id' => ['edit-back-link']],
      '#url' => Url::fromRoute('lodge.view', ['lodge_id' => $lodge_id]),
    ]; 

    if (empty($results)) {
      $form['lodges'] = [
          '#type' => 'markup',
          '#markup' => 'No changes have been made to this lodge.',
          '#prefix' => '<div class="lodge-history-page">',
          '#suffix' => '</div>',
      ];
        
      return $form;
    }

    $idx = 0;
    foreach ($results as $i => $record) {

      $form['lodges'][$i] = [
        '#type' => 'table',
        '#header' => [
          $this->getTitleFromFieldName('HISTORY_ID'),
          $this->getTitleFromFieldName('TIMESTAMP'),
          $this->getTitleFromFieldName('USER_ID'),
        ],
        '#prefix' => '<div class="lodge-history-page lodge-history-page-top">',
        '#suffix' => '</div>',
      ];

      $form['lodges'][$i][$idx]['hid'] = [
        '#title' => $this->getTitleFromFieldName('HISTORY_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['HISTORY_ID'],
      ];

      $form['lodges'][$i][$idx]['timestamp'] = [
        '#title' => $this->getTitleFromFieldName('TIMESTAMP'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['TIMESTAMP'],
      ];

      $form['lodges'][$i][$idx]['uid'] = [
        '#title' => $this->getTitleFromFieldName('USER_ID'),
        '#title_display' => 'invisible',
        '#attributes' => ['class' => []],
        '#type' => 'item',
        '#markup' => $record['USER_ID'],
      ];

      foreach ($record['CHANGES'] as $changeIdx => $changes) {
        $idx++;
        $headers = [];
        $form['lodges'][$i][$idx]['changes'] = [
          '#type' => 'table',
          '#wrapper_attributes' => ['colspan' => 3],
        ];

        foreach ($changes as $k => $v) {
          $headers[] = ucwords(strtolower(preg_replace('/_/', ' ', $k)));
          $form['lodges'][$i][$idx]['changes'][$changeIdx][strtolower($k)] = [
            '#title' => $this->getTitleFromFieldName($k),
            '#title_display' => 'invisible',
            '#attributes' => ['class' => []],
            '#type' => 'item',
            '#markup' => $v,
            '#prefix' => '<div class="lodge-history-page lodge-history-page-result">',
            '#suffix' => '</div>',
          ];
        }

        $form['lodges'][$i][$idx]['changes']['#header'] = $headers;
      }
      $idx++;
    }

    return $form;
  }

  public function getTitleFromFieldName($fieldName) {
    $a = [
      'HISTORY_ID' => $this->t('History ID'),
      'TIMESTAMP' => $this->t('Timestamp'),
      'USER_ID' => $this->t('User ID'),
      'PREVIOUS_LODGE_ID' => $this->t('Previous Lodge ID'),
      'NEW_LODGE_ID' => $this->t('New Lodge ID'),
      'PREVIOUS_NAME' => $this->t('Previous Name'),
      'NEW_NAME' => $this->t('New Name'),
      'PREVIOUS_ORGANIZED_DATE' => $this->t('Previous Organized Date'),
      'NEW_ORGANIZED_DATE' => $this->t('New Organized Date'),
      'PREVIOUS_COUNTY_NAME' => $this->t('Previous County Name'),
      'NEW_COUNTY_NAME' => $this->t('New County Name'),
      'PREVIOUS_TIER_NAME' => $this->t('Previous Tier Name'),
      'NEW_TIER_NAME' => $this->t('New Tier Name'),
      'PREVIOUS_DISTRICT_NAME' => $this->t('Previous District Name'),
      'NEW_DISTRICT_NAME' => $this->t('New District Name'),
      'PREVIOUS_APPLY_LODGE_REFUND' => $this->t('Previous Apply Lodge Refund'),
      'NEW_APPLY_LODGE_REFUND' => $this->t('New Apply Lodge Refund'),
      'PREVIOUS_STATUS' => $this->t('Previous Status'),
      'NEW_STATUS' => $this->t('New Status'),
      'PREVIOUS_DISBANDED_DATE' => $this->t('Previous Disbanded Date'),
      'NEW_DISBANDED_DATE' => $this->t('New Disbanded Date'),
    ];
    if (array_key_exists($fieldName, $a)) {
      return $a[$fieldName];
    }
  }

  public function getFormId() {
    return 'lodge_lodge_history';
  }

  public function submitForm(array &$form, FormStateInterface $form_state, $lodge_id = null) {
    // This is not a submitable form.
  }

}
