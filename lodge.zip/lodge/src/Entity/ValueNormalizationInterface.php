<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Entity;

/**
 * Description of ValueNormalizerInterface
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
interface ValueNormalizationInterface {
  public function normalize($value);
}
