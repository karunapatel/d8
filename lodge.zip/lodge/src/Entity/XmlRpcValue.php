<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Entity;

use Drupal\lodge\Entity\ValueNormalizationInterface;

/**
 * Description of XmlRpcValue
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcValue {

  /**
   * ValueNormalizationInterface object.
   *
   * @var ValueNormalizationInterface
   */
  protected $normalizer = null;

  /**
   * Value to normalize.
   * @var type
   */
  protected $value;

  /**
   * Default constructor.
   *
   * @param ValueNormalizerInterface $normalizer
   */
  public function __construct(ValueNormalizationInterface $normalizer) {
    $this->normalizer = $normalizer;
  }

  /**
   * Sets the value to normalize.
   *
   * @param mixed $value
   * @return ValueNormalizationInterface $this
   */
  public function setValue($value) {
    $this->value = $value;
    return $this;
  }

  /**
   * Returns the original value.
   *
   * @return mixed The original, raw, unprocessed, value.
   */
  public function getRawValue() {
    return $this->value;
  }

  /**
   * Normalizes the value.
   *
   * @return mixed The normalized value.
   */
  public function normalize() {
    return $this->normalizer->normalize($this->value);
  }

}
