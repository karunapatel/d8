<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Entity;

use Drupal\lodge\Entity\ValueNormalizationInterface;

/**
 * Description of DateTimeNormalization
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class DateTimeNormalization implements ValueNormalizationInterface {

  protected $inFormat;

  public function __construct($inFormat) {
    $this->inFormat = $inFormat;
  }

  public function normalize($value='') {
    if (empty($value) || !$value) {
      return null;
    }
    return \DateTime::createFromFormat($this->inFormat, $value);
  }
}
