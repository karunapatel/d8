<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Entity;

use Drupal\lodge\Service\XmlRpcLodgeService;


/**
 * Description of XmlRpcQuery
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcQuery {

  /**
   * The lodge web service object.
   *
   * @var XmlRpcLodgeService
   */
  protected $service = null;

  /**
   * Query array structure for querying the lodge web service.
   *
   * @var array
   */
  protected $query = null;

  /**
   * The XML-RPC query result array.
   *
   * @var array
   */
  protected $results = null;

  /**
   * Default constructor;
   *
   * @param \Drupal\lodge\Service\XmlRpcLodgeService $service
   */
  public function __construct(XmlRpcLodgeService $service) {
    $this->service = $service;
    return $this;
  }

  /**
   * Gets the XML-RPC service object.
   *
   * @return \Drupal\lodge\Service\XmlRpcLodgeService object.
   */
  public function getService() {
    return $this->service;
  }

  /**
   * Free up the query and results by setting both to null. Allows reuse of this
   * object without having to worry about accidentally retrieving incorrect data
   * or results already stored locally.
   *
   * @return null
   */
  public function freeQuery() {
    $this->query = null;
    $this->results = null;
  }

  /**
   * Prepares the XML-RPC callback.
   *
   * @param type $callback  The callback function.
   * @param type $type      The callback subtype.
   * @param type $select    The fields to select.
   * @param array $filters  The fields to filter on.
   * @param array $join     The tables to join and what fields to join on.
   * @param string $order   The order by clause.
   * @return $this          This object.
   */
  public function prepare($callback, $type = null, array $select = ['*'], array $filters = array(), array $join = array(), $order = '') {
    $where = empty($filters) ? '' : (count($filters) > 1 ? $filters : array_pop($filters));
    if (is_null($type) || strlen($type) < 1) {
      if (empty($where)) {
        $this->query = [$callback => []];
      } else {
        $this->query = [$callback => [$where]];
      }
    } else {
      $this->query = [$callback => [$type, $select, $where, $join, $order]];
    }
    return $this;
  }

  /**
   * Executes the XML-RPC callback created by prepare().
   * @return $this
   */
  public function execute() {
    if (is_null($this->query)) {
      $this->results = [];
    }
    $this->results = $this->service->handle($this->query);
    return $this;
  }

  /**
   * Fetches the results stored locally when execute() was run.
   *
   * @return array.
   */
  public function fetch() {
    if (is_null($this->results) && !is_null($this->query)) {
      $this->execute();
    }
    
    return $this->results;
  }
}
