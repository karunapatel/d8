<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'Lodge Search form' block.
 *
 * @Block(
 *   id = "lodge_search_block",
 *   admin_label = @Translation("Lodge Search Block"),
 *   category = @Translation("Lodge")
 * )
 */
class LodgeSearchBlock extends BlockBase {

  public function build() {
    $form = \Drupal::formbuilder()->getForm('Drupal\lodge\Form\LodgeSearchForm');
    return $form;
  }

}
