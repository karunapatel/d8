<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Description of LodgeOfficerController
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeOfficerController extends ControllerBase {

  public function all($lodge_id, $officer_status = 'all') {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\ListOfficersForm', $lodge_id, $officer_status);

    return [
      '#title' => $this->t('Officers'),
      '#theme' => 'lodge_assigned_list',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function add($lodge_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\AddOfficerForm', $lodge_id);

    return [
      '#title' => $this->t('Add an Officer'),
      '#theme' => 'lodge_officer_create',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function edit($lodge_id, $officer_id) {    

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditOfficerForm', $lodge_id, $officer_id);

    return [
      '#title' => $this->t('Edit Lodge Officer'),
      '#theme' => 'lodge_officer_edit',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];

  }

  public function view($lodge_id, $officer_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditOfficerForm', $lodge_id, $officer_id);

    return [
      '#title' => $this->t('View Lodge Officer'),
      '#theme' => 'lodge_officer_view',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function history($lodge_id, $officer_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\OfficerHistoryForm', $lodge_id, $officer_id);

    return [
      '#title' => $this->t('View Officer History'),
      '#theme' => 'lodge_officer_history',
      '#data' => [
        'officerName' => $form['officer_name']['#default_value'],
        'officerId' => $officer_id,
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];

  }

}
