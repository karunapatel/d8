<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Controller;

/**
 * Description of LodgeSearchController
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeSearchController {

  public function index($search_text='') {

    $results = [];
    $lodgeService = \Drupal::service('lodge.xmlrpc');
    if (empty($search_text) || $search_text != 'content') {
      $results = $lodgeService->search($search_text);
    }

    if (empty($results) && (!empty($search_text) && $search_text != 'content')) {
      $message = t('We\'re sorry but we were unable to find anything matching the search phrase you entered.');
    } elseif (empty($results)) {
      $message = t('Please enter text into the "Search phrase" box and click the "Search" button to begin your search.');
    } else {
      $message = t('Found @total results containing "@search".', ['@total' => count($results), '@search' => $search_text]);
    }

    $form = \Drupal::formbuilder()->getForm('Drupal\lodge\Form\LodgeSearchForm', $search_text);

    return [
      '#theme' => 'lodge_search',
      '#data' => [
        'form' => $form,
        'results' => $results,
        'message' => $message,
      ],
    ];
  }
}
