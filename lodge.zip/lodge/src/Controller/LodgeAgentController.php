<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Description of LodgeAgentController
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeAgentController extends ControllerBase {

  public function all($lodge_id, $agent_status = 'all') {
    
    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\ListAgentsForm', $lodge_id, $agent_status);

    return [
      '#title' => $this->t('Agents'),
      '#theme' => 'lodge_assigned_list',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function add($lodge_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\AddAgentForm', $lodge_id);

    return [
      '#title' => $this->t('Add a Lodge Agent'),
      '#theme' => 'lodge_agent_create',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function view($lodge_id, $agent_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditAgentForm', $lodge_id, $agent_id);
    $form['id']['agent_id']['#disabled'] = true;

    return [
      '#title' => t('View Lodge Agent'),
      '#theme' => 'lodge_agent_view',
      '#data' => [        
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function edit($lodge_id, $agent_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditAgentForm', $lodge_id, $agent_id);

    return [
      '#title' => t('Edit Lodge Agent'),
      '#theme' => 'lodge_agent_edit',
      '#data' => [        
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

  public function history($lodge_id, $agent_id) {    

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\AgentHistoryForm', $lodge_id, $agent_id);

    return [
      '#title' => t('Lodge Agent History'),
      '#theme' => 'lodge_agent_history',
      '#data' => [        
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_id']['#default_value'],
        'agentId' => $form['agent_id']['#default_value'],
        'agentName' => $form['agent_name']['#default_value'],
        'form' => $form,
      ],
    ];
  }

}
