<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Description of LodgeController
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeController extends ControllerBase {

  public function all() {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\ListLodgesForm');

    return array(
      '#title' => t('Lodges'),
      '#theme' => 'lodge_list',      
      '#data' => [
        'form' => $form,
      ],
    );
  }

  public function view($lodge_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditLodgeForm', $lodge_id);

    return [
      '#title' => t('View Lodge'),
      '#theme' => 'lodge_view',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['name']['#value'],
        'form' => $form,
      ],
    ];
  }

  public function add() {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\AddLodgeForm');
    
    return [
      '#title' => t('Add a New Lodge'),
      '#theme' => 'lodge_create',
      '#data' => [
        'form' => $form,
      ],
    ];
  }

  public function edit($lodge_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\EditLodgeForm', $lodge_id);

    return [
      '#title' => t('View Lodge'),
      '#theme' => 'lodge_edit',
      '#data' => [        
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['name']['#value'],
        'form' => $form,
      ],
    ];
  }

  public function history($lodge_id) {

    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\LodgeHistoryForm', $lodge_id);

    return array(
      '#title' => t('Lodge History'),
      '#theme' => 'lodge_history',
      '#data' => [
        'lodgeId' => $lodge_id,
        'lodgeName' => $form['lodge_name']['#default_value'],
        'form' => $form,
      ],
    );
  }

}
