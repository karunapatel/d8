<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Description of LodgeFeeController
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeFeeController {

  public function fee() {

  }

  public function add() {

  }

  public function delete($lodge_id, $fee_id) {
    $form = \Drupal::formBuilder()->getForm('Drupal\lodge\Form\DeleteFeeConfirmForm', $lodge_id, $fee_id);

    return ['#data' => ['form' => $form]];
  }

}
