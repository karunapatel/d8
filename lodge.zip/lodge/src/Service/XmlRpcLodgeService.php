<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Service;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Value\XmlRpcLodge;
use Drupal\lodge\Value\XmlRpcLodgeAgent;
use Drupal\lodge\Value\XmlRpcLodgeDues;
use Drupal\lodge\Value\XmlRpcLodgeOfficer;

/**
 * Description of XmlRpcLodge
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcLodgeService {

  protected $xmlRpcUri;

  /**
   * Default constructor.
   */
  public function __construct() {
    $this->xmlRpcUri = \Drupal::config('lodge.generalsettings')->get('lodge_xmlrpc_uri');
  }

  /**
   * Handles an XML-RPC service callback for the lodge module.
   *
   * @param array $xmlRpcArgs The array of arguments for the XML-RPC service.
   * @return boolean
   */
  public function handle(array $xmlRpcArgs) {
    $results = array();

    if (!empty($xmlRpcArgs)) {
      $results = xmlrpc($this->xmlRpcUri, $xmlRpcArgs);
    }

    if ($errorObj = xmlrpc_error()) {      
      $message = sprintf('Lodge XML-RPC Error. <br />Sent [ %s ].<br /><br />Received [ %s ].',
          print_r($xmlRpcArgs, true),
          $errorObj->message);
      \Drupal::logger('lodge')->error($message);
      return false;
    }

    return $results;
  }

  public function search($searchText) {
    $results = [];

    $phrase = preg_replace('/[^a-zA-Z0-9]/', ' ', urldecode($searchText));
    $phrases = explode(' ', $phrase);
    $searchCriteria = array_filter($phrases, function($phrase) {
      return $phrase;
    });

    $filterBase = "REGEXP_LIKE (UPPER(%s), '%s')";

    $lFilter = '';
    $oFilter = '';
    foreach ($searchCriteria as $idx => $phrase) {
      if ($idx > 0) {
        $lFilter .= ") OR (";
        $oFilter .= ") OR (";
      }
      $countyName = " OR " . sprintf($filterBase, 'COUNTY_NAME', $phrase);

      $lFilter .= sprintf($filterBase, 'NAME', $phrase, $phrase);
      $lFilter .= $countyName;

      if (ctype_digit(strval($phrase))) {
        $lFilter .= " OR (LODGE_ID = " . $phrase . ")";
      }

      $oFilter .= sprintf($filterBase, 'LAST_NAME', $phrase, $phrase);
      $oFilter .= " OR " . sprintf($filterBase, 'FIRST_NAME', $phrase, $phrase);
      $oFilter .= " OR " . sprintf($filterBase, 'MIDDLE_NAME', $phrase, $phrase);
      $oFilter .= $countyName;
    }

    $lFilter = "($lFilter)";
    $oFilter = "($oFilter)";

    $xmlRpcQuery = new XmlRpcQuery($this);
    $lodges = XmlRpcLodge::createFromXmlRpc($xmlRpcQuery, ['*'], [$lFilter], [], 'LODGE_ID');
    if (is_array($lodges)) {
      foreach ($lodges as $lodge) {
        $results[] = $lodge->buildSearchResult();
      }
    } else {
      $results[] = $lodges->buildSearchResult();
    }

    $xmlRpcQuery->freeQuery();
    $officers = XmlRpcLodgeOfficer::createFromXmlRpc($xmlRpcQuery, ['*'], [$oFilter], [], 'OFFICER_ID');
    foreach ($officers as $officer) {
      $results[] = $officer->buildSearchResult();
    }

    return $results;
  }

  public function deleteLodgeFee($lodge_id, $fee_id) {
    $xmlRpcLodgeDues = XmlRpcLodgeDues::createFromXmlRpc($this, $lodge_id, $fee_id);
    return $xmlRpcLodgeDues->delete();
  }

  /**
   * Retrieves lodge data by lodge id.
   *
   * @param int $lodge_id The lodge id to query.
   * @return array The XML-RPC query results.
   */
  public function retrieveLodge($lodge_id) {
    return XmlRpcLodge::createFromXmlRpc(new XmlRpcQuery($this), ['*'], ['LODGE_ID='.$lodge_id]);
  }

  /**
   * Retrieves a listing of all the lodges.
   *
   * @param string $filter Filter criteria for the query.
   * @param string $order Order criteria for the query.
   * @return array The XML-RPC query results.
   */
  public function retrieveLodgeListing() {
    return XmlRpcLodge::createFromXmlRpc(new XmlRpcQuery($this));
  }

  /**
   * Retrieves a list of all active agents.
   *
   * @return array The XML-RPC query results.
   */
  public function retrieveActiveAgents() {
    $xmlRpcQuery = new XmlRpcQuery($this);
    $xmlRpcQuery->prepare('STG.getActiveAgents', null, [], [], [], '');
    $xmlRpcQuery->execute();
    return $xmlRpcQuery->fetch();
  }

  public function retrieveCestaAgents(array $agentIds) {
    $agents = XmlRpcLodgeAgent::createCestaAgentsFromXmlRpc(new XmlRpcQuery($this), ['*'], [$agentIds], [], 'AGENT_ID');
    if (is_array($agents) && count($agents) > 1) {
      return $agents;
    }
    return array_pop($agents);
  }

  public function retrieveLodgeAgents($lodgeId, $agentId=null) {

    $filters[] = "LODGE_ID=".$lodgeId;
    if (!is_null($agentId)) {
      $filters[] = "AGENT_ID='".$agentId."'";
    }
    $lodgeAgents = XmlRpcLodgeAgent::createLodgeAgentsFromXmlRpc(new XmlRpcQuery($this), ['*'], $filters, [], 'AGENT_ID');
    if (is_array($lodgeAgents) && count($lodgeAgents) > 1) {
      return $lodgeAgents;
    }
    return array_pop($lodgeAgents);
  }

  /**
   * Retrieves an XmlRpcLodgeOfficer object
   *
   * @param string $officerId
   * @return XmlRpcLodgeOfficer An XmlRpcLodgeOfficer object.
   */
  public function retrieveLodgeOfficer($officerId) {    
    $officers = XmlRpcLodgeOfficer::createFromXmlRpc(new XmlRpcQuery($this), ['*'], ['OFFICER_ID='.$officerId], [], 'OFFICER_ID');
    if (is_array($officers) && count($officers) > 1) {
      return $officers;
    }
    return array_pop($officers);
  }

  /**
   * Retrieves an array of XmlRpcLodgeOfficer objects.
   *
   * @param int $lodgeId The lodge id used to query the lodge officers.
   * @return array An array of XmlRpcLodgeOfficerObject
   */
  public function retrieveLodgeOfficers($lodgeId) {
    $officers = XmlRpcLodgeOfficer::createFromXmlRpc(new XmlRpcQuery($this), ['*'], ['LODGE_ID='.$lodgeId]);
    if (is_array($officers) && count($officers) > 1) {
      return $officers;
    }
    return array_pop($officers);
  }

  /**
   * Retrieves the lodge history for a given lodge id.
   *
   * @param int $lodge_id
   * @param string $order
   * @return array An array of lodge history data.
   */
  public function retrieveLodgeHistory($lodge_id, $order = '') {
    $results = $this->handle(['Lodge.retrieve' =>
      [
        'lodgehistory',
        [
          'HISTORY_ID',
          'TIMESTAMP',
          'ACTION',
          'USER_ID',
          'PREVIOUS_LODGE_ID',
          'NEW_LODGE_ID',
          'PREVIOUS_NAME',
          'NEW_NAME',
          'PREVIOUS_ORGANIZED_DATE' => "to_char(PREVIOUS_ORGANIZED_DATE, 'dd-MON-yyyy')",
          'NEW_ORGANIZED_DATE' => "to_char(NEW_ORGANIZED_DATE, 'dd-MON-yyyy')",
          'PREVIOUS_COUNTY_NAME',
          'NEW_COUNTY_NAME',
          'PREVIOUS_TIER_ID',
          'NEW_TIER_ID',
          'PREVIOUS_DISTRICT_ID',
          'NEW_DISTRICT_ID',
          'PREVIOUS_APPLY_LODGE_REFUND',
          'NEW_APPLY_LODGE_REFUND',
          'PREVIOUS_STATUS',
          'NEW_STATUS',
          'PREVIOUS_DISBANDED_DATE',
          'NEW_DISBANDED_DATE',
        ],
        "PREVIOUS_LODGE_ID = $lodge_id OR NEW_LODGE_ID = $lodge_id",
        array(),
        $order,
      ]
    ]);
    return $this->buildHistoryRecords($results);
  }

  /**
   * Retrieves the lodge officer history for a given lodge id and lodge officer id.
   *
   * @param int $lodge_id
   * @param int $officer_id
   * @param string $order
   * @return array
   */
  public function retrieveLodgeOfficerHistory($lodge_id, $officer_id, $order = 'HISTORY_ID DESC') {
    $results = $this->handle([
      'Lodge.retrieve' =>
      [
        'lodgeofficerhistory',
        [
          'HISTORY_ID'
          ,'TIMESTAMP'
          ,'ACTION'
          ,'USER_ID'
          ,'PREVIOUS_LODGE_ID'
          ,'NEW_LODGE_ID'
          ,'PREVIOUS_OFFICER_ID'
          ,'NEW_OFFICER_ID'
          ,'PREVIOUS_OFFICETYPE_ID'
          ,'NEW_OFFICETYPE_ID'
          ,'PREVIOUS_FIRST_NAME'
          ,'NEW_FIRST_NAME'
          ,'PREVIOUS_MIDDLE_NAME'
          ,'NEW_MIDDLE_NAME'
          ,'PREVIOUS_LAST_NAME'
          ,'NEW_LAST_NAME'
          ,'PREVIOUS_ADDRESS'
          ,'NEW_ADDRESS'
          ,'PREVIOUS_CITY'
          ,'NEW_CITY'
          ,'PREVIOUS_STATE'
          ,'NEW_STATE'
          ,'PREVIOUS_ZIP'
          ,'NEW_ZIP'
          ,'PREVIOUS_ZIP_EXT'
          ,'NEW_ZIP_EXT'
          ,'PREVIOUS_WORKPHONE'
          ,'NEW_WORKPHONE'
          ,'PREVIOUS_CELLPHONE'
          ,'NEW_CELLPHONE'
          ,'PREVIOUS_FAX'
          ,'NEW_FAX'
          ,'PREVIOUS_EMAILADDRESS'
          ,'NEW_EMAILADDRESS'
          ,'PREVIOUS_TAXID'
          ,'NEW_TAXID'
          ,'PREVIOUS_TOOK_OFFICE_DATE' => "to_char(PREVIOUS_TOOK_OFFICE_DATE, 'dd-MON-yyyy')"
          ,'NEW_TOOK_OFFICE_DATE' => "to_char(NEW_TOOK_OFFICE_DATE, 'dd-MON-yyyy')"
          ,'PREVIOUS_TERMINATION_DATE' => "to_char(PREVIOUS_TERMINATION_DATE, 'dd-MON-yyyy')"
          ,'NEW_TERMINATION_DATE' => "to_char(NEW_TERMINATION_DATE, 'dd-MON-yyyy')"
        ],
        '(PREVIOUS_LODGE_ID = ' . $lodge_id . ' AND PREVIOUS_OFFICER_ID = ' . $officer_id . ') OR (NEW_LODGE_ID = ' . $lodge_id . ' AND NEW_OFFICER_ID = ' . $officer_id . ')',
        [],
        $order
      ]
    ]);
    return $this->buildHistoryRecords($results);
  }

  /**
   * Retrieves the lodge agent history for an agent given the lodge id and agent id.
   *
   * @param int $lodge_id
   * @param int $agent_id
   * @param string $order
   * @return array
   */
  public function retrieveLodgeAgentHistory($lodge_id, $agent_id, $order = 'HISTORY_ID DESC') {
    $results = $this->handle([
      'Lodge.retrieve' =>
      [
        'lodgeagenthistory',
        [
          'HISTORY_ID'
          ,'TIMESTAMP'
          ,'ACTION'
          ,'USER_ID'
          ,'PREVIOUS_LODGE_ID'
          ,'NEW_LODGE_ID'
          ,'PREVIOUS_APPLY_PROMO'
          ,'NEW_APPLY_PROMO'
          ,'PREVIOUS_TOOK_OFFICE_DATE' => "to_char(PREVIOUS_TOOK_OFFICE_DATE, 'dd-MON-yyyy')"
          ,'NEW_TOOK_OFFICE_DATE' => "to_char(NEW_TOOK_OFFICE_DATE, 'dd-MON-yyyy')"
          ,'PREVIOUS_TERMINATION_DATE' => "to_char(PREVIOUS_TERMINATION_DATE, 'dd-MON-yyyy')"
          ,'NEW_TERMINATION_DATE' => "to_char(NEW_TERMINATION_DATE, 'dd-MON-yyyy')"
        ],
        '(PREVIOUS_LODGE_ID = ' . $lodge_id . ' AND PREVIOUS_AGENT_ID = ' . $agent_id . ') OR (NEW_LODGE_ID = ' . $lodge_id . ' AND NEW_AGENT_ID = ' . $agent_id . ')',
        [],
        $order
      ]
    ]);
    return $this->buildHistoryRecords($results);
  }

  /**
   * Parses the XML-RPC results of a lodge, lodge officer, or lodge agent
   * history query. It then builds the changes array for relevant changes and
   * returns the parsed array for consumption.
   *
   * @param array $results
   * @return array
   */
  protected function buildHistoryRecords($results) {
    $records = array();
    foreach ($results as $idx => $history) {
      // Skip over insert actions.
      if ($history['ACTION'] == 'INSERT') {
        continue;
      }

      $changes = $this->buildHistoryChanges($history);

      if (!empty($changes)) {
        $records[$idx] = $this->buildHistoryRecord($history, $changes);
      }
    }
    return $records;
  }

  /**
   * Parses the history changes to verify a change occurred. Keeps only the
   * values for new and previous for actual changes. Empty fields are not
   * included.
   *
   * @param array $history
   * @return array
   */
  protected function buildHistoryChanges($history) {
    $changes = [];
    $prevKey = '';
    $prevVal = '';

    foreach ($history as $k => $v) {
      // Normalize Dates...
      if (substr($k, 0, -4) == 'DATE') {
        $val = $this->normalizeDate($v);
      } else {
        $val = $v;
      }

      if (substr($k, 0, 8) == 'PREVIOUS') {
        $prevVal = $val;
        $prevKey = $k;
      } elseif (substr($k, 0, 3) == 'NEW') {
        if ($val != $prevVal) {
          $changes[] = [
            $k => $val,
            $prevKey => $prevVal,
          ];
        }
      }
    }
    return $changes;
  }

  /**
   * Builds and returns the useable history record.
   *
   * @param array $history
   * @param array $changes
   * @return array
   */
  protected function buildHistoryRecord($history, $changes) {
    return [
      'HISTORY_ID' => $history['HISTORY_ID'],
      'TIMESTAMP' => $history['TIMESTAMP'],
      'USER_ID' => $history['USER_ID'],
      'CHANGES' => $changes,
    ];
  }

  /**
   * Retrieves a list of counties.
   * @return array
   */
  public function retrieveCounties() {
    $counties = array();
    if (!$counties = $this->getCachedData('county')) {
      if ($countiesList = $this->handle(['Lodge.retrieve' => ['county', ['FIPS_ID', 'COUNTY_NAME'], '', [], 'county_name']])) {
        foreach ($countiesList as $record) {
          $counties[$record['COUNTY_NAME']] = $record['COUNTY_NAME'];
        }
      }
    }
    return $counties;
  }

  /**
   * Retrieves a list of tiers.
   * @return array
   */
  public function retrieveTiers() {
    $tiers = array();
    if (!$tiers = $this->getCachedData('tier')) {
      if ($tiersList = $this->handle(['Lodge.retrieve' => ['tier', ['TIER_ID', 'NAME'], '', [], 'tier_id']])) {
        foreach ($tiersList as $k => $v) {
          $tiers[$v['TIER_ID']] = $v['NAME'];
        }
      }
    }
    return $tiers;
  }

  /**
   * Retrieves a list of districts.
   * @return array
   */
  public function retrieveDistricts() {
    $districts = array();
    if (!$districts = $this->getCachedData('district')) {
      if ($districtList = $this->handle(['Lodge.retrieve' => ['district', ['DISTRICT_ID', 'NAME'], '', [], 'district_id']])) {
        foreach ($districtList as $k => $v) {
          $districts[$v['DISTRICT_ID']] = $v['NAME'];
        }
      }
    }
    return $districts;
  }

  /**
   * Retrieves the active dues for a give lodge id.
   *
   * @param int $lodge_id
   * @return array
   */
  public function retrieveDues($lodge_id, $fee_id = null) {
    $xmlRpcLodgeDues = XmlRpcLodgeDues::createFromXmlRpc($this, $lodge_id, $fee_id);
    if (is_array($xmlRpcLodgeDues) && count($xmlRpcLodgeDues) > 1) {
      return $xmlRpcLodgeDues;
    }
    return array_pop($xmlRpcLodgeDues);
  }

  /**
   * Retrieves the county name for a give county id.
   *
   * @param int $county_id
   * @return string
   */
  public function getCountyName($county_id) {
    $counties = $this->retrieveCounties();
    if (in_array($county_id, $counties)) {
      return $counties[$county_id];
    }
  }

  /**
   * Retrieves the County id by the county name.
   *
   * @param string $name
   * @return int
   */
  public function getCountyIdByName($name) {
    $counties = $this->retrieveCounties();
    return array_search($name, $counties);
  }

  /**
   * Gets cached data so we don't have to make an XML-RPC call.
   *
   * @param mixed $type
   * @return mixed
   */
  public function getCachedData($type) {
    return \Drupal::cache()->get($type);
  }

  /**
   * Caches data so we don't have to always make XML-RPC calls.
   * @param mixed $type
   * @param mixed $data
   */
  public function setCachedData($type, $data) {
    \Drupal::cache()->set($type, $data);
  }

  /**
   * Retrieves lodge data.
   *
   * @param string $type
   * @param array $fields
   * @param string $filter
   * @param array $join
   * @param string $order
   * @return array
   */
  public function getLodgeData($type, array $fields = array(), $filter = '', array $join = array(), $order = NULL) {
    return $this->handle(['Lodge.retrieve' => [$type, $fields, $filter, $join, $order]]);
  }

  /**
   * Converts a Date from the Oracle d-M-Y format to a DrupalDateTime format.
   * NOTE: use DrupalDateTime::createFromDateTime() else get 32-bit dates which
   * only supports dates from 1970 JAN through JAN 2038.
   *
   * @param string $string
   * @param string $format
   * @return DrupalDateTime object
   */
  public function normalizeDate($string, $format = 'd-M-Y') {
    if (empty($string)) {
      return null;
    }
    $date = \DateTime::createFromFormat($format, $string);
    return DrupalDateTime::createFromDateTime($date);
  }

  /**
   * Converts XML-RPC error codes into human friendly and readable strings.
   *
   * @param \stdClass $errorObj
   * @return string
   */
  public function getFriendlyErrorMessage(\stdClass $errorObj) {
    switch ($errorObj->code) {
      case 2292:
        $msg = 'Did you attempt to update a lodge\'s ID while officers are assigned to it? If so, assign the officers to a different lodge first.';
        break;

      case 1:
        $msg = 'Did you attempt to create a record with an ID (i.e., Lodge ID or Officer ID) that is already in use?';
        break;

      case 904:
        $msg = 'Lodge UI attempted to select a nonexistent column. Please contact IT and have them check the intranet logs.';
        break;

      case 920:
        $msg = 'Lodge UI attempted to select from a nonexistent table. Please contact IT and have them check the intranet logs.';
        break;

      case 12514:
        $msg = 'There was a problem connecting to the database. Please ask IT to check the intranet logs. Make sure that they check the web services configuration points to the correct Oracle environment, and that that Oracle environment is operational.';
        break;

      default:
        $msg = 'Unknown Error! <P>Did you attempt to create a duplicate record (e.g. a lodge fee effective on the same date as a previous lodge fee, or a duplicate lodge number). If this error persists please contact IT.';
        break;
    }
    return $msg;
  }

  /**
   * Retrieves and array of U.S. States.
   *
   * @return array
   */
  public function getStates() {
    return array(
       'AL'=>'AL',
       'AK'=>'AK',
       'AR'=>'AR',
       'AZ'=>'AZ',
       'CA'=>'CA',
       'CO'=>'CO',
       'CT'=>'CT',
       'DE'=>'DE',
       'FL'=>'FL',
       'GA'=>'GA',
       'HI'=>'HI',
       'ID'=>'ID',
       'IL'=>'IL',
       'IN'=>'IN',
       'IA'=>'IA',
       'KS'=>'KS',
       'KY'=>'KY',
       'LA'=>'LA',
       'ME'=>'ME',
       'MD'=>'MD',
       'MA'=>'MA',
       'MI'=>'MI',
       'MN'=>'MN',
       'MS'=>'MS',
       'MO'=>'MO',
       'MT'=>'MT',
       'NE'=>'NE',
       'NV'=>'NV',
       'NH'=>'NH',
       'NJ'=>'NJ',
       'NM'=>'NM',
       'NY'=>'NY',
       'NC'=>'NC',
       'ND'=>'ND',
       'OH'=>'OH',
       'OK'=>'OK',
       'OR'=>'OR',
       'PA'=>'PA',
       'RI'=>'RI',
       'SC'=>'SC',
       'SD'=>'SD',
       'TN'=>'TN',
       'TX'=>'TX',
       'UT'=>'UT',
       'VT'=>'VT',
       'VA'=>'VA',
       'WA'=>'WA',
       'WV'=>'WV',
       'WI'=>'WI',
       'WY'=>'WY'
    );
  }
}