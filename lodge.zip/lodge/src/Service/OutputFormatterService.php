<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Service;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\lodge\Value\Address;
use Drupal\lodge\Value\Contact;
use Drupal\lodge\Value\IdentificationInterface;

/**
 * Description of OutputFormatterService
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class OutputFormatterService {

  public function formatAddress(Address $address) {
    $zipExt = $address->getZipExt();

    $street = '<p class="address-street">' . $address->getStreet() . '</p>';
    $cityStateZip = '<p class="address-city-state-zip"><span class="address-city">' . $address->getCity() . '</span><span class="address-city-state-separator">, </span><span class="address-state">' . $address->getState() . '</span> <span class="address-zip">' . $address->getZip() . '</span>' . (!empty($zipExt) ? ('<span class="address-zip-zip4-separator">-</span><span class="address-zip4">' . $zipExt . '</span>') : '') . '</p>';
    $county = '<p class="address-county">' . $address->getCounty() . ' County</p>';
    return '<div id="address-wrap">'.$street.$cityStateZip.$county.'</div>';
  }

  public function formatContact(Contact $contact) {
    $raw = $contact->getValue();
    if (!empty($raw)) {
      $area = substr($raw, 0, 3);
      $prefix = substr($raw, 3, 3);
      $line = substr($raw, 6);
      return '<span class="phone-area">(' . $area . ')</span><span class="phone-area-prefix-separator">&nbsp;</span><span class="phone-prefix">' . $prefix . '</span><span class="phone-prefix-line-separator">-</span><span="phone-line">' . $line . '</span>';
    }
    return '';
  }

  public function formatId(IdentificationInterface $id) {
    $raw = $id->getValue();
    if (!empty($raw)) {
      switch ($id->getType()) {
        case 'ein':
          $prefix = substr($raw, 0, 2);
          $suffix = substr($raw, 2);
          $suffix_masked = str_repeat('*', strlen($raw) - 4) . substr($raw, -4);
          return '<span class="mask-id">**-' . $suffix_masked . '</span>';
        case 'itin':
        case 'ssn':
          $area = substr($raw, 0, 3);
          $group = substr($raw, 3, 2);
          $serial = substr($raw, 5);
          return '<span class="mask-id">***-**-' . $serial . '</span>';
        default:
          // Unknown/unsupported ID format so we should return a default mask to
          // mask all but the last 4 didgits of the unformatted (raw) value.
          return '<span class="mask-id">' . (str_repeat('*', strlen($raw) - 4) . substr($raw, -4)) . '</span>';
      }
    }
    return '<span class="mask-id"></span>';
  }

  public function formatOfficeTerm($status, DrupalDateTime $startDate=null, DrupalDateTime $endDate = null, $dateFormat='n/j/Y') {
    if (empty($startDate)) {
      return '';
    }
    $terminationDate = is_null($endDate) ? '' : $endDate->format($dateFormat);
    return '<p class="term-status">Status: ' . $status . '</p><p class="term-begin">Begin: ' . $startDate->format($dateFormat) . '</p><p class="term-end">End: ' . $terminationDate . '</p>';
  }
}
