<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

/**
 * Description of SearchResult
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class SearchResult {

  protected $title;
  protected $snippet;
  protected $info;

  public function __construct($title, $snippet, $info) {
    $this->title = $title;
    $this->snippet = $snippet;
    $this->info = $info;
  }

  public function setTitle($title) {
    $this->title = $title;
  }

  public function setSnippet($snippet) {
    $this->snippet = $snippet;
  }

  public function setInfo($info) {
    $this->info = $info;
  }

  public function getTitle() {
    return $this->title;
  }

  public function getSnippet() {
    return $this->snippet;
  }

  public function getInfo() {
    return $this->info;
  }
}
