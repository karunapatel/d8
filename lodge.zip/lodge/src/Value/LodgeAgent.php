<?php

/** 
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of LodgeAgent
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeAgent {
  protected $lodgeId;
  protected $tookOfficeDate;
  protected $terminationDate;
  protected $applyPromo;
  protected $agentId;
  protected $brokerCode;
  protected $brokerageName;
  protected $agcNewBusinessEffDate;
  protected $agcDateClosedNb;
  protected $name;
  protected $entyCode;
  protected $address;
  protected $city;
  protected $state;
  protected $zip;
  protected $zipExt;
  protected $countyName;
  protected $emailAddress;
  protected $workPhone;
  protected $cellPhone;
  protected $fax;
  protected $entyRecognizedStartDate;
  protected $entyRecognizedEndDate;
  protected $status;

  public function __construct(
    $agentId = null
    , $lodgeId = null
    , $applyPromo = null
    , DrupalDateTime $tookOfficeDate = null
    , DrupalDateTime $terminationDate = null
    , $brokerCode = null
    , $brokerageName = null
    , DrupalDateTime $agcNewBusinessEffDate = null
    , DrupalDateTime $agcDateClosedNb = null
    , $name = null
    , $entyCode = null
    , $address = null
    , $city = null
    , $state = null
    , $zip = null
    , $zipExt = null
    , $countyName = null
    , $emailAddress = null
    , $workPhone = null
    , $cellPhone = null
    , $fax = null
    , DrupalDateTime $entyRecognizedStartDate = null
    , DrupalDateTime $entyRecognizedEndDate = null
    , $status = null
  ) {
    $this->setAgentId($agentId);
    $this->setLodgeId($lodgeId);
    $this->setApplyPromo($applyPromo);
    $this->setTookOfficeDate($tookOfficeDate);
    $this->setTerminationDate($terminationDate);
    $this->setBrokerCode($brokerCode);
    $this->setBrokerageName($brokerageName);
    $this->setAgcNewBusinessEffDate($agcNewBusinessEffDate);
    $this->setAgcDateClosedNb($agcDateClosedNb);
    $this->setName($name);
    $this->setEntyCode($entyCode);
    $this->setAddress($address);
    $this->setCity($city);
    $this->setState($state);
    $this->setZip($zip);
    $this->setZipExt($zipExt);
    $this->setCountyName($countyName);
    $this->setEmailAddress($emailAddress);
    $this->setWorkPhone($workPhone);
    $this->setCellPhone($cellPhone);
    $this->setFax($fax);
    $this->setEntyRecognizedStartDate($entyRecognizedStartDate);
    $this->setEntyRecognizedEndDate($entyRecognizedEndDate);
    $this->setStatus($status);
  }

  public static function createFromFormState(FormStateInterface $form_state) {

    if (!empty($form_state->getValue('took_office_date'))) {
      $tookOfficeDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('took_office_date')));
    }
    if (!empty($form_state->getValue('termination_date')) && $form_state->getValue('agent_lodge_status') == 'terminated') {
      $terminationDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('termination_date')));
    } else {
      $terminationDate = null;
    }

    return static::createFromArray([
      'LODGE_ID' => $form_state->getValue('lodge_id'),
      'AGENT_ID' => $form_state->getValue('agent_id'),
      'APPLY_PROMO' => $form_state->getValue('apply_promo'),
      'TOOK_OFFICE_DATE' => $tookOfficeDate,
      'TERMINATION_DATE' => $terminationDate,
    ]);
  }

  public static function createFromArray(array $agent) {
    return new static(
      isset($agent['AGENT_ID']) ? $agent['AGENT_ID'] : null
      , isset($agent['LODGE_ID']) ? $agent['LODGE_ID'] : null
      , isset($agent['APPLY_PROMO']) ? $agent['APPLY_PROMO'] : null
      , isset($agent['TOOK_OFFICE_DATE']) ? $agent['TOOK_OFFICE_DATE'] : null
      , isset($agent['TERMINATION_DATE']) ? $agent['TERMINATION_DATE'] : null
      , isset($agent['BROKER_CODE']) ? $agent['BROKER_CODE'] : null
      , isset($agent['BROKERAGE_NAME']) ? $agent['BROKERAGE_NAME'] : null
      , isset($agent['AGC_NEW_BUSINESS_EFF_DATE']) ? $agent['AGC_NEW_BUSINESS_EFF_DATE'] : null
      , isset($agent['AGC_DATE_CLOSED_NB']) ? $agent['AGC_DATE_CLOSED_NB'] : null
      , isset($agent['NAME']) ? $agent['NAME'] : null
      , isset($agent['ENTY_CODE']) ? $agent['ENTY_CODE'] : null
      , isset($agent['ADDRESS']) ? $agent['ADDRESS'] : null
      , isset($agent['CITY']) ? $agent['CITY'] : null
      , isset($agent['STATE']) ? $agent['STATE'] : null
      , isset($agent['ZIP']) ? $agent['ZIP'] : null
      , isset($agent['ZIP_EXT']) ? $agent['ZIP_EXT'] : null
      , isset($agent['COUNTY']) ? $agent['COUNTY'] : null
      , isset($agent['EMAIL']) ? $agent['EMAIL'] : null
      , isset($agent['BUS_TEL']) ? $agent['BUS_TEL'] : null
      , isset($agent['BUS_CELL']) ? $agent['BUS_CELL'] : null
      , isset($agent['BUS_FAX']) ? $agent['BUS_FAX'] : null
      , isset($agent['ENTY_RECOGNIZED_START_DATE']) ? $agent['ENTY_RECOGNIZED_START_DATE'] : null
      , isset($agent['ENTY_RECOGNIZED_END_DATE']) ? $agent['ENTY_RECOGNIZED_END_DATE'] : null
      , isset($agent['CESTA_STATUS']) ? $agent['CESTA_STATUS'] : null
    );
  }

  public function setAgentId($agentId) {
    $this->agentId = $agentId;
  }

  public function setLodgeId($lodgeId) {
    $this->lodgeId = $lodgeId;
  }

  public function setApplyPromo($applyPromo) {
    $this->applyPromo = $applyPromo;
  }

  public function setTookOfficeDate(DrupalDateTime $tookOfficeDate = null) {
    $this->tookOfficeDate = $tookOfficeDate;
  }

  public function setTerminationDate(DrupalDateTime $terminationDate = null) {
    $this->terminationDate = $terminationDate;
  }

  public function setBrokerCode($brokerCode) {
    $this->brokerCode = $brokerCode;
  }

  public function setBrokerageName($brokerageName) {
    $this->brokerageName = $brokerageName;
  }

  public function setAgcNewBusinessEffDate(DrupalDateTime $agcNewBusinessEffDate = null) {
    $this->agcNewBusinessEffDate = $agcNewBusinessEffDate;
  }

  public function setAgcDateClosedNb(DrupalDateTime $agcDateClosedNb = null) {
    $this->agcDateClosedNb = $agcDateClosedNb;
  }

  public function setName($name) {
    $this->name = $name;
  }

  public function setEntyCode($entyCode) {
    $this->entyCode = $entyCode;
  }

  public function setAddress($address) {
    $this->address = $address;
  }

  public function setCity($city) {
    $this->city = $city;
  }

  public function setState($state) {
    $this->state = $state;
  }

  public function setZip($zip) {
    $this->zip = $zip;
  }

  public function setZipExt($zipExt) {
    $this->zipExt = $zipExt;
  }

  public function setCountyName($countyName) {
    $this->countyName = $countyName;
  }

  public function setEmailAddress($emailAddress) {
    $this->emailAddress = $emailAddress;
  }

  public function setWorkPhone($workPhone) {
    $this->workPhone = $workPhone;
  }

  public function setCellPHone($cellPhone) {
    $this->cellPhone = $cellPhone;
  }

  public function setFax($fax) {
    $this->fax = $fax;
  }

  public function setEntyRecognizedStartDate(DrupalDateTime $entyRecognizedStartDate = null) {
    $this->entyRecognizedStartDate = $entyRecognizedStartDate;
  }

  public function setEntyRecognizedEndDate(DrupalDateTime $entyRecognizedEndDate = null) {
    $this->entyRecognizedEndDate = $entyRecognizedEndDate;
  }

  public function setStatus($status) {
    $this->status = $status;
  }

  public function getAgentId() {
    return $this->agentId;
  }

  public function getLodgeId() {
    return $this->lodgeId;
  }

  public function getApplyPromo() {
    return $this->applyPromo;
  }

  public function getTookOfficeDate($format = '') {
    if (is_null($this->tookOfficeDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->tookOfficeDate;
    }
    return $this->tookOfficeDate->format($format);
  }

  public function getTerminationDate($format = '') {
    if (is_null($this->terminationDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->terminationDate;
    }
    return $this->terminationDate->format($format);
  }

  public function getName() {
    return $this->name;
  }

  public function getStatus() {
    return $this->status;
  }

  public function getEmailAddress() {
    return $this->emailAddress;
  }

  public function getBrokerageName() {
    return $this->brokerageName;
  }

  public function getAddress() {
    return $this->address;
  }

  public function getEntyCode() {
    return $this->entyCode;
  }

  public function getWorkPhone() {
    return $this->workPhone;
  }

  public function getCellPhone() {
    return $this->cellPhone;
  }

  public function getFax() {
    return $this->fax;
  }

  public function getZipExt() {
    return $this->zipExt;
  }

  public function getZip() {
    return $this->zip;
  }

  public function getState() {
    return $this->state;
  }

  public function getCountyName() {
    return $this->countyName;
  }

  public function getCity() {
    return $this->city;
  }
}