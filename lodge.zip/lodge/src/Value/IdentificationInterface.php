<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

/**
 * Description of IdentificationInterface
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
interface IdentificationInterface {
  public function getType();
  public function getValue();
}
