<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\lodge\Value\IdentificationInterface;

/**
 * Description of Identification
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class Identification implements IdentificationInterface {

  protected $type;
  protected $value;

  public function __construct($type, $value) {
    if (in_array($type, $this->validTypes())) {
      $this->type = $type;
      $this->value = $value;
    }
  }
  
  public function getType() {
    return $this->type;
  }

  public function getValue() {
    return $this->value;
  }

  protected function validTypes() {
    return [
      'ein',
      'ssn',
      'itin',
    ];
  }
}
