<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\lodge\Entity\DateTimeNormalization;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Entity\XmlRpcValue;
use Drupal\lodge\Value\AbstractXmlRpcValueObject;
use Drupal\lodge\Value\LodgeAgent;

/**
 * Description of XmlRpcLodgeAgent
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcLodgeAgent extends AbstractXmlRpcValueObject {

  protected $xmlRpcQuery;
  protected $lodgeAgent;

  public function __construct(XmlRpcQuery $xmlRpcQuery, LodgeAgent $lodgeAgent) {
    $this->xmlRpcQuery = $xmlRpcQuery;
    $this->lodgeAgent = $lodgeAgent;
  }

  public function getLodgeAgent() {
    return $this->lodgeAgent;
  }

  public static function createCestaAgentsFromXmlRpc(XmlRpcQuery $xmlRpcQuery, array $select = ['*'], array $filters = array(), array $join = array(), $order = 'AGENT_ID') {
    $xmlRpcQuery->freeQuery();
    $xmlRpcQuery->prepare('STG.getAgentInfo_lodge', null, $select, $filters, $join, $order);
    $xmlRpcQuery->execute();
    $results = $xmlRpcQuery->fetch();

    // Makes it possible to normalize date strings in x format as PHP
    // DateTime objects to get around the 32-bit date issue.
    $dateTimeNormalizer = new DateTimeNormalization('d-M-Y');

    $records = [];
    if (is_array($results) && !empty($results)) {
      foreach ($results as &$cestaAgent) {
        $curDate = (new DrupalDateTime('now', 'America/Chicago'));
        $cestaAgent['AGENT_ID'] = $cestaAgent['ENTY_CODE'];

        $startDate = null;
        if (isset($cestaAgent['ENTY_RECOGNIZED_START_DATE'])) {
          $startDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($cestaAgent['ENTY_RECOGNIZED_START_DATE'])->normalize();
        }

        $endDate = null;
        if (isset($cestaAgent['ENTY_RECOGNIZED_END_DATE'])) {
        $endDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($cestaAgent['ENTY_RECOGNIZED_END_DATE'])->normalize();
        }
        $newBusinessEffectiveDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($cestaAgent['AGC_NEW_BUSINESS_EFF_DATE'])->normalize();
        $closedNbDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($cestaAgent['AGC_DATE_CLOSED_NB'])->normalize();

        $cestaAgent['ENTY_RECOGNIZED_START_DATE'] = !$startDate ? null : DrupalDateTime::createFromDateTime($startDate);
        $cestaAgent['ENTY_RECOGNIZED_DATE_END'] = !$endDate ? null : DrupalDateTime::createFromDateTime($endDate);
        $cestaAgent['AGC_NEW_BUSINESS_EFF_DATE'] = !$newBusinessEffectiveDate ? null : DrupalDateTime::createFromDateTime($newBusinessEffectiveDate);
        $cestaAgent['AGC_DATE_CLOSED_NB'] = !$closedNbDate ? null : DrupalDateTime::createFromDateTime($closedNbDate);

        if (isset($cestaAgent['ENTY_RECOGNIZED_FLAG']) && ($cestaAgent['ENTY_RECOGNIZED_FLAG'] == 'Y' && (
            ($cestaAgent['ENTY_RECOGNIZED_START_DATE'] <= $curDate) &&
            ($curDate <= $cestaAgent['ENTY_RECOGNIZED_END_DATE'])))
        ) {
          $cestaAgent['CESTA_STATUS'] = 'recognized';
        }
        elseif (($cestaAgent['AGC_NEW_BUSINESS_EFF_DATE'] <= $curDate) && (
            ($curDate <= $cestaAgent['AGC_DATE_CLOSED_NB']) || !$cestaAgent['AGC_DATE_CLOSED_NB']->format('r'))
        ) {
          $cestaAgent['CESTA_STATUS'] = 'active';
        }
        else {
          $cestaAgent['CESTA_STATUS'] = 'inactive';
        }
        $records[] = new static($xmlRpcQuery, LodgeAgent::createFromArray($cestaAgent));
      }
    }

    return $records;
  }

  public static function createLodgeAgentsFromXmlRpc(XmlRpcQuery $xmlRpcQuery, array $select = ['*'], array $filters = array(), array $join = array(), $order = 'AGENT_ID') {
    $xmlRpcQuery->freeQuery();
    $xmlRpcQuery->prepare('Lodge.retrieve', 'lodgeagent', $select, $filters, $join, $order);
    $xmlRpcQuery->execute();
    $results = $xmlRpcQuery->fetch();

    $agents = [];
    $agentIds = [];
    if (is_array($results) && count($results) > 0) {

      // Makes it possible to normalize date strings in x format as PHP
      // DateTime objects to get around the 32-bit date issue.
      $dateTimeNormalizer = new DateTimeNormalization('d-M-Y');
      foreach ($results as $result) {
        $agentIds[] = $agentId = $result['AGENT_ID'];
        $agents[$agentId] = $result;

        // We're not creating DrupalDateTime objects straight from the database
        // date values because DrupalDateTime will convert it to a 32-bit date
        // and then we have dates which can't be before Dec 31, 1970 or after
        // Jan 18, 2038 which IS a BIG problem.
        // Normalize the TOOK_OFFICE_DATE as a PHP DateTime object.
        $tookOfficeDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($result['TOOK_OFFICE_DATE'])->normalize();

        // Normalize the TERMINATION_DATE as PHP DateTime object.
        $terminationDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($result['TERMINATION_DATE'])->normalize();

        // DrupalDateTime for Drupal 8 Form API and render compatibility.
        $agents[$agentId]['TOOK_OFFICE_DATE'] = !$tookOfficeDate ? null : DrupalDateTime::createFromDateTime($tookOfficeDate);

        // DrupalDateTime for Drupal 8 Form API and render compatibility.
        $agents[$agentId]['TERMINATION_DATE'] = !$terminationDate ? null : DrupalDateTime::createFromDateTime($terminationDate);

        // Set the promo value to lowercase as select value attributes are lower case.
        $agents[$agentId]['APPLY_PROMO'] = strtolower($result['APPLY_PROMO']);
      }
    }

    $cestaAgents = static::createCestaAgentsFromXmlRpc($xmlRpcQuery, ['*'], count($agentIds < 2) ? [$agentIds] : $agentIds);

    $records = [];
    // Non-legacy agents.
    foreach ($cestaAgents as &$cestaAgent) {
      $lodgeAgent = $cestaAgent->getLodgeAgent();
      if (array_key_exists($lodgeAgent->getAgentId(), $agents)) {
        $agent = $agents[$lodgeAgent->getAgentId()];
        $cestaAgent->getLodgeAgent()->setLodgeId($agent['LODGE_ID']);
        $cestaAgent->getLodgeAgent()->setApplyPromo($agent['APPLY_PROMO']);
        $cestaAgent->getLodgeAgent()->setTerminationDate($agent['TERMINATION_DATE']);
        $cestaAgent->getLodgeAgent()->setTookOfficeDate($agent['TOOK_OFFICE_DATE']);
        unset($agents[$lodgeAgent->getAgentId()]);
        $records[] = $cestaAgent;
      }
    }

    // Legacy agents.
    foreach ($agents as $agent) {
      $record = new static($xmlRpcQuery, LodgeAgent::createFromArray($agent));
      if (empty($record->getLodgeAgent()->getName())) {
        $record->getLodgeAgent()->setName("Legacy Agent #{$record->getLodgeAgent()->getAgentId()}");
        $record->getLodgeAgent()->setStatus('not available');
      }
      $records[] = $record;
    }

    usort($records, ['\Drupal\lodge\Value\XmlRpcLodgeAgent', 'sortByNameAscending']);

    return $records;
  }

  protected function buildXmlRpcArray() {
    return [
      'LODGE_ID' => $this->lodgeAgent->getLodgeId(),
      'TOOK_OFFICE_DATE' => $this->lodgeAgent->getTookOfficeDate('d-M-Y'),
      'TERMINATION_DATE' => is_null($this->lodgeAgent->getTerminationDate()) ? null : $this->lodgeAgent->getTerminationDate('d-M-Y'),
      'APPLY_PROMO' => ucfirst($this->lodgeAgent->getApplyPromo()), /* database has first letter capitalized. */
      'AGENT_ID' => $this->lodgeAgent->getAgentId()
    ];
  }

  public function save() {

    $user = \Drupal::currentUser()->getAccountName();
    $values = $this->buildXmlRpcArray();
    $lodgeId = $this->lodgeAgent->getLodgeId();
    $agentId = $this->lodgeAgent->getAgentId();

    $agent = $this->xmlRpcQuery->getService()->retrieveLodgeAgents($lodgeId, $agentId);
    if ($agent) {
      $xmlRpcArgs = ['Lodge.update' => [$user, 'lodgeagent', $values, ["AGENT_ID = '" . $agentId . "'", 'LODGE_ID=' . $lodgeId]]];
    }
    else {
      $xmlRpcArgs = ['Lodge.create' => [$user, 'lodgeagent', $values]];
    }

    if (false != $response = $this->xmlRpcQuery->getService()->handle($xmlRpcArgs)) {
      return $this;
    }
    return false;
  }

  protected static function sortByNameAscending($a, $b) {
    return strcmp($a->lodgeAgent->getName(), $b->lodgeAgent->getName());
  }

}
