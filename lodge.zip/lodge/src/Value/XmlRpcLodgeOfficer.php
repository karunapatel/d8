<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\DateTime\DrupalDateTime;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\lodge\Entity\DateTimeNormalization;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Entity\XmlRpcValue;
use Drupal\lodge\Value\AbstractXmlRpcValueObject;
use Drupal\lodge\Value\LodgeOfficer;
use Drupal\lodge\Value\SearchResult;

/**
 * Description of XmlRpcLodgeOfficer
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcLodgeOfficer extends AbstractXmlRpcValueObject {

  /**
   * Officer object.
   *
   * @var \Drupal\lodge\Value\Officer object.
   */
  protected $officer;

  /**
   *
   * @var type
   */
  protected $history;

  /**
   * XML-RPC query object.
   *
   * @var Drupal\lodge\Value\XmlRpcQuery
   */
  protected $xmlRpcQuery;

  /**
   * Default constructor.
   *
   * @param \Drupal\lodge\Value\XmlRpcQuery $xmlRpcQuery
   * @param LodgeOfficer $officer
   */
  public function __construct(XmlRpcQuery $xmlRpcQuery, LodgeOfficer $officer = null) {
    $this->xmlRpcQuery = $xmlRpcQuery;
    $this->officer = $officer;
  }

  /**
   * Officer object.
   *
   * @return Drupal\lodge\Value\Officer object.
   */
  public function getOfficer() {
    return $this->officer;
  }

  /**
   * Creates an instance of this object from the results of an XML-RPC response
   * query.
   *
   * @param XmlRpcQuery $xmlRpcQuery
   * @param array $select
   * @param array $filters
   * @param array $join
   * @param string $order
   * @return \static An instance of this object.
   */
  public static function createFromXmlRpc(XmlRpcQuery $xmlRpcQuery, array $select = ['*'], array $filters = array(), array $join = array(), $order = 'OFFICER_ID') {

    $xmlRpcQuery->prepare('Lodge.retrieve', 'lodgeofficer', $select, $filters, $join, $order);
    $xmlRpcQuery->execute();
    $results = $xmlRpcQuery->fetch();

    $officers = [];
    if (is_array($results) && count($results) > 0) {

      // Makes it possible to normalize date strings in x format as PHP
      // DateTime objects to get around the 32-bit date issue.
      $dateTimeNormalizer = new DateTimeNormalization('d-M-Y');
      foreach ($results as &$record) {
        // We're not creating DrupalDateTime objects straight from the database
        // date values because DrupalDateTime will convert it to a 32-bit date
        // and then we have dates which can't be before Dec 31, 1970 or after
        // Jan 18, 2038 which IS a BIG problem.

        // Normalize the TERMINATION_DATE as a PHP DateTime object.
        $terminationDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($record['TERMINATION_DATE'])->normalize();
        
        // Normalize the TOOK_OFFICE_DATE as a PHP DateTime object.
        $tookOfficeDate = (new XmlRpcValue($dateTimeNormalizer))->setValue($record['TOOK_OFFICE_DATE'])->normalize();

        // DrupalDateTime creation for best Drupal 8 compatibility.
        $record['TERMINATION_DATE'] = !$terminationDate ? null : DrupalDateTime::createFromDateTime($terminationDate);

        // DrupalDateTime creation for best Drupal 8 compatability.
        $record['TOOK_OFFICE_DATE'] = !$tookOfficeDate ? null : DrupalDateTime::createFromDateTime($tookOfficeDate);

        // Sometimes the STATUS field can be (NULL) in the database.
        // Account for that here and set the proper status when we create the
        // officer object.
        if (empty($record['STATUS'])) {
          if (empty($terminationDate)) {
            $record['STATUS'] = 'active';
          } else {
            $record['STATUS'] = 'inactive';
          }
        }

        // Add the officer recrod to the stack of officers.
        $officers[] = new static($xmlRpcQuery, LodgeOfficer::createFromArray($record));
      }
    }

    usort($officers, ['\Drupal\lodge\Value\XmlRpcLodgeOfficer', 'sortByNameAscending']);

    return $officers;
  }

  /**
   * Builds the officer data structure for used to map data for an officer to
   * the database through the XML-RPC service.
   *
   * {@inheritdoc}
   */
  protected function buildXmlRpcArray() {
    $officerId = empty($this->officer->getOfficerId()) ? null : trim($this->officer->getOfficerId());
    $terminationDate = is_null($this->officer->getTerminationDate()) || $this->officer->getStatus() == 'active' ? null : $this->officer->getTerminationDate('d-M-Y');
    $status = empty($terminationDate) ? 'active' : 'inactive';
    return [
      'LODGE_ID' => $this->officer->getLodgeId(),
      'OFFICER_ID' => $officerId,
      'OFFICETYPE_ID' => $this->officer->getOfficeTypeId(),
      'STATUS' => $status,
      'ADDRESS' => $this->officer->getAddress(),
      'CITY' => $this->officer->getCity(),
      'STATE' => $this->officer->getState(),
      'ZIP' => $this->officer->getZip(),
      'ZIP_EXT' => $this->officer->getZipExt(),
      'COUNTY_NAME' => $this->officer->getCountyName(),
      'EMAILADDRESS' => $this->officer->getEmailAddress(),
      'WORKPHONE' => $this->officer->getWorkPhone(),
      'CELLPHONE' => $this->officer->getCellPhone(),
      'FAX' => $this->officer->getFax(),
      'TAXID' => $this->officer->getTaxId(),
      'TOOK_OFFICE_DATE' => $this->officer->getTookOfficeDate('d-M-Y'),
      'TERMINATION_DATE' => $terminationDate,
      'FIRST_NAME' => $this->officer->getFirstName(),
      'MIDDLE_NAME' => $this->officer->getMiddleName(),
      'LAST_NAME' => $this->officer->getLastName(),
    ];
  }

  /**
   * Saves a lodge officer using the XML-RPC service.
   *
   * {@inheritdoc}
   */
  public function save() {
    if (is_null($this->officer) || empty($this->officer) || is_null($this->officer->getLodgeId()) || empty($this->officer->getLodgeId())) {
      return false;
    }

    $data = [
      \Drupal::currentUser()->getAccountName(),
      'lodgeofficer',
      $this->getXmlRpcArray(),
    ];

    if (empty($this->officer->getOfficerId())) {
      // Create a new lodge officer.
      unset($data[2]['OFFICER_ID']);
      $xmlRpcArgs = ['Lodge.create' => $data];
    } elseif (!is_null($this->officer->getOfficerId()) && !empty($this->officer->getOfficerId())){
      // Update an existing lodge officer.
      $data[] = ['OFFICER_ID = ' . trim($this->officer->getOfficerId()), 'LODGE_ID = ' . trim($this->officer->getLodgeId())];
      $xmlRpcArgs = ['Lodge.update' => $data];
    }

    $response = $this->xmlRpcQuery->getService()->handle($xmlRpcArgs);
    if (false != $response) {
      return true;
    }
    return false;
  }

  public function buildSearchResult() {
    $officer = $this->officer;
    $url = Url::fromRoute('lodge.viewofficer', ['lodge_id' => $officer->getLodgeId(), 'officer_id' => $officer->getOfficerId()]);
    $title =  Link::fromTextAndUrl($officer->getFullName(), $url)->toRenderable();
    $snippet = $officer->getFullName() . "\n" . $officer->getCountyName() . " County";
    $info = Link::fromTextAndUrl('View officer', $url)->toRenderable();
    return new SearchResult($title, $snippet, $info);
  }

  protected static function sortByNameAscending($a, $b) {    
    return strcmp(self::buildFullName($a), self::buildFullName($b));
  }

  protected static function buildFullName($record) {
    $firstName = $record->officer->getFirstName();
    $middleName = $record->officer->getMiddleName();
    $lastName = $record->officer->getLastName();
    return $firstName . ' ' . (!empty($middleName) ? ($middleName . ' ') : '') . $lastName;
  }
  
}
