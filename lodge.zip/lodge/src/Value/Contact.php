<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

/**
 * Description of Contact
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class Contact {

  protected $type;
  protected $value;

  public function __construct($type, $value) {
    $this->type = $type;
    $this->value = $value;
  }

  public function getType() {
    return $this->type;
  }

  public function getValue() {
    return $this->value;
  }

}
