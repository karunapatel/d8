<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\lodge\Service\XmlRpcLodgeService;
use Drupal\lodge\Value\AbstractXmlRpcValueObject;
use Drupal\lodge\Value\LodgeDues;

/**
 * Description of XmlRpcLodgeDues
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcLodgeDues extends AbstractXmlRpcValueObject {
  protected $lodgeService;
  protected $lodgeDues;

  public function __construct(XmlRpcLodgeService $lodgeService, LodgeDues $lodgeDues) {
    $this->lodgeService = $lodgeService;
    $this->lodgeDues = $lodgeDues;
  }

  public static function createFromXmlRpc(XmlRpcLodgeService $lodgeService, $lodgeId, $feeId = null) {

    $filters = [
      "ENTITY_TYPE='lodge'",
      "ENTITY_ID='{$lodgeId}'",
    ];

    if (!empty($feeId)) {
      $filters[] = "FEE_ID={$feeId}";
    }

    $xmlRpcArgs = [
      'Lodge.retrieve' =>
      [
        'fee',
        [
          'AMOUNT' => "to_char(AMOUNT, '$9,999.00')",
          'EFFECTIVE_DATE' => "to_char(EFFECTIVE_DATE, 'mm/dd/yyyy')",
          'EFFECTIVE_DATE2' => 'EFFECTIVE_DATE',
          'FEE_ID',
        ],
        $filters,
        [],
        'EFFECTIVE_DATE2 DESC',
      ],
    ];
    $results = $lodgeService->handle($xmlRpcArgs);
    $dues = [];
    if (!empty($results)) {
      foreach ($results as &$record) {
        $record['LODGE_ID'] = $lodgeId;
        $record['EFFECTIVE_DATE'] = $lodgeService->normalizeDate($record['EFFECTIVE_DATE2']);
        $dues[] = new static($lodgeService, LodgeDues::createFromArray($record));
      }
    }
    return $dues;
  }

  public function getLodgeDues() {
    return $this->lodgeDues;
  }

  protected function buildXmlRpcArray() {
    return [
      'FEE_TYPE_ID' => 'lodgefee',
      'ENTITY_TYPE' => 'lodge',
      'ENTITY_ID' => $this->lodgeDues->getLodgeId(),
      'AMOUNT' => $this->lodgeDues->getAmount(),
      'EFFECTIVE_DATE' => $this->lodgeDues->getEffectiveDate('d-M-Y'),
    ];
  }

  public function save() {
    if (empty($this->lodgeDues) || empty($this->lodgeDues->getLodgeId()) || empty($this->lodgeDues->getAmount())) {
      return false;
    }

    $xmlRpcArgs = [
      'Lodge.create' => [
        \Drupal::currentUser()->getAccountName(),
        'FEE', 
        $this->getXmlRpcArray(),
      ],
    ];

    if (false != $response = $this->lodgeService->handle($xmlRpcArgs)) {
      return $this->lodgeService->retrieveDues($this->lodgeDues->getLodgeId());
    }
    return false;
  }

  public function delete() {
    if (empty($this->lodgeDues->getFeeId())) {
      return false;
    }

    $xmlRpcArgs = [
      'Lodge.delete' =>
      [
        \Drupal::currentUser()->getAccountName(),
        'FEE',
        'FEE_ID='.$this->lodgeDues->getFeeId(),
      ],
    ];

    return $this->lodgeService->handle($xmlRpcArgs);
  }
}
