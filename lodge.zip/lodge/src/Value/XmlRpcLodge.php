<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\lodge\Entity\DateTimeNormalization;
use Drupal\lodge\Entity\XmlRpcQuery;
use Drupal\lodge\Entity\XmlRpcValue;
use Drupal\lodge\Value\AbstractXmlRpcValueObject;
use Drupal\lodge\Value\Lodge;
use Drupal\lodge\Value\SearchResult;

/**
 * Description of XmlRpcLodge
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class XmlRpcLodge extends AbstractXmlRpcValueObject {

  /**
   * XML-RPC query object.
   *
   * @var Drupal\lodge\Value\XmlRpcQuery
   */
  protected $xmlRpcQuery;

  /**
   * Lodge object.
   *
   * @var Drupal\lodge\Value\Lodge object.
   */
  protected $lodge;

  /**
   * Default constructor.
   *
   * @param XmlRpcQuery $xmlRpcQuery
   */
  public function __construct(XmlRpcQuery $xmlRpcQuery, Lodge $lodge) {
    $this->xmlRpcQuery = $xmlRpcQuery;
    $this->lodge = $lodge;
  }

  /**
   * Lodge object.
   *
   * @return Drupal\lodge\Value\Lodge object
   */
  public function getLodge() {
    return $this->lodge;
  }

  /**
   * Creates an instance of this object from the results of an XML-RPC response
   * query.
   *
   * @param XmlRpcQuery $xmlRpcQuery
   * @param array $select
   * @param array $filters
   * @param array $join
   * @param string $order
   * @return \static An instance of this object.
   */
  public static function createFromXmlRpc(XmlRpcQuery $xmlRpcQuery, array $select = ['*'], array $filters = array(), array $join = array(), $order = 'LODGE_ID') {

    $xmlRpcQuery->prepare('Lodge.retrieve', 'lodge', $select, $filters, $join, $order);
    $xmlRpcQuery->execute();
    $results = $xmlRpcQuery->fetch();
    
    $lodges = [];
    if (is_array($results) && count($results) > 0) {

      // Makes it possible to normalize date strings in x format as PHP
      // DateTime objects to get around the 32-bit date issue.
      $dateTimeNormalizer = new DateTimeNormalization('d-M-Y');
      foreach ($results as &$record) {

        $dateTimeValue = new XmlRpcValue($dateTimeNormalizer);
        // We're not creating DrupalDateTime objects straight from the database
        // date values because DrupalDateTime will convert it to a 32-bit date
        // and then we have dates which can't be before Dec 31, 1970 or after
        // Jan 18, 2038 which IS a BIG problem.

        // Normalize the ORGANIZED_DATE as a PHP DateTime object.
        $organizedDate = $dateTimeValue->setValue($record['ORGANIZED_DATE'])->normalize();
        // Normalize the DISBANDED_DATE as a PHP DateTime object.
        $disbandedDate = $dateTimeValue->setValue($record['DISBANDED_DATE'])->normalize();

        // Create a DrupalDateTime object from the PHP DateTime object.
        $record['ORGANIZED_DATE'] = !$organizedDate ? null : DrupalDateTime::createFromDateTime($organizedDate);
        // Create a DrupalDateTime object from the PHP DateTime object.
        $record['DISBANDED_DATE'] = !$disbandedDate ? null : DrupalDateTime::createFromDateTime($disbandedDate);

        // Add the lodge record to the stack of lodges.
        $lodges[] = new static($xmlRpcQuery, Lodge::createFromArray($record));
      }
    }
    if (!empty($lodges) && count($lodges) < 2) {
      return array_pop($lodges);
    }
    return $lodges;
  }

  /**
   * {@inheritdoc}
   */
  protected function buildXmlRpcArray() {
    $lodgeId = is_null($this->lodge->getLodgeId()) || empty($this->lodge->getLodgeId()) ? null : $this->lodge->getLodgeId();
    $disbandedDate = is_null($this->lodge->getDisbandedDate()) ? null : $this->lodge->getDisbandedDate('d-M-Y');
    return [
      'LODGE_ID' => $lodgeId,
      'NAME' => $this->lodge->getLodgeName(),
      'ORGANIZED_DATE' => $this->lodge->getOrganizedDate('d-M-Y'),
      'COUNTY_NAME' => $this->lodge->getCountyName(),
      'TIER_ID' => $this->lodge->getTierId(),
      'DISTRICT_ID' => $this->lodge->getDistrictId(),
      'APPLY_LODGE_REFUND' => $this->lodge->getApplyLodgeRefund(),
      'STATUS' => $this->lodge->getLodgeStatus(),
      'DISBANDED_DATE' => $disbandedDate,
    ];
  }

  /**
   * Saves a Lodge record.
   *
   * {@inheritdoc}
   */
  public function save() {

    $data = [
      \Drupal::currentUser()->getAccountName(),
      'lodge',
      $this->getXmlRpcArray(),
    ];

    $lodgeId = $this->lodge->getLodgeId();
    if (empty($this->xmlRpcQuery->getService()->retrieveLodge($lodgeId))) {
      // Create a new lodge officer
      $xmlRpcArgs = ['Lodge.create' => $data];
    } else {
      // Update an existing lodge officer.
      $data[] = ['LODGE_ID='.$lodgeId];
      $xmlRpcArgs = ['Lodge.update' => $data];
    }

    if (false != $response = $this->xmlRpcQuery->getService()->handle($xmlRpcArgs)) {
      return $this->xmlRpcQuery->getService()->retrieveLodge($this->lodge->getLodgeId());
    }
    return false;
  }

  public function buildSearchResult() {
    $lodge = $this->lodge;
    $url = Url::fromRoute('lodge.view', ['lodge_id' => $lodge->getLodgeId()]);
    $title =  Link::fromTextAndUrl($lodge->getLodgeName(), $url)->toRenderable();
    $snippet = $lodge->getLodgeName() . "\n" . $lodge->getCountyName() . " County";
    $info = Link::fromTextAndUrl('View lodge', $url)->toRenderable();
    return new SearchResult($title, $snippet, $info);
  }
}
