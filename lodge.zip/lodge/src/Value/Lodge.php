<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;
use Drupal\lodge\Service\XmlRpcLodgeService;

/**
 * Description of Lodge
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class Lodge {
  protected $id;
  protected $name;
  protected $organizedDate;
  protected $countyName;
  protected $tierId;
  protected $districtId;
  protected $applyLodgeRefund;
  protected $status;
  protected $disbandedDate;

  public function __construct(
    $id = null
    , $name = null
    , DrupalDateTime $organizedDate = null
    , $countyName = null
    , $tierId = null
    , $districtId = null
    , $applyLodgeRefund = null
    , $status = null
    , DrupalDateTime $disbandedDate = null
  ) {
    $this->setLodgeId($id);
    $this->setLodgeName($name);
    $this->setOrganizedDate($organizedDate);
    $this->setCountyName($countyName);
    $this->setTierId($tierId);
    $this->setDistrictId($districtId);
    $this->setApplyLodgeRefund($applyLodgeRefund);
    $this->setLodgeStatus($status);
    $this->setDisbandedDate($disbandedDate);
  }

  public static function createFromFormState(FormStateInterface $form_state) {

    $organizedDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('organized_date')));
    if (!empty($form_state->getValue('disbanded_date'))) {
      $disbandedDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('disbanded_date')));
    } else {
      $disbandedDate = null;
    }

    if (is_null($disbandedDate)) {
        $lodgeStatus = 'active';
    } else {
      $lodgeStatus = $form_state->getValue('lodge_status');
    }

    return static::createFromArray([
      'LODGE_ID' => $form_state->getValue('lodge_id')
      , 'NAME' => $form_state->getValue('lodge_name')
      , 'ORGANIZED_DATE' => $organizedDate
      , 'COUNTY_NAME' => $form_state->getValue('county_name')
      , 'TIER_ID' => $form_state->getValue('tier_id')
      , 'DISTRICT_ID' => $form_state->getValue('district_id')
      , 'STATUS' => $lodgeStatus
      , 'APPLY_LODGE_REFUND' => $form_state->getValue('apply_lodge_refund')
      , 'DISBANDED_DATE' => $disbandedDate
    ]);
  }

  public static function createFromArray(array $lodge) {
    return new static(
      $lodge['LODGE_ID']
      , $lodge['NAME']
      , $lodge['ORGANIZED_DATE']
      , $lodge['COUNTY_NAME']
      , $lodge['TIER_ID']
      , $lodge['DISTRICT_ID']
      , $lodge['APPLY_LODGE_REFUND']
      , $lodge['STATUS']
      , $lodge['DISBANDED_DATE']
    );
  }

  public function setLodgeId($id = null) {
    $this->id = $id;
  }

  public function setLodgeName($name = null) {
    $this->name = $name;
  }

  public function setOrganizedDate(DrupalDateTime $organizedDate = null) {
    $this->organizedDate = $organizedDate;
  }

  public function setCountyName($countyName = null) {
    $this->countyName = $countyName;
  }

  public function setTierId($tierId = null) {
    $this->tierId = $tierId;
  }

  public function setDistrictId($districtId = null) {
    $this->districtId = $districtId;
  }

  public function setApplyLodgeRefund($applyLodgeRefund = null) {
    $this->applyLodgeRefund = $applyLodgeRefund;
  }

  public function setLodgeStatus($status = null) {
    $this->status = $status;
  }

  public function setDisbandedDate(DrupalDateTime $disbandedDate = null) {
    $this->disbandedDate = $disbandedDate;
  }

  public function getLodgeId() {
    return $this->id;
  }

  public function getLodgeName() {
    return $this->name;
  }

  public function getOrganizedDate($format = '') {
    if (is_null($this->organizedDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->organizedDate;
    }
    return $this->organizedDate->format($format);
  }

  public function getCountyName() {
    return $this->countyName;
  }

  public function getTierId() {
    return $this->tierId;
  }

  public function getDistrictId() {
    return $this->districtId;
  }

  public function getApplyLodgeRefund() {
    return $this->applyLodgeRefund;
  }

  public function getLodgeStatus() {
    return $this->status;
  }

  public function getDisbandedDate($format = '') {
    if (is_null($this->disbandedDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->disbandedDate;
    }
    return $this->disbandedDate->format($format);
  }

  public function getLodgeStatusMap() {
    return ['active' => t('Active'), 'disbanded' => t('Disbanded')];
  }
}
