<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of LodgeOfficer
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeOfficer {

  protected $lodgeId;
  protected $officerId;
  protected $officeTypeId;
  protected $status;
  protected $address;
  protected $city;
  protected $state;
  protected $zip;
  protected $zipExt;
  protected $countyName;
  protected $workPhone;
  protected $cellPhone;
  protected $fax;
  protected $emailAddress;
  protected $taxId;
  protected $tookOfficeDate;
  protected $terminationDate;
  protected $firstName;
  protected $middleName;
  protected $lastName;

  public function __construct(
    $lodgeId = null
    , $officerId = null
    , $officeTypeId = null
    , $status = null
    , $address = null
    , $city = null
    , $state = null
    , $zip = null
    , $zipExt = null
    , $countyName = null
    , $workPhone = null
    , $cellPhone = null
    , $fax = null
    , $emailAddress = null
    , $taxId = null
    , DrupalDateTime $tookOfficeDate = null
    , DrupalDateTime $terminationDate = null
    , $firstName = null
    , $middleName = null
    , $lastName = null
  ) {
    $this->setLodgeId($lodgeId);
    $this->setOfficerId($officerId);
    $this->setOfficeTypeId($officeTypeId);
    $this->setStatus($status);
    $this->setAddress($address);
    $this->setCity($city);
    $this->setState($state);
    $this->setZip($zip);
    $this->setZipExt($zipExt);
    $this->setCountyName($countyName);
    $this->setWorkPhone($workPhone);
    $this->setCellPhone($cellPhone);
    $this->setFax($fax);
    $this->setEmailAddress($emailAddress);
    $this->setTaxId($taxId);
    $this->setTookOfficeDate($tookOfficeDate);
    $this->setTerminationDate($terminationDate);
    $this->setFirstName($firstName);
    $this->setMiddleName($middleName);
    $this->setLastName($lastName);
  }

  public static function createFromFormState(FormStateInterface $form_state) {
    $taxId = $form_state->getValue('tax_id_number');
    $taxId = isset($taxId) && !empty($taxId) ? str_replace('-', '', $form_state->getValue('tax_id_number')) : null;
    $workphone = str_replace(['(', ')', '-', ' '], '', $form_state->getValue('work_phone'));
    $cellphone = str_replace(['(', ')', '-', ' '], '', $form_state->getValue('cell_phone'));
    $fax = str_replace(['(', ')', '-', ' '], '', $form_state->getValue('fax'));
    $tookOfficeDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('took_office_date')));
    
    if (!empty($form_state->getValue('termination_date'))) {
      $terminationDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('termination_date')));
    }
    else {
      $terminationDate = null;
    }

    if (is_null($terminationDate)) {
      $status = 'active';
    } else {
      $status = $form_state->getValue('officer_status');
    }

    $officer = static::createFromArray([
        'LODGE_ID' => $form_state->getValue('lodge_id')
        , 'OFFICER_ID' => $form_state->getValue('officer_id')
        , 'OFFICETYPE_ID' => $form_state->getValue('office_type_id')
        , 'STATUS' => $status == 'terminated' ? 'inactive' : $status
        , 'ADDRESS' => $form_state->getValue('street')
        , 'CITY' => $form_state->getValue('city')
        , 'STATE' => $form_state->getValue('state')
        , 'ZIP' => $form_state->getValue('zip')
        , 'ZIP_EXT' => empty($form_state->getValue('zip_ext')) ? null : $form_state->getValue('zip_ext')
        , 'COUNTY_NAME' => $form_state->getValue('county')
        , 'WORKPHONE' => $workphone
        , 'CELLPHONE' => $cellphone
        , 'FAX' => $fax
        , 'EMAILADDRESS' => $form_state->getValue('email_address')
        , 'TAXID' => $taxId
        , 'TOOK_OFFICE_DATE' => $tookOfficeDate
        , 'TERMINATION_DATE' => $terminationDate
        , 'FIRST_NAME' => $form_state->getValue('first_name')
        , 'MIDDLE_NAME' => empty($form_state->getValue('middle_name')) ? null : $form_state->getValue('middle_name')
        , 'LAST_NAME' => $form_state->getValue('last_name')
    ]);

    return $officer;
  }

  public static function createFromArray(array $lodgeOfficer) {
    return new static(
        $lodgeOfficer['LODGE_ID']
        , $lodgeOfficer['OFFICER_ID']
        , $lodgeOfficer['OFFICETYPE_ID']
        , $lodgeOfficer['STATUS']
        , $lodgeOfficer['ADDRESS']
        , $lodgeOfficer['CITY']
        , $lodgeOfficer['STATE']
        , $lodgeOfficer['ZIP']
        , $lodgeOfficer['ZIP_EXT']
        , $lodgeOfficer['COUNTY_NAME']
        , $lodgeOfficer['WORKPHONE']
        , $lodgeOfficer['CELLPHONE']
        , $lodgeOfficer['FAX']
        , $lodgeOfficer['EMAILADDRESS']
        , $lodgeOfficer['TAXID']
        , $lodgeOfficer['TOOK_OFFICE_DATE']
        , $lodgeOfficer['TERMINATION_DATE']
        , $lodgeOfficer['FIRST_NAME']
        , $lodgeOfficer['MIDDLE_NAME']
        , $lodgeOfficer['LAST_NAME']
    );
  }

  public function setLodgeId($lodgeId) {
    $this->lodgeId = $lodgeId;
  }

  public function setOfficerId($officerId) {
    $this->officerId = $officerId;
  }

  public function setOfficeTypeId($officeTypeId) {
    $this->officeTypeId = $officeTypeId;
  }

  public function setStatus($status) {
    $this->status = $status;
  }

  public function setAddress($address) {
    $this->address = $address;
  }

  public function setCity($city) {
    $this->city = $city;
  }

  public function setState($state) {
    $this->state = $state;
  }

  public function setZip($zip) {
    $this->zip = $zip;
  }

  public function setZipExt($zipExt) {
    $this->zipExt = $zipExt;
  }

  public function setCountyName($countyName) {
    $this->countyName = $countyName;
  }

  public function setWorkPhone($workPhone) {
    $this->workPhone = $workPhone;
  }

  public function setCellPhone($cellPhone) {
    $this->cellPhone = $cellPhone;
  }

  public function setFax($fax) {
    $this->fax = $fax;
  }

  public function setEmailAddress($emailAddress) {
    $this->emailAddress = $emailAddress;
  }

  public function setTaxId($taxId) {
    $this->taxId = $taxId;
  }

  public function setTookOfficeDate(DrupalDateTime $tookOfficeDate = null) {
    $this->tookOfficeDate = $tookOfficeDate;
  }

  public function setTerminationDate(DrupalDateTime $terminationDate = null) {
    $this->terminationDate = $terminationDate;
  }

  public function setFirstName($firstName) {
    $this->firstName = $firstName;
  }

  public function setMiddleName($middleName) {
    $this->middleName = $middleName;
  }

  public function setLastName($lastName) {
    $this->lastName = $lastName;
  }

  public function getLodgeId() {
    return $this->lodgeId;
  }

  public function getOfficerId() {
    return $this->officerId;
  }

  public function getOfficeTypeId() {
    return $this->officeTypeId;
  }

  public function getOfficeTypeName() {
    $officeTypeNames = static::getOfficeTypeNameMap();
    $officeTypeId = $this->officeTypeId;
    if (array_key_exists($officeTypeId, $officeTypeNames)) {
      return $officeTypeNames[$officeTypeId];
    }
    return '';
  }

  public static function getOfficeTypeNameMap() {
    return [
      'president' => t('President'),
      'vicepresident' => t('Vice President'),
      'secretary' => t('Secretary'),
      'finance' => t('Finance Secretary'),
      'adjuster' => t('State Adjuster'),
      'treasurer' => t('Treasurer'),
//      'agent' => t('Agent'), /* Teamwork Desk #1949393
    ];
  }

  public function getStatus() {
    return $this->status;
  }

  public function getAddress() {
    return $this->address;
  }

  public function getCity() {
    return $this->city;
  }

  public function getState() {
    return $this->state;
  }

  public function getZip() {
    return $this->zip;
  }

  public function getZipExt() {
    return $this->zipExt;
  }

  public function getFullZipCode() {
    return $this->zip . (!empty($this->zipExt) ? ('-' . $this->zipExt) : '');
  }

  public function getCountyName() {
    return $this->countyName;
  }

  public function getWorkPhone() {
    return $this->workPhone;
  }

  public function getCellPhone() {
    return $this->cellPhone;
  }

  public function getFax() {
    return $this->fax;
  }

  public function getEmailAddress() {
    return $this->emailAddress;
  }

  public function getTaxId() {
    return $this->taxId;
  }

  public function getTookOfficeDate($format = '') {
    if (is_null($this->tookOfficeDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->tookOfficeDate;
    }
    return $this->tookOfficeDate->format($format);
  }

  public function getTerminationDate($format = '') {
    if (is_null($this->terminationDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->terminationDate;
    }
    return $this->terminationDate->format($format);
  }

  public function getFirstName() {
    return $this->firstName;
  }

  public function getMiddleName() {
    return $this->middleName;
  }

  public function getLastName() {
    return $this->lastName;
  }

  public function getFullName() {
    return $this->firstName . (!empty($this->middleName) ? (' ' . $this->middleName) : '') . ' ' . $this->lastName;
  }

  public static function getLodgeStatusMap() {
    return ['active' => t('Active'), 'terminated' => t('Terminated')];
  }

}
