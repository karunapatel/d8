<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of LodgeDues
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class LodgeDues {

  protected $amount;
  protected $effectiveDate;
  protected $feeId;
  protected $lodgeId;

  public function __construct($lodgeId = null, $amount = null, DrupalDateTime $effectiveDate = null, $feeId = null) {
    $this->lodgeId = $lodgeId;
    $this->amount = $amount;
    $this->effectiveDate = $effectiveDate;
    $this->feeId = $feeId;
  }

  public static function createFromFormState(FormStateInterface $form_state) {

    $effectiveDate = DrupalDateTime::createFromDateTime(new \DateTime($form_state->getValue('dues_effective_date')));

    return static::createFromArray([
      'LODGE_ID' => $form_state->getValue('lodge_id'),
      'AMOUNT' => $form_state->getValue('dues_amount'),
      'EFFECTIVE_DATE' => $effectiveDate,
    ]);
  }

  public static function createFromArray(array $lodgeDues) {
    return new static(
      $lodgeDues['LODGE_ID']
      , $lodgeDues['AMOUNT']
      , $lodgeDues['EFFECTIVE_DATE']
      , isset($lodgeDues['FEE_ID']) ? $lodgeDues['FEE_ID'] : null
    );
  }

  public function setLodgeId($lodgeId = null) {
    $this->lodgeId = $lodgeId;
  }

  public function setAmount($amount = null) {
    $this->amount = $amount;
  }

  public function setEffectiveDate(DrupalDateTime $effectiveDate = null) {
    $this->effectiveDate = $effectiveDate;
  }

  public function setFeeId($feeId) {
    $this->feeId = $feeId;
  }

  public function getLodgeId() {
    return $this->lodgeId;
  }

  public function getAmount() {
    return $this->amount;
  }

  public function getEffectiveDate($format = '') {
    if (is_null($this->effectiveDate)) {
      return null;
    }
    if (empty($format)) {
      return $this->effectiveDate;
    }
    return $this->effectiveDate->format($format);
  }

  public function getFeeId() {
    return $this->feeId;
  }
}
