<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

/**
 * Description of XmlRpcValueObjectInterface
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
interface XmlRpcValueObjectInterface {

  public function save();

  public function getXmlRpcArray();
}
