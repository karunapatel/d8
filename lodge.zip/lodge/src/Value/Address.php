<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

/**
 * Description of Address
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class Address {

  protected $street;
  protected $city;
  protected $state;
  protected $zip;
  protected $zipExt;
  protected $county;

  public function __construct($street, $city, $state, $zip, $county, $zipExt = null) {
    $this->street = $street;
    $this->city = $city;
    $this->state = $state;
    $this->zip = $zip;
    $this->zipExt = $zipExt;
    $this->county = $county;
  }

  public function getStreet() {
    return $this->street;
  }

  public function getCity() {
    return $this->city;
  }

  public function getState() {
    return $this->state;
  }

  public function getZip() {
    return $this->zip;
  }

  public function getZipExt() {
    return $this->zipExt;
  }

  public function getCounty() {
    return $this->county;
  }

}
