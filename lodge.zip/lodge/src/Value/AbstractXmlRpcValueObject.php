<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Value;

use Drupal\lodge\Value\XmlRpcValueObjectInterface;

/**
 * Description of AbstractXmlRpcValueObject
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
abstract class AbstractXmlRpcValueObject implements XmlRpcValueObjectInterface {

  /**
   * Responsible for performing an update call over XML-RPC to save data either
   * through an insert or an update.
   */
  abstract public function save();

  /**
   * Gets the XML-RPC data structure.
   * 
   * @return array  Data array which can be mapped to database table via the
   * XML-RPC service.
   */
  public function getXmlRpcArray() {
    return $this->buildXmlRpcArray();
  }

  /**
   * Builds an array representing a lodge for sending a request to the XML-RPC
   * lodge service. Used to insert/update a lodge record.
   *
   * @return array An array representing a lodge record in the form of
   * field => field_value.
   */
  abstract protected function buildXmlRpcArray();
}
