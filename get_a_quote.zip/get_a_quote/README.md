# Get a Quote

This module is used with commerce module to get a quote for the product on the cart.

## Configuration settings

It has configuration settings to enable get a quote option on commerce checkout flow at review state which can be found in below mentioned path

`admin/commerce/config/quote`

=============================
     
### Requirements

* commerce

===========