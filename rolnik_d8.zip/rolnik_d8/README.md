# Rolnik

Rolnik allows management of the Rolnik magazine opt-in/out for the digital 
magazine instead of the physical magazine.

## Getting Started

Pull down a copy of the module from stash.rvos.com and put it into the modules
folder in the root Drupal 8 directory. If you follow typical stands the module
should go into either the contributed or custom modules folder depending on
whether or not your pulling it down as a contributed module or as in-house.

### Prerequisites

There are no pre-requisites at this time.

### Installing

#### Manual installation
Place the rolnik module into the your Drupal8/modules folder. Navigate
to the extend page in Drupal 8 and tick the checkbox next to the rolnik
module. Click the save button to finalize your selections.

#### Composer installation
Add https://git@stash.rvos.com:8443/scm/cp/ldap.git to your composer.json file
under the repositories section as a vcs or git type.

Use `composer install 'czechpoint/rolnik:^1.0' to install from composer

### Configuration
Do not forget to configure the database configuration options from the Rolnik
configuration page.

## Contributing

Please read CONTRIBUTING.md for details.

## Authors 
 * Daniel Taylor - Contributer - [email](mailto:dtaylor@rvos.com)

## License

Please read LICENSE.md for details.
