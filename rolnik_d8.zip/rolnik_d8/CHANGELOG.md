# Changelog
All notable changes to this project will be documented in this file.

## [v8.x-1.0] - 2018-03-02
### Added
- Converted to Drupal 8 from Drupal 7.

### Changed
- Extra members is now a node referenced within the module itself.
- Pages are tabs.
- Manage list is the default page now. Available via the 'access rolnik' permission.
- Extra Members and Download list pages are only available with 'manage rolnik' permission.
