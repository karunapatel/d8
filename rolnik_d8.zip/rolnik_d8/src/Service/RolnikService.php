<?php
/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
namespace Drupal\rolnik\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\rolnik\Repository\AbstractOracleDatabaseAccessObject;

/**
 * Description of RolnikServices
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class RolnikService extends AbstractOracleDatabaseAccessObject
{

  /**
   * Configuration factory.
   * 
   * @var ConfigFactoryInterface 
   */
  protected $config = null;
    
  /**
   * Default constructor.
   */
  public function __construct(ConfigFactoryInterface $config_factory)
  {
    $this->config = $config_factory->get('rolnik.settings');

    if (!is_null($config_factory)) {
      $this->connect(
        $this->config->get('rolnik_db_protocol')
        , $this->config->get('rolnik_db_host')
        , $this->config->get('rolnik_db_port')
        , $this->config->get('rolnik_db_sid')
        , $this->config->get('rolnik_db_username')
        , $this->config->get('rolnik_db_password'));

      return $this;
    }
  }
  
  /**
   * Creates a new instance of this object.
   * 
   * @param ConfigFactoryInterface $config
   * @return \static
   */
  public static function create(ConfigFactoryInterface $config) {
    return new static($config);
  }
}
