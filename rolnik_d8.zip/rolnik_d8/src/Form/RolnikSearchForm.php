<?php
/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
namespace Drupal\rolnik\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\rolnik\Query\QueryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\rolnik\Repository\DatabaseConnectionInterface;
use Drupal\Core\Url;

/**
 * Description of RolnikSearchForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class RolnikSearchForm extends FormBase
{

  /**
   * @var DatabaseConnectionInterface
   */
  protected $dao;

  /**
   * @var QueryInterface
   */
  protected $customerQuery;
  protected $customerInsertQuery;
  protected $customerDeleteQuery;
  protected $steps;
  protected $step;
  protected $finalizeRedirectPath;

  /**
   * Constructs a \Drupal\rolnik\Form\RolnikSearchForm object.
   * Customized for RolnikSearchForm.
   *
   * @param DatabaseConnectionInterface $dao
   * @param QueryInterface $customer_query
   */
  public function __construct(DatabaseConnectionInterface $dao, QueryInterface $customer_query, QueryInterface $customer_insert_query, QueryInterface $customer_delete_query)
  {
    $this->dao = $dao;
    $this->customerQuery = $customer_query;
    $this->customerInsertQuery = $customer_insert_query;
    $this->customerDeleteQuery = $customer_delete_query;
  }

  /**
   * Creates a \Drupal\rolnik\Form\RolnikSearchForm object.
   * Customized for
   *
   * @param ContainerInterface $container
   * @return \static
   */
  public static function create(ContainerInterface $container)
  {
    return new static(
      $container->get('rolnik.dao')
      , $container->get('rolnik.customerquery')
      , $container->get('rolnik.customerinsertquery')
      , $container->get('rolnik.customerdeletequery')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId()
  {
    return 'rolnik_search_form';
  }

  protected function buildSteps()
  {
    return [
      1 => 'customerRolnikSearch',
      2 => 'customerRolnikOpt',
      3 => 'customerRolnikOptConfirm',
    ];
  }

  private function setStep(FormStateInterface $form_state)
  {
    $steps = $this->steps = $this->buildSteps();
    $step = $form_state->getValue('step');
    if (empty($step)) {
      $step = 1;
      $form_state->setValue('step', $step);
    }
    $this->step = $step;
  }

  /**
   * The Rolnik admin settings form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
    $this->finalizeRedirectPath = 'manager.list';
    $this->setStep($form_state);
    $step = $this->step;

    $form['step'] = [
      '#type' => 'hidden',
      '#value' => $step,
    ];

    $fn = $this->steps[$step];
    if (!method_exists($this, $fn)) {
      $mailto = 'operations@rvos.com';
      $inbox = 'Computer Operations';
      $subject = $this->t('Rolnik step error');
      $body = $this->t('An error occurred in the step navigation for the Rolnik module while navigating to step @step.', ['@step' => $step]);
      $form['error']['step_not_exists'] = [
        '#type' => 'markup',
        '#markup' => '<p>An error occurred while processing your request.</p>'
        . '<p>If you continue to get this error please contact '
        . '<a href="mailto:' . $mailto . '?subject=' . rawurlencode($subject) . '&body=' . rawurlencode($body) . '">' . $inbox . '</a>.',
      ];
      drupal_set_message($body, 'error');
      $this->logger('rolnik')->error($body);
      // Return with the navigation error.
      return $form;
    }

    // build the step.
    $this->$fn($form, $form_state);
    // build the step actions.
    $this->formActions($form, $form_state);

    // Search page button text = 'Go'.
    if ((int) $step === 1) {
      $form['actions']['next']['#value'] = $this->t('Go');
    }

    // Confirmation page button text = 'Confirm'.
    if ((int) $step === 3) {
      $form['actions']['next']['#value'] = $this->t('Confirm');
    }

    // Return the step.
    return $form;
  }

  /**
   * Form actions for the multi-step form.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  private function formActions(array &$form, FormStateInterface $form_state)
  {

    $steps = $this->steps;
    $step = $this->step;
    end($steps);
    $last_step = key($steps);
    reset($steps);
    $first_step = key($steps);

    $form['actions'] = [
      '#type' => 'actions',
      '#prefix' => '<div class="container-inline">',
      '#suffix' => '</div>',
    ];

    if ((int) $step > (int) $first_step) {
      $form['actions']['previous'] = [
        '#type' => 'submit',
        '#value' => t('Previous'),
        '#prefix' => '<span class="text-align-left span-half-width">',
        '#suffix' => '</span>',
        '#name' => 'previous',
        '#attributes' => ['class' => ['btn-primary']],
      ];
    }

    $buttonText = t('Submit');
    $buttonName = 'submit';
    if ((int) $step !== (int) $last_step) {
      $buttonText = t('Next');
      $buttonName = 'continue';
    }

    $form['actions']['next'] = [
      '#type' => 'submit',
      '#value' => $buttonText,
      '#prefix' => '<span class="text-align-right' . (empty($form['actions']['previous']) ? ' span-full-width' : ' span-half-width') . '">',
      '#suffix' => '</span>',
      '#name' => $buttonName,
      '#attributes' => ['class' => [
        'btn-primary',
        ],
      ],
    ];
  }

  /**
   * The customer search form for Rolnik digital magazine opt-in/out.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  private function customerRolnikSearch(array &$form, FormStateInterface $form_state)
  {
    $step = $this->step;
    $fn = $this->steps[$step];
    $values = $form_state->get(['storage', $fn]);

    if (empty($values)) {
      $values = $form_state->getValues();
    }

    $form['tt']['name'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#required' => true,
    );

    $form['tt']['zip'] = array(
      '#title' => $this->t('ZIP'),
      '#type' => 'textfield',
      '#required' => true,
      '#maxlength' => 5,
    );
  }

  /**
   * The customer listing for the search results for the opt-in/out. Each record
   * has a radio button to change opt-in/out status.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  private function customerRolnikOpt(array &$form, FormStateInterface $form_state)
  {

    $fn = $this->steps[$this->step];
    $values = $form_state->get(['storage', $fn]);
    if (empty($values)) {
      $values = $form_state->getValues();
    }

    $prev_step_store = $form_state->get(['storage', 'customerRolnikSearch']);
    $name = strtoupper($prev_step_store['name']);
    $zipcode = $prev_step_store['zip'];

    if (!empty($name) && !empty($zipcode)) {
      $results = $this->customerQuery->execute([':name' => $name, ':zipcode' => $zipcode]);
      $form_state->set(['storage', 'customers'], json_encode($results));

      $form['search_results_title'] = [
        '#markup' => '<h2>' . $this->t('Search results') . '</h2>',
      ];

      $form['optout'] = array(
        '#type' => 'fieldset',
        '#prefix' => '<div id="search-result-list">',
        '#suffix' => '</div>',
        '#title' => $this->t('Rolnik Exclusion List - Choose Customer to Change'),
      );

      $header = [
        'exclude' => t('Exclude Now'),
        'fullname' => t('Full Name'),
        'address' => t('Address'),
        'city' => t('City'),
        'system' => t('Cesta'),
        'customerno' => t('Customer No.'),
        'excludedinfo' => t('Customer Excluded?'),
      ];

      $form['optout']['table'] = [
        '#type' => 'table',
        '#header' => $header,
        '#empty' => t('No records found.'),
      ];

      foreach ($results as $idx => $result) {

        $exclude_options = $this->getExclusionOptions();
        $form['optout']['table'][$idx]['exclude'] = [
          '#type' => 'radios',
          '#options' => $exclude_options,
          '#default_value' => (string) $result->EXCLUDED != 'Yes' ? 0 : 1,
          '#prefix' => '<div class="container-inline">',
          '#suffix' => '</div>',
          '#attributes' => ['class' => ['table-search-results']],
        ];

        $form['optout']['table'][$idx]['name'] = [
          '#type' => 'markup',
          '#markup' => $result->NAME,
        ];

        $form['optout']['table'][$idx]['address'] = [
          '#type' => 'markup',
          '#markup' => $result->ADDRESS,
        ];

        $form['optout']['table'][$idx]['city'] = [
          '#type' => 'markup',
          '#markup' => $result->CITY,
        ];

        $form['optout']['table'][$idx]['system'] = [
          '#type' => 'markup',
          '#markup' => $result->SYSTEM,
        ];

        $form['optout']['table'][$idx]['customerno'] = [
          '#type' => 'markup',
          '#markup' => $result->CUSTOMER_NUMBER,
        ];

        $form['optout']['table'][$idx]['excludedinfo'] = [
          '#type' => 'markup',
          '#markup' => $result->EXCLUDED,
        ];
      }
    }
  }

  /**
   * Conformation form for the opt-in/out status to confirm changes for all
   * records being updated.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  private function customerRolnikOptConfirm(array &$form, FormStateInterface $form_state)
  {
    $exclude_options = $this->getExclusionOptions();

    $header = [
      'fullname' => t('Full Name'),
      'customerno' => t('Customer No.'),
      'excludedinfo' => t('Customer Excluded ?'),
      'changeto' => t('Change to'),
    ];

    $form['optout']['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#caption' => t('Rolnik Exclusion List - Please Confirm Change'),
      '#empty' => t('No records found.'),
    ];

    $customers = $form_state->get(['storage', 'customers']);

    foreach ($customers as $idx => $customer) {
      $form['optout']['table'][$idx]['name'] = [
        '#type' => 'markup',
        '#markup' => $customer->NAME,
      ];

      $form['optout']['table'][$idx]['customerno'] = [
        '#type' => 'markup',
        '#markup' => $customer->CUSTOMER_NUMBER,
      ];

      $form['optout']['table'][$idx]['excludedinfo'] = [
        '#type' => 'markup',
        '#markup' => $customer->EXCLUDED,
      ];

      $form['optout']['table'][$idx]['changeto'] = [
        '#type' => 'markup',
        '#markup' => $exclude_options[$customer->CHANGETO],
      ];
    }
  }

  /**
   * Returns the exclusion options for use in the opt-in/out radio selection
   * element.
   *
   * @return array
   */
  private function getExclusionOptions()
  {
    return [0 => t('No'), 1 => t('Yes')];
  }

  /**
   * Handle the validation of the rolnik search form.
   *
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    parent::validateForm($form, $form_state);

    $step = $form_state->getValue('step');
    $steps = $this->buildSteps();
    $fn = $this->steps[$this->step] . 'Validate';
    if (method_exists($this, $fn)) {
      $this->$fn($form, $form_state);
    }
  }

  public function customerRolnikOptValidate(array &$form, FormStateInterface $form_state)
  {
    // Nothing to really do here...
  }

  public function customerRolnikOptConfirmValidate(array &$form, FormStateInterface $form_state)
  {
    // Not sure there is anything to do here...
  }

  /**
   * Primary submit handler
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    // Get the current step;
    $step = $this->step;

    // Process submit handler for the current step we are on if it has been
    // defined.
    $stepName = $this->steps[$step];
    $fn = $stepName . 'Submit';
    if (method_exists($this, $stepName)) {
      $this->$fn($form, $form_state);
    }

    // Setup for the next/previous step based on the triggering element.
    $triggering_element = $form_state->getTriggeringElement();
    switch ($triggering_element['#name']) {
      case 'previous':
        // Don't validate the fields on the current form when returning to the
        // previous step.
        $form_state->setLimitValidationErrors([]);
        // Set the step value to the previous step.
        $form_state->setValue('step', $step - 1);
        // We have to rebuild the form state, else the page value will be empty and
        // we'll always get step 1.
        $form_state->setRebuild('true');
        // Make sure we save the currently entered values into the form state storage.
        $form_state->set(['storage', $stepName], $form_state->getValues());
        break;
      case 'submit':
        // Clear the form storage.
        $form_state->set('storage', []);
        $form_state->setValue('step', 1);
        // we don't have to create a redirect here as the form should automatically
        // return to step one with the statements above.
        break;
      default:
        // Set the step value to the next step
        $form_state->setValue('step', $step + 1);
        // We have to rebuild the form state, else the page value will be empty and
        // we'll always get step 1.
        $form_state->setRebuild('true');
        // Make sure we save the currently entered values into the form state storage.
        $form_state->set(['storage', $stepName], $form_state->getValues());
        break;
    }
  }

  /**
   * Submit handler for the customer search step.
   *
   * @param array $form
   *  Drupal form array
   * @param FormStateInterface $form_state
   */
  public function customerRolnikSearchSubmit(array &$form, FormStateInterface $form_state)
  {
    // Nothing to do here at this time...
  }

  /**
   * Submit handler for the customer opt-in/out step.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  public function customerRolnikOptSubmit(array &$form, FormStateInterface $form_state)
  {

    // Get the list of queried customers.
    $customers = json_decode($form_state->get(['storage', 'customers']));

    // Loop through each of the customers and get the selected radio option
    // from the form state for that customer.
    // Add a new field labeled 'changeto' and store the radio button selection
    // for the customer.
    $data = $form_state->getValue('table');
    foreach ($customers as $idx => $customer) {

      $selection = $data[$idx]['exclude'];
      $customers[$idx]->CHANGETO = $selection;
    }

    // Save the customer data back to the storage in form_state
    $form_state->set(['storage', 'customers'], $customers);
  }

  /**
   * Submit handler for the customer opt-in/out confirmation step.
   *
   * @param array $form
   * @param FormStateInterface $form_state
   */
  public function customerRolnikOptConfirmSubmit(array &$form, FormStateInterface $form_state)
  {
    // Only process on a submit button press (or confirm button) in this case.
    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element['#name'] == 'submit') {
      $exclustion_options = $this->getExclusionOptions();
      $customers = $form_state->get(['storage', 'customers']);
      $changes = [];
      foreach ($customers as $idx => $customer) {
        $excluderesult = $customer->CHANGETO;
        $changeTo = $exclustion_options[$excluderesult]->getUntranslatedString();
        $existing = $customer->EXCLUDED;

        if ($changeTo == $existing) {
          continue;
        }

        // store what changed.
        $changes[] = $customer;
        $bindArgs = [':customer_number' => $customer->CUSTOMER_NUMBER];
		$exlude = $excluderesult; // will resolved undefined $exlude variable issue
		$name = $customer->NAME; // changes made to customer name
        $this->updateRolnikCustomer($exlude, $bindArgs, $name);  // passed third parameter $name as $customer at 553 was undefined
      }

      if (count($changes) <= 0) {
        drupal_set_message(t('No customers were changed because you did not make any changes to the customers.'));
      }
    }
  }

  /**
   * Updates the record for the rolnik customer.
   * 
   * @param type $exclude
   * @param array $bindArgs
   */
  private function updateRolnikCustomer($exclude, array $bindArgs, $name) {
    // User is opted in for digital magazine instead of physical copy.
/* echo'<pre>'; 
print_r($name); exit; */
    if ((int) $exclude === 1) {
      if ($this->customerInsertQuery->execute($bindArgs)) {
        drupal_set_message(t('The customer, %name, has been removed from the Rolnik mailing list and <strong>will not</strong> receive the mailed version.', ['%name' => $name]));
      } else {
        drupal_set_message(t('The customer, %name, could not be removed from the Rolnik mailing list and <strong>will</strong> continue to receive the mailed version.', ['%name' => $name]), 'warning');
      }
    }

    // User is opted out of digital magazine and will receive physical copy.
    if ((int) $exclude === 0) {
      if ($this->customerDeleteQuery->execute($bindArgs)) {
        drupal_set_message(t('The customer, %name, has been added to the Rolnik mailing list and <strong>will</strong> receive the mailed version.', ['%name' => $name]));
      } else {
        drupal_set_message(t('The customer, %name, could not be added to the Rolnik mailing list and <strong>will not</strong> receive the mailed version.', ['%name' => $name]), 'warning');
      }
    }
  }
}
