<?php
/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
namespace Drupal\rolnik\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of RolnikSettingsForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class RolnikSettingsForm extends ConfigFormBase
{

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames()
  {
    return ['rolnik.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId()
  {
    return 'rolnik_admin_settings';
  }

  /**
   * The Rolnik admin settings form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {

    $config = $this->config('rolnik.settings');
    $settings = $config->get();

    $form['rolniklist'] = array(
      '#type' => 'fieldset',
      '#title' => $this->t('Rolnik List Settings'),
    );
    $form['rolniklist']['rolnik_record_per_piece'] = array(
      '#title' => $this->t('Records per piece'),
      '#description' => $this->t('No. of records should be downloaded at one time.'),
      '#type' => 'textfield',
      '#default_value' => $config->get('rolnik_record_per_piece'),
      '#required' => true,
    );

    $nodeId = !empty($settings['rolnik_extra_members_node']) ? $settings['rolnik_extra_members_node'] : '';
    $nodeManager = \Drupal::entityTypeManager()->getStorage('node');
    $entity = $nodeManager->load($nodeId);
    $form['rolniklist']['rolnik_extra_members_node'] = [
      '#type' => 'entity_autocomplete',
      '#title' => t('Extra Members Node'),
      '#description' => t('The node used to manage the extra members file.'),
      '#target_type' => 'node',
      '#default_value' => $entity,
      '#required' => true,
    ];

    $form['r_oracle'] = [
      '#type' => 'fieldset',
      '#title' => t('Oracle settings for Rolnik'),
      '#description' => t('Configure the oracle db connection settings for Rolnik.'),
    ];

    $protocolOptions = [
      'USETNS' => $this->t('Use TNS'),
      'TCP' => $this->t('TCP w/o SSL'),
      'TCPS' => $this->t('TCP w/SSL'),
      'ICP' => $this->t('HP-UX interprocess communication'),
      'NMP' => $this->t('Unix named pipe'),
      'SPX' => $this->t('Novell'),
      'DCE' => $this->t('Cisco/Brocade Data Center Ethernet'),
      'SDP' => $this->t('RDMA sockets direct protocol'),
      'OSI4' => $this->t('Transport Fast Byte Protocol - ISO 14699'),
      'BEQ' => $this->t('Bequeath'),
      'X25' => $this->t('X25'),
      'DECNet' => $this->t('DECNet'),
      'NTP' => $this->t('NetBIOS'),
      'APPC' => $this->t('IBM mainframe'),
      'ASYNC' => $this->t('ASYNC'),
      'RAW' => $this->t('RAW'),
    ];

    $form['r_oracle']['rolnik_db_protocol'] = [
      '#type' => 'select',
      '#title' => $this->t('Protocol'),
      '#description' => $this->t('The connection protocol used to connect to the oracle database.<br /> <strong>NOTE:</strong>Not all of these options have been implemented.'),
      '#options' => $protocolOptions,
      '#default_value' => empty($settings['rolnik_db_protocol']) ? 'TCP' : $settings['rolnik_db_protocol'],
    ];

    $form['r_oracle']['rolnik_db_host'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Host'),
      '#description' => $this->t('The the database host name.'),
      '#default_value' => $settings['rolnik_db_host'],
    ];

    $form['r_oracle']['rolnik_db_port'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Port'),
      '#description' => $this->t('The port used to connect to the database.'),
      '#default_value' => empty($settings['rolnik_db_port']) ? '1521' : $settings['rolnik_db_port'],
    ];

    $form['r_oracle']['rolnik_db_sid'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Site Identifier (SID)'),
      '#description' => $this->t('The SID used to connect to the database instance.'),
      '#default_value' => $settings['rolnik_db_sid'],
    ];

    $form['r_oracle']['rolnik_db_username'] = [
      '#type' => 'textfield',
      '#title' => $this->t('DB Username'),
      '#description' => $this->t('The username used to connect to the database.'),
      '#default_value' => $settings['rolnik_db_username'],
      '#attributes' => ['autocomplete' => 'off'],
    ];

    $pwNote = t('There is no password saved.');
    if (!empty($settings['rolnik_db_password'])) {
      $pwNote = t('A password has been saved.');
    }
    $form['r_oracle']['rolnik_db_password'] = [
      '#type' => 'password',
      '#title' => $this->t('DB Password'),
      '#description' => $this->t('The password used to connect to the database. <br /> <strong>@pwNote</strong>', ['@pwNote' => $pwNote]),
      '#attributes' => ['autocomplete' => 'new-password'],
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save settings'),
      '#button_type' => 'primary',
    );

    return $form;
  }

  /**
   * Handle the validation of the rolnik general settings form.
   *
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    parent::validateForm($form, $form_state);
  }

  /**
   * Handle the rolnik general settings form submission.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {

    // Get the configuration settings
    $config = $this->configFactory->getEditable('rolnik.settings');

    // Save configuration settings
    $config
      ->set('rolnik_record_per_piece', $form_state->getValue('rolnik_record_per_piece'))
      ->set('rolnik_db_protocol', $form_state->getValue('rolnik_db_protocol'))
      ->set('rolnik_db_host', $form_state->getValue('rolnik_db_host'))
      ->set('rolnik_db_port', $form_state->getValue('rolnik_db_port'))
      ->set('rolnik_db_sid', $form_state->getValue('rolnik_db_sid'))
      ->set('rolnik_db_username', $form_state->getValue('rolnik_db_username'))
      ->set('rolnik_extra_members_node', $form_state->getValue('rolnik_extra_members_node'))
      ->save();

    // Prevent old password from being overwritten on saving form settings if
    // an old password already exists while allowing a new new password to be
    // saved if provided.
    $oldPassword = $config->get('rolnik_db_password');
    $newPassword = $form_state->getValue('rolnik_db_password');
    if (empty($oldPassword) || !empty($newPassword)) {
      $config->set('rolnik_db_password', $newPassword)
        ->save();
    }

    parent::submitForm($form, $form_state);
  }
}
