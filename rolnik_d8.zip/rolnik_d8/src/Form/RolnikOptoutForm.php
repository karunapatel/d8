<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\rolnik\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of RolnikOptoutForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class RolnikOptoutForm extends ConfigFormBase {

   /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['rolnik.settings'];
  }
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rolnik_optout_form';
  }

  /**
   * The Rolnik Opt-out form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
	
	
/* 	$result = \Drupal::database()->select('my_custom', 'n')
            ->fields('n', array('id', 'name', 'message'))
            ->execute()->fetchAllAssoc('id');

    $rows = array();
    foreach ($result as $row => $content) {
      $rows[] = array(
        'data' => array($content->id, $content->name, $content->message));
    } */
	
	$form['optout'] = array(
	   '#type' => 'fieldset',
	   '#title' => $this->t('Rolnik Exclusion List - Choose Customer to Change'),
	);
	
	$header = [
     'fullname' => t('Full Name'),
     'address' => t('Address'),
     'city' => t('City'),
     'system' => t('Cesta'),
     'customerno' => t('Customer No.'),
     'excludedinfo' => t('Customer Excluded ?'),
    ];
	
	// Initialize an empty array
	$output = array();
	// Next, loop through the $results array
	/* foreach ($results as $result) {
     if ($result->uid != 0 && $result->uid != 1) {
       $output[$result->uid] = [
         'fullname' => 'sdgsdh',   
         'address' => 'dhfsfg',
         'city' => 'ghfh',   
         'system' => 'fgggggggggd',    
         'customerno' => 'fghdf',    
         'excludedinfo' => 'fghfghgf',    
       ];
     }
    } */
	$output[] = [
        'fullname' => 'Blah blah',   
        'address' => 'Blah blah',
        'city' => 'Texas',   
        'system' => 'Cesta',    
        'customerno' => '2',    
        'excludedinfo' => 'no',    
    ];
	
	$form['optout']['table'] = [
		'#type' => 'tableselect',
		'#header' => $header,
		'#options' => $output,
		'#empty' => t('No records found.'),
	];

    $form['action']['#type'] = 'actions';
    $form['optout']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
      '#button_type' => 'primary',
    );

    return $form;
  }

  /**
   * Handle the validation of the rolnik Opt-out form.
   *
   * {@inheritdoc}
   */
   public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * Handle the rolnik Opt-out form submission.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Should not be a submittable form.
  }


}
