<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\rolnik\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Description of RolnikExtraMemberForm
 *
 * @author Daniel Taylor <dtaylor@rvos.com>
 */
class RolnikExtraMemberForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'rolnik_extramember_form';
  }

  /**
   * The Rolnik Opt-out form
   *
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
	$form = array(
      '#attributes' => array('enctype' => 'multipart/form-data'),
    );
    $validators = array(
      'file_validate_extensions' => array('doc docx odt pdf'),
    );
		
	$form['member_file_upload'] = [
		'#type' => 'managed_file',
		'#title' => 'Upload attachment',
		'#description' => t('Allowed formats : doc, docx, odt, pdf.'),
        '#upload_validators' => $validators, 
        /* '#upload_validators' => array(
			'file_validate_unique' => array($file),
			'file_validate_extensions' => array('doc docx odt pdf'),
		);  */	
        '#upload_location' => 'public://rolnik-extramember/',
	];

    $form['action']['#type'] = 'actions';
    $form['action']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Upload'),
      '#button_type' => 'primary',
    );

    return $form;
  }

  /**
   * Handle the validation of the rolnik extra member form.
   *
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if ($form_state->getValue('member_file_upload') == NULL) {
      $form_state->setErrorByName('member_file_upload', $this->t('Please upload file.'));
    }
	$file = \Drupal::entityTypeManager()->getStorage('file')->load($form_state->getValue('member_file_upload')[0]);
    
	$filename = $file->get('filename')->value;
    if (file_exists('public://rolnik-extramember/' . $filename)) { 
       $form_state->setErrorByName('member_file_upload', $this->t('The file ' . $file->get('filename')->value . ' could not be uploaded because a file by that name already exists in the destination directory.'));
    }  	 
	//parent::validateForm($form, $form_state);
  }
  
  /*  public function file_validate_unique($file) { 
	   $file = \Drupal::entityTypeManager()->getStorage('file')->load($form_state->getValue('member_file_upload')[0]);
    
	   $filename = $file->get('filename')->value;
	   if (file_exists('public://rolnik-extramember/' . $filename)) { 
			 $errors[] = t('The file could not be uploaded because a file by that name already exists in the destination directory.');
	   }
	   return $errors;
   }  */

  /**
   * Handle the rolnik extra member form submission.
   *
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
  
	// Get the configuration settings
    // $config = $this->configFactory->getEditable('rolnik.settings');
	
	// get the file entity 
    $file = \Drupal::entityTypeManager()->getStorage('file')->load($form_state->getValue('member_file_upload')[0]); 

    // Save configuration settings
    //$config->set('member_file_upload', $form_state->getValue('member_file_upload'))->save();
    
	//parent::submitForm($form, $form_state);
    // access field via standard method
	drupal_set_message($file->get('filename')->value . ' File has been successfully uploaded');
   // dpm($file->get('filename')->value);
	
  }


}
