<?php
/**
 * @file
 * Definition of \Drupal\rolnik\Controller\RolnikList.
 */
namespace Drupal\rolnik\Controller;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\rolnik\Repository\DatabaseConnectionInterface;
use Drupal\rolnik\Query\QueryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

/**
 * Controller for RolnikList
 */
class RolnikList extends ControllerBase
{

  protected $config;
  protected $rolnik;
  protected $totalQuery;
  protected $infoQuery;
  protected $customerQuery;

  /**
   * {@inheritDoc}
   * 
   * Customized for rolnik module
   */
  public function __construct(ConfigFactoryInterface $config_factory, DatabaseConnectionInterface $rolnik, QueryInterface $totalQuery, QueryInterface $infoQuery, QueryInterface $customersQuery)
  {
    $this->config = $config_factory->get('rolnik.settings');
    $this->rolnik = $rolnik;
    $this->totalQuery = $totalQuery;
    $this->infoQuery = $infoQuery;
    $this->customerQuery = $customersQuery;
  }

  /**
   * {@inheritDoc}
   * 
   * Customized for rolnik module.
   */
  public static function create(ContainerInterface $container)
  {
    return new static(
      $container->get('config.factory')
      , $container->get('rolnik.dao')
      , $container->get('rolnik.totalquery')
      , $container->get('rolnik.infoquery')
      , $container->get('rolnik.customerquery')
    );
  }

  /**
   * Builds the response for the /rolnik-list page.
   * 
   * @param int $page The page number requested.
   * @return array  A Drupal renderable array.
   */
  public function rolnikList()
  {

    $num_records = $this->config->get('rolnik_record_per_piece');

    // The query services return stdClass objects, as an array of stdClass if
    // the count() of results is greater than zero (0).
    $results = $this->totalQuery->execute();
    
    $total_insured = 0;
    if(0 != $count = count($results)) {
      $total_insured = $results[0]->TOTAL;
    }

    $links = [];
    if ($total_insured > 0) {
      $pages = $total_insured / $num_records;
      $total_pages = ceil($pages);
      $p = 1;
      while ($p <= $total_pages) {
        // Rebuild this link using Drupal 8's URI and Link objects.
        $url = Url::fromRoute('rolnik.download', ['page' => $p], ['attributes' => ['target' => '_blank']]);
        $link = Link::fromTextAndUrl($this->t('Download Part @s', ['@s' => $p]), $url);
        $links[] = $link->toString();
        $p++;
      }
    }

    return [
      '#title' => $this->t('Rolnik List Download'),
      '#theme' => 'rolnik_list',
      '#data' => [
        'num_records' => $num_records,
        'links' => $links,
      ],
    ];
  }

  public function managerlist()
  {
    $form = \Drupal::formBuilder()->getForm('\Drupal\rolnik\Form\RolnikSearchForm');
    $url = Url::fromRoute('rolnik.list');
    $link = Link::fromTextAndUrl(t('Back'), $url);
    $back_link = $link->toRenderable();
    $back_link['#attributes'] = array('class' => array('back-link nouse'));
    return [
      '#title' => $this->t('Rolnik List Manager'),
      '#theme' => 'rolnik_list_manager',
      '#data' => [
        'back_link' => $back_link,
        'form' => $form,
      ],
    ];
  }

  public function extramembers()
  {
    /* $form = \Drupal::formBuilder()->getForm('\Drupal\rolnik\Form\RolnikExtraMemberForm');*/
    $url = Url::fromRoute('rolnik.list');
    $link = Link::fromTextAndUrl(t('Back'), $url);
    $back_link = $link->toRenderable();
    $back_link['#attributes'] = array('class' => array('back-link nouse'));
	/*
	$dir = 'public://rolnik-extramember/';
	//$mask = '/.*\.pdf$/';
	$mask = '/\.(?:pdf|doc|docx|odt)$/i';
	$files = file_scan_directory($dir, $mask, $options = array(), $depth = 0);
	$x = 0;
	$file_datas = array();
	foreach ($files as $file) {
		$file_url = file_create_url($file->uri);
		$file_name = $file->filename;
		$file_datas[$x]['file_url'] = $file_url;
		$file_datas[$x]['file_name'] = $file_name;
		$x++;
    } 
    return [
        '#title' => $this->t('Rolnik Extra Members'),
        '#theme' => 'rolnik_extra_members',
        '#data' => [
			'back_link' => $back_link,
			'form' => $form,
			'file_datas' => $file_datas,
		],
    ]; */


	$nodeId = $this->config->get('rolnik_extra_members_node');
  $entity_type = 'node';
  $view_mode = 'default';

  $output = '';
  if (!empty($nodeId)) {
    $view_builder = \Drupal::entityTypeManager()->getViewBuilder($entity_type);
    $storage = \Drupal::entityTypeManager()->getStorage($entity_type);
    $entity = $storage->load($nodeId);
    $build = $view_builder->view($entity, $view_mode);
    $output = render($build);
  }

	return [
        '#title' => $this->t('Rolnik Extra Members'),
        '#theme' => 'rolnik_extra_members',
        '#data' => [
			'content' => $output,
			'back_link' => $back_link,
		],
	];
  }

  public function download($page)
  {

    $filename = "Rolnik_List_Part_$page.csv";

    $num_records = $this->config->get('rolnik_record_per_piece');

    // What we do here is create and serve up the file on request. This way we
    // aren't creating all the .csv files at once. Creating all the files at
    // once could cause the end-user to believe the site has stopped responding.
    if ($page > 0) {
      $start = ($page - 1) * $num_records;

      // The query services return stdClass objects, as an array of stdClass if
      // the count() of results is greater than zero (0).
      $results = $this->infoQuery->execute([':thestart' => $start, ':totalPerPage' => $num_records]);

      // Convert the stdClass results to json, and then back as an array instead
      // of stdClass objects.
      $rolnik_records = json_decode(json_encode($results), true);

      // The CSV header line defining the names of the columns.
      $header = ['Num', 'Insured Name', 'Insured Address', 'City', 'State', 'Zip', 'code', 'Agent Name', 'Agent Phone'];
      $fileData = implode(',', $header) . "\r\n";

      // Write each record to the file.
      foreach ($rolnik_records as $record) {
        $fileData .= implode(',', $record) . "\r\n";
      }

      // Build the physical file, which returns a Drupal 8 file path string with
      // the usabe of file_unmanaged_save_date(). A file object/entity is returned
      // if file_save_data() is used.
      $path = 'public://rolnik/';
      if (file_prepare_directory($path, FILE_CREATE_DIRECTORY)) {
        $file = file_unmanaged_save_data($fileData, $path . $filename, FILE_EXISTS_REPLACE);
      }
    }

    // Build the download response...
    $response = new BinaryFileResponse($file);
    $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $filename);
    return $response;
  }
}
