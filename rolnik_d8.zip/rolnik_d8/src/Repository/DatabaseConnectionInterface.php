<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Drupal\rolnik\Repository;

/**
 *
 * @author dtaylor
 */
interface DatabaseConnectionInterface
{

  /**
   * Establishes an Oracle database connection.
   * 
   * @param string $protocol
   * @param string $host
   * @param int $port
   * @param string $sid
   * @param string $username
   * @param string $password
   * @return DatabaseConnectionInterface
   */
  public function connect($protocol, $host, $port = 1521, $sid, $username, $password);

  /**
   * Queries a database.
   *
   * @param string $query
   * @param array $bindArgs Query placeholder parameters.
   * @return query results array/object.
   */
  public function query($query, array $bindArgs = array(), array $options = array());
}
