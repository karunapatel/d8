<?php
namespace Drupal\rolnik\Repository;

use Drupal\rolnik\Repository\DatabaseConnectionInterface;
use Drupal\Core\Url;

abstract class AbstractOracleDatabaseAccessObject implements DatabaseConnectionInterface
{
  
  /**
   * Oracle database connection resource.
   *
   * @var resource
   */
  protected $conn = null;
  
  /**
   * {@inheritDoc}
   */
  public function connect($protocol, $host, $port = 1521, $sid, $username, $password)
  {
    $db = sprintf(
      '(DESCRIPTION=(ADDRESS_LIST = (ADDRESS = (PROTOCOL = %s)(HOST = %s)(PORT = %s)))(CONNECT_DATA=(SID=%s)))'
      , $protocol
      , $host
      , $port
      , $sid
    );
    
    $conn = oci_connect($username, $password, $db);

    if (!$conn) {
      $user = \Drupal::currentUser();
      $url = Url::fromRoute('rolnik_settings')->toString();
      if ($user->hasPermission('administer site configuration')) {
        drupal_set_message(t('Visit the <a href=":url">Rolnik Settings</a> page to configure the ROLNIK settings.', [':url' => $url]), 'warning');
      } else {
        drupal_set_message(t('We\'re sorry, but we\'re unable to process your request.<br />If you continue to experience this issue please contact Computer Operations.'), 'warning');
      }
      return;
    }

    $this->conn = $conn;
    return $this;
  }

  /**
   * Default destructor.
   */
  public function __destruct()
  {
    if (!is_null($this->conn)) {
      oci_close($this->conn);
      $this->conn = null;
    }
  }

  /**
   * {@inheritDoc}
   */
  public function query($query, array $bindArgs = array(), array $options = array())
  {
    if (!$this->conn) {
      return false;
    }

    $results = [];
    $stmt = oci_parse($this->conn, $query);

    if (count($bindArgs) > 0) {
      $this->bindArgs($stmt, $bindArgs);
    }

    oci_execute($stmt);
    if (oci_statement_type($stmt) == 'SELECT') {
      while (false != $item = oci_fetch_object($stmt)) {
        $results[] = $item;
      }
    } else {
      $results = oci_num_rows($stmt);
    }

    oci_free_statement($stmt);

    return $results;
  }

  /**
   * Binds variables to the prepared statement.
   * 
   * @param oci_statement resource $stmt
   * @param array $bindArgs
   */
  protected function bindArgs(&$stmt, array $bindArgs = array())
  {
    foreach (array_keys($bindArgs) as $placeholder) {
      if (is_array($placeholder) && count($placeholder) > 0) {
        $this->bindArgs($stmt, $placeholder);
      } else {
        oci_bind_by_name($stmt, $placeholder, $bindArgs[$placeholder]);
      }
    }
  }
}
