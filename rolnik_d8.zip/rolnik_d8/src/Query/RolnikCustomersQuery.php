<?php
namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\AbstractQuery;

class RolnikCustomersQuery extends AbstractQuery
{

  /**
   * {@inheritDoc}
   */
  public function getSQL()
  {
    return "SELECT DISTINCT Trim(Upper(ins.enty_name)) NAME,
      Trim(Upper(ins.enty_address1)) address,
      Trim(Upper(ins.enty_city)) city,
      'CESTA' AS SYSTEM,
      ins.enty_code customer_number,
       CASE
         WHEN re_customer_no IS NULL THEN 'No'
         ELSE 'Yes'
       END AS excluded
      FROM stg_core.policy_register
        CROSS JOIN stg_core.entity_address_master ins
        LEFT OUTER JOIN lodge.rolnik_exclude re ON ins.enty_code = re_customer_no
      WHERE preg_status <> 'C'
      AND   preg_end_date >SYSDATE
      AND   preg_subline = 'RV010'
      AND   ins.enty_code = preg_insured
      AND   ins.enty_status = 'Y'
      AND   ins.enty_group_code = 'INSURED'
      AND   REGEXP_LIKE (UPPER(ins.enty_name), UPPER(:name))
      AND   Substr(ins.enty_zip,1,5) = :zipcode";
  }
}
