<?php
namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\AbstractQuery;

class RolnikTotalQuery extends AbstractQuery
{

  /**
   * {@inheritDoc}
   */
  public function getSql()
  {
    return 'SELECT COUNT(*) total FROM (SELECT DISTINCT ins.enty_name
    , ins.enty_address1 || \' \' || ins.enty_address2 
       , ins.enty_city 
       , ins.enty_state 
       , DECODE(LENGTH(ins.enty_zip),
             \'9\', SUBSTR(ins.enty_zip, 1, 5) || \'-\' || SUBSTR(ins.enty_zip, 6, 10),
             ins.enty_zip
       )
       , bro.enty_name 
       , CASE
         WHEN bro.enty_busstel LIKE \'%-%\' THEN bro.enty_busstel
         ELSE SUBSTR(bro.enty_busstel,1,3) || \'-\' || SUBSTR(bro.enty_busstel,4,3) || \'-\' || SUBSTR(bro.enty_busstel,7,4)
       END
    FROM stg_ext.entity_address_master ins
      INNER JOIN stg_ext.policy_register ON ins.enty_code = preg_insured

      INNER JOIN stg_ext.entity_address_master bro ON bro.enty_code = (SELECT preg_subbroker
                                                                       FROM stg_ext.policy_register
                                                                       WHERE preg_insured = ins.enty_code
                                                                       AND   ROWNUM = 1)
      LEFT OUTER JOIN lodge.rolnik_exclude ON re_customer_no = ins.enty_code
      WHERE ins.enty_group_code = \'INSURED\'
      AND   ins.enty_status = \'Y\'
      AND   preg_subline = \'RV010\'
      AND   preg_status <> \'C\'
      AND   preg_end_date >SYSDATE
      AND   bro.enty_group_code = \'BROKER\'
      AND   bro.enty_status = \'Y\'
      AND   re_customer_no IS NULL

    UNION ALL 

      SELECT nname1
           , naddr1
           , ncity
           , nstate
           , CAST(nzip AS VARCHAR2 (10))
           , ofname
           , CASE
             WHEN ofhomp = 0 THEN substr(OFMOBP,1,3) || \'-\' ||substr (OFMOBP,4,3) || \'-\' || SUBSTR(OFMOBP,7,4)
             ELSE substr(OFHOMP,1,3) || \'-\' ||substr (OFHOMP,4,3) || \'-\' || SUBSTR(OFHOMP,7,4)
           END AS PHONE


      FROM (SELECT DISTINCT NNAME1
                 , NADDR1
                 , NCITY
                 , NSTATE
                 , NZIP
                 , PMSR#
          FROM filesqry.namast@as400
            INNER JOIN filesqry.polmst@as400 ON nmem# = pmmem#
            LEFT OUTER JOIN lodge.rolnik_exclude ON re_customer_no = nmem#
          WHERE nrflg = \'Y\'
          AND   pmact != \'D\'
          AND   nactcd = \' \'
          AND   re_customer_no IS NULL) t
      INNER JOIN filesqry.offmst@as400 ON ofno = pmsr#


      UNION ALL
      SELECT DISTINCT nname1
             , naddr1
             , ncity
             , nstate
             , CAST(nzip AS VARCHAR2 (10))
             , \'\' AS agent_name
             , \'\' AS agent_phone
      FROM filesqry.rolmbr@as400
    )';
  }
}
