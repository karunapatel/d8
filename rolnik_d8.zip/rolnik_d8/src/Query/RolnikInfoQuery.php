<?php
namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\AbstractQuery;

class RolnikInfoQuery extends AbstractQuery
{

  /**
   * {@inheritDoc}
   */
  public function getSql()
  {
    return 'SELECT * FROM (
      SELECT ROWNUM AS rn, a.* FROM (
          SELECT NAME,
          address,
          city,
          STATE,
          ZIP,
          agent,
          agent_name,
          agent_phone
        FROM (
          SELECT DISTINCT agent,
            NAME,
            address,
            city,
            STATE,
            ZIP
          FROM (
            /* Retrieve distinct customers from Cesta */
            SELECT DISTINCT a.patc_subbroker agent,
         -- NAME AND THE CARE OF NAME
              trim(upper(ins.enty_name)) || \' \' ||  
              trim(upper(ins.ENTY_DBA)) NAME,
              trim(upper(ins.enty_address1)) address,
              trim(upper(ins.enty_city)) city,
              trim(upper(ins.enty_state)) STATE,
              DECODE(LENGTH(ins.enty_zip),\'9\', 
                SUBSTR(ins.enty_zip, 1, 5) || \'-\' || SUBSTR(ins.enty_zip, 6, 10), ins.enty_zip) ZIP
            FROM stg_core.policy_register,
              stg_core.entity_address_master ins,
              stg_core.policy_status s,
              stg_policy_core.policy_attrib_changes a,
              lodge.rolnik_exclude
            WHERE preg_status IS NOT NULL
              AND preg_begin_date <= sysdate
              AND preg_end_date > sysdate
              AND preg_subline = \'RV010\'
              AND ins.enty_code = preg_insured
              AND ins.enty_status = \'Y\'
              AND ins.enty_group_code = \'INSURED\'
              AND re_customer_no(+) = ins.enty_code
              AND re_customer_no IS NULL
              AND s.psta_policy_no = preg_policy_no
              AND s.psta_policy_renew_no = preg_policy_renew_no
              AND s.psta_status <> \'TR\'
              AND (
                s.psta_system_activity_no,
                s.psta_policy_no,
                s.psta_policy_renew_no
                ) IN (
                SELECT MAX(psta_system_activity_no),
                  inn.psta_policy_no,
                  inn.psta_policy_renew_no
                FROM stg_core.policy_status inn
                WHERE TRUNC(inn.psta_date_generate) <= sysdate
                  AND inn.psta_policy_no = s.psta_policy_no
                  AND inn.psta_policy_renew_no = s.psta_policy_renew_no
                GROUP BY inn.psta_policy_no,
                  inn.psta_policy_renew_no
                )
              AND a.patc_policy_no = preg_policy_no
              AND a.patc_policy_renew_no = preg_policy_renew_no
              AND (
                NVL(a.patc_edr_session_no, 0),
                NVL(a.patc_edr_eff_date, a.patc_begin_date)
                ) IN (
                SELECT MAX(TO_NUMBER(NVL(b.patc_edr_session_no, 0))),
                  MAX(NVL(b.patc_edr_eff_date, b.patc_begin_date))
                FROM stg_policy_core.policy_attrib_changes b
                WHERE b.patc_policy_no = a.patc_policy_no
                  AND b.patc_policy_renew_no = a.patc_policy_renew_no
                  AND b.patc_status = \'Y\'
                  AND NVL(b.patc_edr_eff_date, b.patc_begin_date) = (
                    SELECT MAX(NVL(c.patc_edr_eff_date, c.patc_begin_date))
                    FROM stg_policy_core.policy_attrib_changes c
                    WHERE c.patc_policy_no = b.patc_policy_no
                      AND c.patc_policy_renew_no = b.patc_policy_renew_no
                      AND NVL(c.patc_edr_eff_date, c.patc_begin_date) <= sysdate
                      AND c.patc_status = \'Y\'
                    )
                )
            UNION
            /*  Retrieve distinct customers from Cesta      */
            SELECT DISTINCT to_char(ag.subbroker) agent,
              trim(upper(nname1)) NAME,
              trim(upper(naddr1)) address,
              trim(upper(ncity)) city,
              trim(upper(nstate)) STATE,
              trim(upper(nzip)) ZIP
            FROM filesqry.polmst@as400,
              filesqry.namast@as400,
              filesqry.stcagt@as400 ag,
              lodge.rolnik_exclude
            WHERE pmmem# = nmem#
              AND nrflg = \'Y\'
              AND pmact = \' \'
              AND pmsr# = ag.agtno
              AND re_customer_no(+) = pmmem#
              AND re_customer_no IS NULL
            )
          ) customer,
          /*----------------------------------------------------------------------------------------------
            agent Name retrieval
          ---------------------------------------------------------------------------------------------- */
          (
            SELECT DISTINCT sbrk.enty_code agent_no,
              sbrk.enty_name agent_name,
              sbrk.enty_address1 agent_address,
              sbrk.enty_city agent_city,
              sbrk.enty_state agent_state,
              CASE 
                WHEN sbrk.enty_busstel LIKE \'%-%\'
                  THEN sbrk.enty_busstel
                ELSE SUBSTR(sbrk.enty_busstel, 1, 3) || \'-\' || SUBSTR(sbrk.enty_busstel, 4, 3) || \'-\' || SUBSTR(sbrk.enty_busstel, 7, 4)
                END AS agent_phone
            FROM stg_core.entity_address_master sbrk
            WHERE sbrk.enty_status = \'Y\'
              AND sbrk.enty_group_code = \'BROKER\'
            ) agent
          WHERE customer.agent = agent.agent_no(+)
      )a
    )
    WHERE ROWNUM <= :totalPerPage
    AND rn > :thestart';
  }
}
