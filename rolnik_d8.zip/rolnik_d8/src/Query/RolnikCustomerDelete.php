<?php

namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\AbstractQuery;

class RolnikCustomerDelete extends AbstractQuery
{
  /**
   * {@inheritDoc}
   */
  public function getSQL()
  {
    return "DELETE FROM lodge.rolnik_exclude WHERE RE_CUSTOMER_NO = :customer_number";
  }
}
