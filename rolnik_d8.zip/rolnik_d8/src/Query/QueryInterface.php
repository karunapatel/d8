<?php
namespace Drupal\rolnik\Query;

interface QueryInterface
{
  /**
   * Retrieves the results of the query.
   * 
   * @param array $bindings The bindings to bind to the SQL Statement.
   * @param array $options The options for the SQL statement.
   */
  public function execute(array $bindings = [], array $options = []);
  
  /**
   * The SQL statement to be executed.
   */
  public function getSQL();
}
