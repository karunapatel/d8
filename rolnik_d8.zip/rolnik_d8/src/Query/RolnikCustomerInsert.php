<?php

namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\AbstractQuery;

class RolnikCustomerInsert extends AbstractQuery
{
  /**
   * {@inheritDoc}
   */
  public function getSQL()
  {
    return "INSERT INTO lodge.rolnik_exclude (RE_CUSTOMER_NO) VALUES (:customer_number)";
  }
}
