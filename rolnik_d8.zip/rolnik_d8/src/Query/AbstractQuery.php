<?php
namespace Drupal\rolnik\Query;

use Drupal\rolnik\Query\QueryInterface;
use Drupal\rolnik\Repository\DatabaseConnectionInterface;

abstract class AbstractQuery implements QueryInterface
{

  /**
   * The database connection object/service.
   * 
   * @var database connection object.
   */
  protected $conn = null;

  /**
   * The default constructor.
   * 
   * @param type $connection
   */
  public function __construct(DatabaseConnectionInterface $connection)
  {
    $this->conn = $connection;
  }

  /**
   * {@inheritDoc}
   */
  public function execute(array $bindings = [], array $options = [])
  {
    return $this->conn->query($this->getSql(), $bindings, $options);
  }
}
