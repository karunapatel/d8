<?php

/**
 * @filesource
 * @author Daniel Taylor <dtaylor@rvos.com>
 */

namespace Drupal\lodge\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'Rolnik List' block.
 *
 * @Block(
 *   id = "rolnik_list_block",
 *   admin_label = @Translation("Rolnik List Block"),
 *   category = @Translation("Rolnik")
 * )
 */
class RolnikList extends BlockBase {

  public function build() {
    $form = \Drupal::formbuilder()->getForm('Drupal\rolnik\Form\RolnikGeneralSettingsForm');
    return $form;
  }

}
